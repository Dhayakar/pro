import {
  Component,
  HostListener,
  LOCALE_ID,
  Inject,
  ViewChild,
  ElementRef,
} from "@angular/core";
import { Router } from "@angular/router";
import { TranslateService } from "@ngx-translate/core";
import { Title } from "@angular/platform-browser";
import { Subscription } from "rxjs";
import { LoggingService } from "./services/logging/logging.service";
import { TranslateCacheService } from "ngx-translate-cache";
import { IntlService, CldrIntlService } from "@progress/kendo-angular-intl";
import { SidebarComponent } from "./core/navigation/sidebar/sidebar.component";
import { OrderCreateSelectorComponent } from "@orders/order-create/order-create-selector/order-create-selector.component";
import { OrderGridSelectorComponent } from "@orders/order-grid/order-grid-selector/order-grid-selector.component";
import { OrderViewDetailsSelectorComponent } from "@orders/order-view-details/order-view-details-selector/order-view-details-selector.component";
import { OrderEditSelectorComponent } from "@orders/order-edit/order-edit-selector/order-edit-selector.component";
import { OrderViewAttachmentComponent } from "@orders/order-attachment/order-view-attachment.component";
import { OrderNotesComponent } from "@orders/order-notes/order-notes.component";
import { OrderListCorrespondenceComponent } from "@orders/order-correspondence/list/order-list-correspondence.component";
import { OrderViewHistoryComponent } from "@orders/order-history/order-view-history.component";
import { OrderGridCompanionComponent } from "@orders/order-grid/order-grid-companion/order-grid-companion.component";
import { LoaderService } from "@services/loader/loader.service";
import { IdleWatchService } from "@services/idle-watch/idle-watch.service";
import { AppConfigService } from "@services/app-config/app-config.service";

@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.scss"],
  queries: {
    scrollContentRef: new ViewChild("scrollContentRef", { static: false }),
  },
})
export class AppComponent {
  scrolled: boolean;
  customHeader: boolean = false;
  translationsHaveBeenFetched: boolean = false;
  @ViewChild("sidebar", { static: false }) sidebar: SidebarComponent;
  public scrollContentRef!: ElementRef;

  private popupOpenSubscription: Subscription;
  private popupCloseSubscription: Subscription;
  private initializeSubscription: Subscription;
  private statusChangeSubscription: Subscription;
  private revokeChoiceSubscription: Subscription;

  constructor(
    public router: Router,
    private translate: TranslateService,
    private readonly loaderService: LoaderService,
    private titleService: Title,
    private loggingService: LoggingService /* Don't remove loggingService declaration */,
    private translateCacheService: TranslateCacheService,
    @Inject(LOCALE_ID) public localeId: string,
    public intlService: IntlService,
    public readonly idleWatchService: IdleWatchService,
    private readonly appConfigService: AppConfigService,
  ) {
    this.setUpTranslateService();
  }

  ngOnInit() {
    this.loggingService.initialize();
    this.scrolled = false;
    this.localeId = this.translate.currentLang;
    (<CldrIntlService>this.intlService).localeId = this.localeId;
    this.initialiseGoogleTagManager();
  }

  ngOnDestroy() {
    // unsubscribe to cookieconsent observables to prevent memory leaks
    this.popupOpenSubscription.unsubscribe();
    this.popupCloseSubscription.unsubscribe();
    this.initializeSubscription.unsubscribe();
    this.statusChangeSubscription.unsubscribe();
    this.revokeChoiceSubscription.unsubscribe();
  }

  @HostListener("window:scroll", [])
  onWindowScroll() {
    const scrollDistance =
      window.pageYOffset ||
      document.documentElement.scrollTop ||
      document.body.scrollTop ||
      0;
    this.scrolled = scrollDistance > 0;
  }

  onActivate(event) {
    if (this.sidebar) this.sidebar.expanded = false;

    this.scrollContentRef.nativeElement.scrollTo(0, 0);
    this.setCustomHeader(event);
    this.idleWatchService.showPopup = false;
  }

  onEntityChange() {
    if (this.sidebar) this.sidebar.getAvailableProducts();
  }

  displayNavigation(): boolean {
    return this.idleWatchService.onPageThatRequiresLogin(location.href);
  }

  setUpTranslateService() {
    this.translate.addLangs([
      "en",
      "fr",
      "de",
      "it",
      "es",
      "ja",
      "pt-br",
      "zh",
    ]);
    this.translate.setDefaultLang("en");
    this.translateCacheService.init();
    this.loaderService.start();
    this.translate.get("application-title").subscribe((translation: string) => {
      this.titleService.setTitle(translation);
      this.translationsHaveBeenFetched = true;
      this.loaderService.stop();
    });
  }

  setCustomHeader(event: any) {
    if (
      event instanceof OrderCreateSelectorComponent ||
      event instanceof OrderGridSelectorComponent ||
      event instanceof OrderViewDetailsSelectorComponent ||
      event instanceof OrderEditSelectorComponent ||
      event instanceof OrderViewAttachmentComponent ||
      event instanceof OrderNotesComponent ||
      event instanceof OrderListCorrespondenceComponent ||
      event instanceof OrderViewHistoryComponent ||
      event instanceof OrderGridCompanionComponent
    )
      this.customHeader = true;
    else this.customHeader = false;
  }

  closeIdleWatchPopup(): void {
    this.idleWatchService.showPopup = false;
  }

  @HostListener("click", ["$event.target"]) onClick(e) {
    if (this.sidebar && !e.hasAttribute("sbnav")) {
      this.sidebar.isCollapseFlag = true;
      this.sidebar.expanded = false;
    }
  }

  private initialiseGoogleTagManager() {
    this.createGoogleTagManagerScriptInHead();
    this.createGtagFunctionInHead();
  }

  private createGoogleTagManagerScriptInHead(): void {
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = `https://www.googletagmanager.com/gtag/js?id=${this.appConfigService.config.gtm.id}`;
    this.AppendToHeadElement(script);
  }

  private createGtagFunctionInHead() {
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.innerHTML = `window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
  
    gtag('config', '${this.appConfigService.config.gtm.id}', {'debug_mode':${this.appConfigService.config.gtm.debug}});`;
    this.AppendToHeadElement(script);
  }

  private AppendToHeadElement(script: HTMLScriptElement) {
    const head = document.getElementsByTagName("head")[0];
    if (head !== null && head !== undefined) {
      document.head.appendChild(script);
    }
  }
}
