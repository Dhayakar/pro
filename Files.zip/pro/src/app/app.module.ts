import {
  NgModule,
  APP_INITIALIZER,
  ErrorHandler,
  LOCALE_ID,
} from "@angular/core";
import { AppComponent } from "./app.component";
import { MenuModule } from "@progress/kendo-angular-menu";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import {
  HttpClientModule,
  HttpClient,
  HTTP_INTERCEPTORS,
  HttpXsrfTokenExtractor,
} from "@angular/common/http";
import {
  TranslateModule,
  TranslateLoader,
  TranslateService,
} from "@ngx-translate/core";
import {
  TranslateCacheModule,
  TranslateCacheSettings,
  TranslateCacheService,
} from "ngx-translate-cache";
import {
  MsalService,
  BroadcastService,
  MsalModule,
  MsalInterceptor,
  MSAL_CONFIG,
  MSAL_CONFIG_ANGULAR,
  MsalAngularConfiguration,
} from "@azure/msal-angular";
import { AppConfigService } from "./services/app-config/app-config.service";
import { CoreModule } from "./core/core.module";
import { RomeInterceptorService } from "./services/interceptors/rome-interceptor.service";
import { SchedulerModule } from "@progress/kendo-angular-scheduler";
import { DirtyPopupComponent } from "./services/guards/dirty-check-guard";
import { IdleWatchPopupComponent } from "./shared/components/idle-watch-popup/idle-watch-popup.component";
import { DialogModule } from "@progress/kendo-angular-dialog";
import { Router } from "@angular/router";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { LoggingService } from "./services/logging/logging.service";
import { ErrorHandlerService } from "./services/error-handling/error-handler.service";
import { AuthorisationService } from "./services/authorisation/authorisation.service";
import { TreeViewModule } from "@progress/kendo-angular-treeview";
import { Configuration, Logger, LogLevel, CryptoUtils } from "msal";
import { TranslationService } from "@services/translation/translation.service";
import { UserPreferencesService } from "@services/user-preferences/user-preferences.service";
import {
  CldrIntlService,
  IntlModule,
  IntlService,
} from "@progress/kendo-angular-intl";
import { CommonModule, registerLocaleData } from "@angular/common";

import "@progress/kendo-angular-intl/locales/en/all";
import "@progress/kendo-angular-intl/locales/fr/all";
import "@progress/kendo-angular-intl/locales/de/all";
import "@progress/kendo-angular-intl/locales/es/all";
import "@progress/kendo-angular-intl/locales/it/all";
import "@progress/kendo-angular-intl/locales/ja/all";
import "@progress/kendo-angular-intl/locales/pt/all";
import "@progress/kendo-angular-intl/locales/zh/all";
import localeEn from "@angular/common/locales/en";
import localeFr from "@angular/common/locales/fr";
import localeDe from "@angular/common/locales/de";
import localeEs from "@angular/common/locales/es";
import localeIt from "@angular/common/locales/it";
import localeJa from "@angular/common/locales/ja";
import localePtBr from "@angular/common/locales/pt";
import localeZh from "@angular/common/locales/zh";
import { AppRoutingModule } from "./app-routing.module";
import { LabelModule } from "@progress/kendo-angular-label";
import { RomePopUpModule } from "@ui-components/rome-pop-up-module/rome-pop-up-module";
import { NgxUiLoaderModule } from "ngx-ui-loader";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { RomeTooltipComponent } from "@ui-components/rome-tooltip/rome-tooltip/rome-tooltip.component";
import { IdleWatchService } from "@services/idle-watch/idle-watch.service";
import { GoogleAnalyticsService } from "@services/google-analytics/google-analytics.service";
import { ProductDescriptionService } from "@services/products/product-description/product-description.service";
import { DisplayProductDescriptionPipe } from "@shared/pipes/productDescription/displayProductDescriptionPipe";
import { CachingInterceptorService } from "@services/interceptors/caching-interceptor.service";

registerLocaleData(localeEn);
registerLocaleData(localeFr);
registerLocaleData(localeDe);
registerLocaleData(localeEs);
registerLocaleData(localeIt);
registerLocaleData(localeJa);
registerLocaleData(localePtBr);
registerLocaleData(localeZh);

export function loadEnvironmentConfigService(
  configService: AppConfigService,
  loggingService: LoggingService,
) {
  return (): Promise<any> => {
    return configService.loadEnvironmentConfig().then(() => {
      loggingService.initializeConnectionString(
        configService.getAppConfig().appInsightsConnectionString,
        retrieveDomain(configService.getAppConfig().baseUrl),
        configService.getAppConfig().aiCloudRole,
      );
    });
  };
}

export function retrieveDomain(url: string): string {
  var hostname = "";

  // remove protocol
  if (url.indexOf("//") > -1) {
    hostname = url.split("/")[2];
  } else {
    hostname = url.split("/")[0];
  }
  hostname = hostname.split(":")[0]; // remove possible port

  var domains = hostname.split(".");
  if (domains.length > 1) {
    hostname = domains[domains.length - 2] + "." + domains[domains.length - 1];
  }
  return hostname;
}

export function msalConfigFactory(
  configService: AppConfigService,
): Configuration {
  const configuration: any = {
    auth: {
      clientId: configService.config.authentication.clientID,
      authority: configService.config.authentication.authority,
      redirectUri: configService.config.authentication.redirectUri,
      postLogoutRedirectUri:
        configService.config.authentication.postLogoutRedirectUri,
      navigateToLoginRequestUrl:
        configService.config.authentication.navigateToLoginRequestUrl,
      validateAuthority: configService.config.authentication.validateAuthority,
    },
    cache: {
      cacheLocation: configService.config.authentication.cacheLocation,
      storeAuthStateInCookie: false,
    },
    system: {},
  };

  if (configService.config.authentication.enableLogging) {
    configuration.system.logger = new Logger(
      (logLevel, message, piiEnabled) => {
        console.log(message);
      },
      {
        correlationId: CryptoUtils.createNewGuid(),
        level: LogLevel.Verbose,
        piiLoggingEnabled: configService.config.authentication.enablePiiLogging,
      },
    );
  }

  return configuration as Configuration;
}

export function msalAngularConfigFactory(
  configService: AppConfigService,
): MsalAngularConfiguration {
  const msalAngularConfiguration = {
    consentScopes: configService.config.authentication.consentScopes,
    popUp: configService.config.authentication.popUp,
    unprotectedResources:
      configService.config.authentication.unprotectedResources,
    protectedResourceMap:
      configService.config.authentication.protectedResourceMap,
  };
  return msalAngularConfiguration as MsalAngularConfiguration;
}

export function TranslateCacheFactory(
  translateService: TranslateService,
  translateCacheSettings: TranslateCacheSettings,
) {
  return new TranslateCacheService(translateService, translateCacheSettings);
}

@NgModule({
  declarations: [AppComponent, DirtyPopupComponent, IdleWatchPopupComponent],
  imports: [
    AppRoutingModule,
    CommonModule,
    HttpClientModule,
    DialogModule,
    MenuModule,
    BrowserAnimationsModule,
    IntlModule,
    RomePopUpModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useClass: TranslationService,
        deps: [HttpClient],
      },
    }),
    TranslateCacheModule.forRoot({
      cacheService: {
        provide: TranslateCacheService,
        useFactory: TranslateCacheFactory,
        deps: [TranslateService, TranslateCacheSettings],
      },
    }),
    CoreModule,
    SchedulerModule,
    ButtonsModule,
    TreeViewModule,
    LabelModule,
    NgxUiLoaderModule,
    RomeTooltipModule,
  ],
  providers: [
    AuthorisationService,
    GoogleAnalyticsService,
    IdleWatchService,
    ProductDescriptionService,
    AppConfigService,
    MsalModule,
    MsalInterceptor,
    MsalService,
    BroadcastService,
    {
      provide: APP_INITIALIZER,
      useFactory: loadEnvironmentConfigService,
      deps: [AppConfigService, LoggingService],
      multi: true,
    },
    {
      provide: MSAL_CONFIG,
      useFactory: msalConfigFactory,
      deps: [AppConfigService],
    },
    {
      provide: MSAL_CONFIG_ANGULAR,
      useFactory: msalAngularConfigFactory,
      deps: [AppConfigService],
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: RomeInterceptorService,
      deps: [
        MsalService,
        Router,
        AuthorisationService,
        AppConfigService,
        HttpXsrfTokenExtractor,
        IdleWatchService,
      ],
      multi: true,
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CachingInterceptorService,
      deps: [AuthorisationService, AppConfigService],
      multi: true,
    },
    LoggingService,
    {
      provide: ErrorHandler,
      useClass: ErrorHandlerService,
    },
    UserPreferencesService,
    CldrIntlService,
    {
      provide: IntlService,
      useExisting: CldrIntlService,
    },
    {
      provide: LOCALE_ID,
      useValue: "en-US",
    },
    DisplayProductDescriptionPipe,
  ],
  exports: [TranslateModule],
  bootstrap: [AppComponent],
  entryComponents: [
    DirtyPopupComponent,
    IdleWatchPopupComponent,
    RomeTooltipComponent,
  ],
})
export class AppModule {}
