export class UserStatus {
    public userStatusId: number;
    public description: string;
}
