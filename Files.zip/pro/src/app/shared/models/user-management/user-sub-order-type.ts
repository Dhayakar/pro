export class UserSubOrderType {
    public romeUserId: number;
    public fullName: string;
    public isInternal: boolean;
    public subOrderTypes: UserSubOrderTypeItem[];
    public isExternalClinicalUser: boolean;

}

export class UserSubOrderTypeItem {
    public id : number;
    public subOrderTypeId : number;
    public subOrderTypeDescription: string;
    public subOrderCategoryTypeId : number;
    public subOrderCategoryTypeDescription: string;
    public subOrderTypeActive: boolean;
    public productTypeId : number;
    public productTypeDescription: string;
    public axEntityTypeId : number;
    public axEntityTypeDescription: string;
    public axEntityTypeLongDescription: string;
    public deliveryAddressId : number;
    public deliveryAddressDescription: string;
    public organizationId: number;
    public organizationDescription: string;
    public viewAccess: boolean;
    public writeAccess: boolean;
    public accountActive: boolean;
    public isDisabled: boolean;
    public isWriteAccessDisabled: boolean;
}

export class UserSubOrderTypeFilter {
    public axEntityTypeIds: number[];
    public productTypeIds: number[];
    public subOrderTypeDescriptions: string[];
    public subOrderCategoryTypeIds: number[];
    public organizationIds: number[];
    public deliveryAddressIds: number[];
    public statuses: boolean[];

    constructor() {
        this.axEntityTypeIds = [];
        this.productTypeIds = [];
        this.subOrderTypeDescriptions = [];
        this.subOrderCategoryTypeIds = [];
        this.organizationIds = [];
        this.deliveryAddressIds = [];
        this.statuses = [];
    }
}

export class UserSubOrderTypeCommand {
    public romeUserId: number;
    public subOrderTypes: UserSubOrderTypeItemCommand[];

    constructor(userSubOrderType: UserSubOrderType) {
        this.romeUserId = userSubOrderType.romeUserId;
        this.subOrderTypes = userSubOrderType.subOrderTypes.map(i => new UserSubOrderTypeItemCommand(i));
    }
}

export class UserSubOrderTypeItemCommand {
    public id : number;
    public subOrderTypeId : number;
    public productTypeId : number;
    public axEntityTypeId : number;
    public deliveryAddressId : number;
    public viewAccess: boolean;
    public writeAccess: boolean;
    public isDisabled: boolean;

    constructor(userSubOrderTypeItem: UserSubOrderTypeItem) {
        this.id = userSubOrderTypeItem.id;
        this.subOrderTypeId = userSubOrderTypeItem.subOrderTypeId;
        this.productTypeId = userSubOrderTypeItem.productTypeId;
        this.axEntityTypeId = userSubOrderTypeItem.axEntityTypeId;
        this.deliveryAddressId = userSubOrderTypeItem.deliveryAddressId;
        this.viewAccess = userSubOrderTypeItem.viewAccess;
        this.writeAccess = userSubOrderTypeItem.writeAccess;
        this.isDisabled = userSubOrderTypeItem.isDisabled;
    }
}
