import { CreatedUpdatedUserHistory } from '../history/created-updated-user-history';
import { HistoryCategory } from '../history/history-category';
import { UserHistoryItem } from '../history/user-history-item';


export class UserHistory {
  orderHistoryId: number;
  orderId: number;
  createdUpdatedDate: Date;
  statusChangeExplanation: string;
  changes: Array<UserHistoryItem>;
  createdUpdatedBy: CreatedUpdatedUserHistory;
  historyCategory: HistoryCategory;
  organizationChanges: Array<OrganizationChange>;
}

export class OrganizationChange {
  organizationId: number;
  organizationDescription: string;
  action: number;
}

export class UserHistoryModel {
  userFullName: string;
  userHistories: Array<UserHistory>;
}