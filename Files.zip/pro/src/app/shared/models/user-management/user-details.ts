export class UserDetailsList {
  constructor(public userList: UserDetails[]) {}
}

export class UserDetails {
  public romeUserId: number;
  public firstName: string;
  public lastName: string;
  public email: string;
  public primaryPhoneNumber: string;
  public secondaryPhoneNumber: string;
  public organization: Organization[];
  public activeStatusIndicator: boolean;
  public userStatusId: number;
  public description: string;
  get fullName(): string {
    return this.firstName + " " + this.lastName;
  }
  isExternalClinicalTrialUser: boolean;
}

class Organization {
  organizationId: number;
  description: string;
  statusId: number;
  usersPermissions: UserPermissions[];
}

class UserPermissions {
  public readOnly: boolean;
  public deliveryAddress: DeliveryAddress;
  customerSuperUserPermission: boolean;
}

class DeliveryAddress {
  deliveryAddressId: number;
  axLocationId: string;
  description: string;
  zipCode: string;
  street: string;
  city: string;
  county: string;
  country: string;
  state: string;
  timeZoneTypeId: number;
  blanketPO: string;
  activeStatusIndicator: boolean;
}

export class InstitutionPermission {
  organization: string;
  deliveryAddress: string;
  permission: string;
}

export class GroupedInstitutionPermission {
  organizationName: string;
  institutionPermission: InstitutionPermission[];
}

export class AdarTerritoryModel {
  adarTerritoryId: number;
  adarDescription: string;
  active: boolean;
}
