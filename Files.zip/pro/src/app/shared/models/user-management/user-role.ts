import { axEntityTypeDropdown } from "../lookup-types/lookup";

export class UserRole {
  public role: Role;
  public allEntities: boolean;
  public entities: axEntityTypeDropdown[];

  constructor(role: Role) {
    this.role = role;
    this.entities = [];
  }
}

export class Role {
  public value: number;
  public text: string;
  public isSystemAdmin: boolean;
  public isActive: boolean;
  public isSelected: boolean;
  public name: string;

  constructor(
    value: number,
    text: string,
    isSystemAdmin: boolean,
    isActive: boolean,
    name: string,
  ) {
    this.value = value;
    this.text = text;
    this.isSystemAdmin = isSystemAdmin;
    this.isActive = isActive;
    this.isSelected = false;
    this.name = name;
  }
}
