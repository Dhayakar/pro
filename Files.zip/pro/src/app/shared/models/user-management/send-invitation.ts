import { UserList } from '../UsersList';

export class SendInvitation {
    users: SendInvitationUser[];

    constructor() {
        this.users = [];
    }
}

export class SendInvitationUser {
    userId: number;
    firstName: string;
    lastName: string;
    email: string;

    constructor(user: UserList) {
        this.userId = user.romeUserId;
        this.email = user.email;
        this.firstName = user.firstName;
        this.lastName = user.lastName;
    }
}