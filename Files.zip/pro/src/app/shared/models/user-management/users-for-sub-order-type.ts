export class GetUsersForAccountSubOrderTypesQuery {
    romeUserIds: number[];
    accountId: number;
    subOrderTypeId: number;

    constructor(romeUserIds: number[], accountId: number, subOrderTypeId: number) {
        this.romeUserIds = romeUserIds;
        this.accountId = accountId;
        this.subOrderTypeId = subOrderTypeId;
    }
}

export class UsersForAccountSubOrderTypesModel {
    romeUserIds: number[];
}