import { UserSubOrderType, UserSubOrderTypeItem } from "./user-sub-order-type";

export class OrdersForSubOrderTypes {
  romeUserId: number;
  updatedSubOrderTypes: UpdatedSubOrderType[];

  constructor(userSubOrderType: UserSubOrderType) {
    this.romeUserId = userSubOrderType.romeUserId;
    this.updatedSubOrderTypes = userSubOrderType.subOrderTypes.map((sub) => {
      return new UpdatedSubOrderType(sub);
    });
  }
}

export class UpdatedSubOrderType {
  userSubOrderTypeId: number;
  writeAccess: boolean;

  constructor(sub: UserSubOrderTypeItem) {
    this.userSubOrderTypeId = sub.id;
    this.writeAccess = sub.writeAccess;
  }
}

export class OrdersForSubOrderTypesModel {
  productTypeIds: number[];
  institutionIds: number[];
  deliveryAddressIds: number[];
  orderStatusTypeIds: number[];
  subOrderTypeIds: number[];
}
