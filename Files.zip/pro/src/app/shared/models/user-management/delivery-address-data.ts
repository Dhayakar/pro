import { DeliveryAddress } from '../lookup-types/delivery-address-lookup';

export class DeliveryAdressGroup {
    constructor(deliveryAddressData: DeliveryAddressData[]) {}
}

export class DeliveryAddressData {
    organizationId: number;
    description: string;
    statusId: number;
    deliveryAddresses: DeliveryAddress[];
}

