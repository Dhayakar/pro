export class EmailValidation {
    valid: boolean;
    email: string;
}