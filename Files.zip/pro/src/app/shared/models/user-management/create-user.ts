import {
  DeliveryAddressPermissionGroup,
  UpdatedEntityUserPermission,
  UpdatedUserPermission,
} from "src/app/modules/administration/user-management/create-edit-user-shared-fields/models/user-permission-groups";
import { CreateEditUserDetails } from "src/app/modules/administration/user-management/create-edit-user-shared-fields/models/create-edit-user-details";

export class CreateUserDetails {
  public romeUserId: number;
  public firstName: string;
  public lastName: string;
  public lastSignInDate: Date;
  public email: string;
  public primaryPhoneNumber: string;
  public secondaryPhoneNumber: string;
  public activeStatusIndicator: boolean;
  public statusChangeExplanation: string;
  public isDistributor: boolean;
  public userStatusId: number;
  public primaryEntityId: number;
  public defaultEntityId: number;
  public countryRegion: string;
  public shouldApprove: boolean;
  public shouldDecline: boolean;
  public selectedLanguage: string;
  public preferredLanguageId: number;
  public preferredTimePatternId: number;
  public isExternalClinicalTrialUser: boolean;
  public isCrossEntity: boolean;
  public isChinaDistributor: boolean;

  public axEntityTypeIds: number[] = [];
  public usersPermissions: Array<UpdatedUserPermission> = [];
  public captchaResponse: string;
  public userProducts: number[];

  constructor(userDetails: CreateEditUserDetails) {
    this.romeUserId = userDetails.romeUserId;
    this.firstName = userDetails.firstName;
    this.lastName = userDetails.lastName;
    this.lastSignInDate = userDetails.lastSignInDate;
    this.email = userDetails.email;
    this.primaryPhoneNumber = userDetails.primaryPhoneNumber;
    this.secondaryPhoneNumber = userDetails.secondaryPhoneNumber;
    this.activeStatusIndicator = userDetails.activeStatusIndicator;
    this.statusChangeExplanation = userDetails.statusChangeExplanation;
    this.isDistributor = userDetails.isDistributor;
    this.userStatusId = userDetails.userStatusId;
    this.primaryEntityId = userDetails.primaryEntityId;
    this.defaultEntityId = userDetails.defaultEntityId;
    this.shouldApprove = userDetails.shouldApprove;
    this.shouldDecline = userDetails.shouldDecline;
    this.preferredLanguageId = userDetails.preferredLanguageId;
    this.preferredTimePatternId = userDetails.preferredTimePatternId;
    this.userProducts = userDetails.userProducts;
    this.isExternalClinicalTrialUser = userDetails.isExternalClinicalTrialUser;
    this.isCrossEntity = userDetails.isCrossEntity;
    this.isChinaDistributor = userDetails.isChinaDistributor;

    this.axEntityTypeIds = [];
    this.usersPermissions = [];

    for (let axEntityType of userDetails.userRoleEntities)
      this.axEntityTypeIds.push(axEntityType.axEntityTypeId);

    for (let entity of userDetails.entityPermissionGroups) {
      for (let prod of entity.productPermissionGroups) {
        for (let org of prod.institutionPermissionGroups) {
          for (let permission of org.deliveryAddressPermissionGroups)
            this.addPermission(permission, entity.entity.axEntityTypeId);
        }
      }
    }
  }

  private addPermission(
    permissionGroup: DeliveryAddressPermissionGroup,
    axEntityTypeId: number,
  ) {
    let permission = new UpdatedUserPermission(permissionGroup, axEntityTypeId);
    this.usersPermissions.push(permission);
  }
}
export class UpdateUserDetails {
  romeUserId: number;
  firstName: string;
  lastName: string;
  email: string;
  activeStatusIndicator: boolean;
  primaryPhoneNumber: string;
  secondaryPhoneNumber: string;

  userPermissionAccountIdsToRemove: number[];
  updatedUserPermissions: UpdatedUserPermission[];
  updatedAxEntityIdPermissions: UpdatedEntityUserPermission[];

  statusChangeExplanation: string;
  axEntityTypeIds: number[] = [];
  isDistributor: boolean;
  userStatusId: number;
  primaryEntityId: number;
  defaultEntityId: number;
  shouldApprove: boolean;
  shouldDecline: boolean;
  preferredLanguageId: number;
  preferredTimePatternId: number;
  userProducts: number[];
  isExternalClinicalTrialUser: boolean;
  isCrossEntity: boolean;
  isChinaDistributor: boolean;

  constructor(
    userDetails: CreateEditUserDetails,
    userPermissionAccountIdsToRemove: number[],
    updatedPermissionsToSave: UpdatedUserPermission[],
    updatedAxEntityIdPermissions: UpdatedEntityUserPermission[],
  ) {
    this.romeUserId = userDetails.romeUserId;
    this.firstName = userDetails.firstName;
    this.lastName = userDetails.lastName;
    this.email = userDetails.email;
    this.primaryPhoneNumber = userDetails.primaryPhoneNumber;
    this.secondaryPhoneNumber = userDetails.secondaryPhoneNumber;
    this.activeStatusIndicator = userDetails.activeStatusIndicator;
    this.statusChangeExplanation = userDetails.statusChangeExplanation;
    this.isDistributor = userDetails.isDistributor;
    this.userStatusId = userDetails.userStatusId;
    this.primaryEntityId = userDetails.primaryEntityId;
    this.defaultEntityId = userDetails.defaultEntityId;
    this.shouldApprove = userDetails.shouldApprove;
    this.shouldDecline = userDetails.shouldDecline;
    this.preferredLanguageId = userDetails.preferredLanguageId;
    this.preferredTimePatternId = userDetails.preferredTimePatternId;
    this.userProducts = userDetails.userProducts;
    this.isExternalClinicalTrialUser = userDetails.isExternalClinicalTrialUser;
    this.isCrossEntity = userDetails.isCrossEntity;
    this.isChinaDistributor = userDetails.isChinaDistributor;

    this.axEntityTypeIds = userDetails.userRoleEntities.map(
      (ure) => ure.axEntityTypeId,
    );
    this.userPermissionAccountIdsToRemove = userPermissionAccountIdsToRemove;
    this.updatedUserPermissions = updatedPermissionsToSave;
    this.updatedAxEntityIdPermissions = updatedAxEntityIdPermissions;
  }
}
