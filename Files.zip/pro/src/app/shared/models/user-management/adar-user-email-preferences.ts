export class AdarUserEmailPreferences {
  public adarTerritoryIds: number[];
  public emailPreferences: AdarEmailPreference[];
}

export class AdarEmailPreference {
  public adarEmailPreferenceId: number;
  public emailTemplateTypeId: number;
  public product: string;
  public emailTemplateType: string;
  public active: boolean;
  public isDisabled: boolean;
}
