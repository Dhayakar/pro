import { AdarTerritoryModel } from "./user-details";
import { UserRole } from "./user-role";

export class InternalUser {
  public firstName: string;
  public lastName: string;
  public email: string;
  public userRoles: UserRole[];
  public status: boolean;
  public isCrossEntity: boolean;
  public preferredLanguageId: number;
  public preferredTimePatternId: number;
  public primaryEntityId: number;
  public defaultEntityId: number;
  public userProducts: number[];
  public userProductsDescription: string;
  public primaryEntityDescription: string;
  public defaultEntityDescription: string;
  public lastSignInDate: Date;
  public userAdarTerritories: number[];
  public userAdarTerritoriesDescription: string;
  public adarTerritories: AdarTerritoryModel[];
  constructor() {
    this.firstName = "";
    this.lastName = "";
    this.email = "";
    this.userProductsDescription = "";
    this.userRoles = [];
    this.status = false;
    this.isCrossEntity = false;
    this.userProducts = [];
    this.primaryEntityDescription = "";
    this.userAdarTerritories = [];
    this.userAdarTerritoriesDescription = "";
  }
}
