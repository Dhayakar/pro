import { NumberValueAccessor } from '@angular/forms';

export class Policy {
    policiesReferenceMaterialsEntityId: number;
    content: string;
    axEntityTypeId: number;
    policiesReferenceMaterialsAttachments: PolicyReferenceMaterialAttachment[];

    constructor() {
        this.policiesReferenceMaterialsEntityId = 0;
        this.content = "";
        this.axEntityTypeId = 0;
        this.policiesReferenceMaterialsAttachments = [];
    }
}

export class PolicyReferenceMaterialAttachment {
    policiesReferenceMaterialsAttachmentId: number;
    fileName: string;
    originalFileName: string;

    constructor(policiesReferenceMaterialsAttachmentId: number, fileName: string, originalFileName: string){
        this.policiesReferenceMaterialsAttachmentId = policiesReferenceMaterialsAttachmentId;
        this.fileName = fileName;
        this.originalFileName = originalFileName;
    }
}

export class PolicyDetail {
    policiesReferenceMaterialsEntityId: number;
    content: string;
    axEntityTypeId: number;
    existingAttachmentIds: number[];
    language: string;

    constructor(policiesReferenceMaterialsEntityId: number,
        content: string,
        existingAttachmentIds: number[],
        language: string) {
            this.policiesReferenceMaterialsEntityId = policiesReferenceMaterialsEntityId;
            this.content = content;
            this.existingAttachmentIds = existingAttachmentIds;
            this.language = language;
    }
}