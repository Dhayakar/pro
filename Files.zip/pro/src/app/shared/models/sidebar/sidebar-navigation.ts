export class SidebarNavigation {
  name: string;
  navigationUrl: string;
  parentUrl: string;
  constructor(name: string, navigationUrl: string) {
    this.name = name;
    this.navigationUrl = navigationUrl;
    this.parentUrl = navigationUrl;
  }

}


export class SidebarItem {
  name: string;
  headerLookup: boolean;
  url: string;
  singleMenu: boolean;
  permissions: string[];
  subItems: SidebarItem[]
}
