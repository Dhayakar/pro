export class AllProductsModel {
  productTypeId: number;
  description: string;
  commercialDescription: string;
  clinicalTrialDescription: string;
}
