export class UserResearchAccess {
  hasRAndDCategory: boolean;
  hasNonRAndDCategory: boolean;
}
