import { formatDate } from '@angular/common';
import { CreateBlock } from './orders/calendar/create-block';

export class BlockDatesCommandModel {

    public injectionDateBlocks: CreateBlockModel[];
    public deliveryDateBlocks: CreateBlockModel[];
    public productionDateBlocks: CreateBlockModel[];

    constructor(inputInjectionBlocks: CreateBlock[], inputDeliveryBlocks: CreateBlock[], inputProductionBlocks: CreateBlock[]) {
        this.injectionDateBlocks = inputInjectionBlocks.map(block => new CreateBlockModel(block));
        this.deliveryDateBlocks = inputDeliveryBlocks.map(block => new CreateBlockModel(block));
        this.productionDateBlocks = inputProductionBlocks.map(block => new CreateBlockModel(block));
    }
}

export class CreateBlockModel {
    public dateString: string;
    public explanation: string;
    public warehouseId: number;
    public productTypeIds: number[];
 
    constructor(block: CreateBlock) {
        this.dateString = formatDate(block.date, "yyyy-MM-dd", "en-US")
        this.explanation = block.explanation;
        this.warehouseId = block.warehouseId;
        this.productTypeIds = block.productTypeIds;
    }
}
