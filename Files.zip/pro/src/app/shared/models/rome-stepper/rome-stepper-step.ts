import { TemplateRef } from "@angular/core";

export class RomeStepperStep {
    key: string;
    label: string;
    isHidden: boolean;
    isClickable: boolean;
    template: TemplateRef<any>;

    constructor(key: string, label: string, isHidden: boolean = false, isClickable: boolean = false, template: TemplateRef<any> = null) {
        this.key = key;
        this.label = label;
        this.isHidden = isHidden;
        this.isClickable = isClickable;
        this.template = template;
    }
}