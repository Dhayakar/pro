export class UnblockDateCommandModel {    
    public dateToUnblock: string;
    public explanation: string;
    public blockType: number;
    public warehouseId: number;
    public productTypeIds: number[];

    constructor(dateToUnblock: string, explanation: string, blockType: number, warehouseId: number, productTypeIds: number[]) {
        this.dateToUnblock = dateToUnblock;
        this.explanation = explanation;
        this.blockType = blockType;
        this.warehouseId = warehouseId;
        this.productTypeIds = productTypeIds;
    }
}