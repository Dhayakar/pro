export class RomeContactsViewModel {
    romeContactId: number;
    contactName: string;
    contactEmail: string;
    contactPhoneNumber: string;

    constructor(romeContactId?: number,
        contactName?: string,
        contactEmail?: string,
        contactPhoneNumber?: string) {
            this.romeContactId = romeContactId;
            this.contactName = contactName;
            this.contactEmail = contactEmail;
            this.contactPhoneNumber = contactPhoneNumber;
    }
}