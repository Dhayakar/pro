export class RomeContact {
    romeContactId: number;
    parentObjectId: number;
    parentObjectTypeId: number;
    contactName: string;
    contactEmail: string;
    contactPhoneNumber: string;

    constructor(romeContactId?: number,
        parentObjectId?: number,
        parentObjectTypeId?: number,
        contactName?: string,
        contactEmail?: string,
        contactPhoneNumber?: string) {
            this.romeContactId = romeContactId;
            this.parentObjectId = parentObjectId;
            this.parentObjectTypeId = parentObjectTypeId;
            this.contactName = contactName;
            this.contactEmail = contactEmail;
            this.contactPhoneNumber = contactPhoneNumber;
    }
}