import { OrganizationTypeEnum } from "@shared/enums/organization-type-enum";
import { RamLicenseStatusEnum } from "@shared/enums/ram-license-status-enum";

export class InstitutionsFilteredModel {
  institutions: InstitutionFilteredItemModel[];
  totalInstitutionsCount: number;
}

export class InstitutionFilteredItemModel {
  organizationId: number;
  description: string;
  deliveryAddresses: DeliveryAddressModel[];
  possessionLimitMci: number;
  expirationDate: Date;
  statusId: number;
}

export class DeliveryAddressModel {
  deliveryAddressId: number;
  productCategory: string;
  accountId: number;
  description: string;
  product: string;
  productId: number;
  active: boolean;
  ramLicenseStatus: RamLicenseStatusEnum;
  ramLicenseId: number;
  ramLicenseOrderType: RamLicenseOrderTypeModel;
  regionId: number;
  regionDescription: string;
}

export class RamLicenseOrderTypeModel {
  ramLicenseOrderTypeId: number | null;
  orderTypeAssigned: boolean;
}

export class InstitutionFilterRequest {
  axCustomerAccountId: string;
  organizationType: OrganizationTypeEnum;
  nrcRamLicenseId: string;
  institutionIds: number[];
  deliveryAddressIds: number[];
  productTypeIds: number[];
  accountStatuses: boolean[];
  institutionStatusIds: number[];
  ramLicenseStatusIds: number[];
  orderTypeIds: number[];
  states: string[];
  cities: string[];
  zipcode: string;
  regionIds: number[];

  constructor() {
    this.axCustomerAccountId = "";
    this.organizationType = null;
    this.nrcRamLicenseId = "";
    this.institutionIds = [];
    this.deliveryAddressIds = [];
    this.productTypeIds = [];
    this.accountStatuses = [];
    this.institutionStatusIds = [];
    this.ramLicenseStatusIds = [];
    this.orderTypeIds = [];
    this.states = [];
    this.cities = [];
    this.zipcode = "";
    this.regionIds = [];
  }

  public clear() {
    this.axCustomerAccountId = "";
    this.organizationType = null;
    this.nrcRamLicenseId = "";
    this.institutionIds = [];
    this.deliveryAddressIds = [];
    this.productTypeIds = [];
    this.accountStatuses = [];
    this.institutionStatusIds = [];
    this.ramLicenseStatusIds = [];
    this.orderTypeIds = [];
    this.states = [];
    this.cities = [];
    this.zipcode = "";
    this.regionIds = [];
  }
}
