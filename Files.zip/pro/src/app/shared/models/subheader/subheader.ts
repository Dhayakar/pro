import { ProductTypeCategoryEnum } from "@shared/enums/product-type-category-enum";

export class SubHeader {
    name: string;
    url: string;
    description: string;
    subDescription: string;
    permissions: string[];
    subItems: SubHeader[];
    hideForProductCategories: ProductTypeCategoryEnum[];
    optionalHide: boolean;

    constructor(name: string, url: string, description: string, subDescription: string, permissions: string[],
        subItems: SubHeader[] = [], hideForProductCategories: ProductTypeCategoryEnum[] = []) {
        this.name = name;
        this.url = url;
        this.description = description;
        this.subDescription = subDescription;
        this.permissions = permissions;
        this.subItems = subItems;
        this.hideForProductCategories = hideForProductCategories;
    }
}