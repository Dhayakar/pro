import { SubHeader } from './subheader';

export class Header {
  name: string;
  items: SubHeader[];
  constructor(name: string, items: SubHeader[]) {
      this.name = name;
      this.items = items;
  }
}
