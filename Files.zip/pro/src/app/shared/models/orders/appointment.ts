import { OrderStatusType } from './order-status-type';

export class Appointment {
    public id: number;
    public doseNumber: any;
    public additionalDoseNumber: number;
    public additionalDoseIndicator: boolean;
    public additionalDoseReason: string;
    public injectionDate: Date;
    public orderStatusType: OrderStatusType;
    public possessionLimitExceeded: boolean = false;
    public papVoucherCode: string;
    constructor(doseNumber?: number) {
        this.doseNumber = doseNumber;
    }
}
