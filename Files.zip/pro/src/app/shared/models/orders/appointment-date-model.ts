export class AppointmentDateModel {
    deliveryDate: Date;
    injectionDate: Date;
    originalStatusId: number;

    constructor(deliveryDate: Date, injectionDate: Date, originalStatusId: number = null) {
        this.deliveryDate = deliveryDate;
        this.injectionDate = injectionDate;
        this.originalStatusId = originalStatusId;
    }
}