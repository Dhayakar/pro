import { SafeHtml } from "@angular/platform-browser";

export class BlockDates {
  entityBlocks: EntityBlocks;
  warehouseBlocks: WarehouseBlocksModel;
}

export class EntityBlocks {
  injectionDateBlocks: EntityBlocksForDateModel[];
  deliveryDateBlocks: EntityBlocksForDateModel[];
}

export class WarehouseBlocksModel {
  injectionDateBlocks: WarehouseBlocksForDateModel[];
  deliveryDateBlocks: WarehouseBlocksForDateModel[];
  productionDateBlocks: WarehouseBlocksForDateModel[];
}
export abstract class BlockDateModel {
  date: Date;
}

export class EntityBlocksForDateModel extends BlockDateModel {
  entities: AreaProductModel[];
}

export class WarehouseBlocksForDateModel extends BlockDateModel {
  warehouses: WarehouseProductModel[];
}

export class AreaProductModel {
  description: string;
  products: ProductModel[];
}

export class WarehouseProductModel extends AreaProductModel {
  warehouseId: number;

  constructor(
    warehouseId: number,
    description: string,
    products: ProductModel[],
  ) {
    super();
    this.warehouseId = warehouseId;
    this.description = description;
    this.products = products;
  }
}

export class ProductModel {
  productTypeId: number;
  description: string;
  explanation: string;
  isCapacityBlock: boolean;
  isOnlyCapacityBlock: boolean = false;

  constructor(productTypeId: number, description: string) {
    this.productTypeId = productTypeId;
    this.description = description;
  }
}
