export class AxPricingGroupCategory {
    constructor(public id: number,
        public description: string) {

    }
}