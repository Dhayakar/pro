import { CreatedUpdatedUserHistory } from '../history/created-updated-user-history';
import { HistoryCategory } from '../history/history-category';

export class BlockDateHistory {
  blockDate: Date;
  blockType: number;
  createdUpdatedDate: Date;
  createdUpdatedBy: CreatedUpdatedUserHistory;
  historyCategory: HistoryCategory;
}
