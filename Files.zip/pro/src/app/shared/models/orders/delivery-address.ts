import { BlockOrderStatusEnum } from "@shared/enums/block-order-status-enum";
import { TimeZoneType } from "./time-zone-type";

export class DeliveryAddress {
  constructor(
    public id: number,
    public description: string,
    public timeZoneType: TimeZoneType = null,
    public isSelected: boolean = false,
    public fullDescription: string = null,
    public fullDescriptionWithAddressName: string = null,
    public hasActiveRamLicense: boolean = false,
    public isRamLicenseExpiring: boolean = false,
    public ramLicenseExpiryDate: Date = null,
    public ramLicenseExpiringInDays: number = null,
    public orderTypeIds: number[] = null,
    public blockOrderStatus: BlockOrderStatusEnum = BlockOrderStatusEnum.NO_BLOCK,
    public adarTerritoryId: number = null,
  ) {}
}
