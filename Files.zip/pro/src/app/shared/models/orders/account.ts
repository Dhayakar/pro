import { BlockOrderStatusEnum } from "@shared/enums/block-order-status-enum";
import { CreateOrderAccount } from "./create/create-order-account";
import { AxEntityType } from "../ax-entity-types/ax-entity-type";

export class Accounts {
  constructor(public accounts: Account[]) {}
}

export class Account extends CreateOrderAccount {
  public axCustomerNumber: string;
  public deactivationDate: Date;
  public blockOrderStatus: BlockOrderStatusEnum;
  public axEntityType: AxEntityType;
}
