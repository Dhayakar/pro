export class CustomerFeedback {

    constructor(
        public rating: number,
        public comment: string,
        public orderId: number,
    ) {
    }
}