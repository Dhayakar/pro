export class InitialPurpose  {
    constructor(public initialPurposeTypeId: number,
      public description: string) {
  
    }
  }