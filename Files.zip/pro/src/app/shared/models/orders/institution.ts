export class Institution  {
    constructor(public organizationId: number,
      public description: string) {
  
    }
  }