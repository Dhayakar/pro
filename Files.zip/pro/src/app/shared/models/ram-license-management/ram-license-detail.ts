import { RamLicenseVersionTypeEnum } from "@shared/enums/ram-license-version-type-enum";
import {
  CreateRamLicenseModel,
  LineItem,
  LineItemAccountOrderType,
} from "./ram-license";
import { RomeContactsViewModel } from "../rome-contacts-management/rome-contacts-view-model";

export class CreateRamLicenseDetailModel {
  nrcRamLicenseId: string;
  expiryDate: string;
  authorisedUsers: string[];
  comment: string;
  lineItems: LineItem[];
  contacts: RomeContactsViewModel[];
  versionNumber: number;

  constructor(
    nrcRamLicenseId: string,
    expiryDate: string,
    authorisedUsers: string[],
    comment: string,
    lineItems: LineItem[],
    contacts: RomeContactsViewModel[],
    versionNumber: number,
  ) {
    this.nrcRamLicenseId = nrcRamLicenseId;
    this.expiryDate = expiryDate;
    this.authorisedUsers = authorisedUsers;
    this.comment = comment;
    this.lineItems = lineItems;
    this.contacts = contacts;
    this.versionNumber = versionNumber;
  }
}

export class CreateRamLicenseVersionDetailModel {
  ramLicenseId: number;
  expiryDate: string;
  authorisedUsers: string[];
  comment: string;
  versionType: RamLicenseVersionTypeEnum;
  versionNumber: number;
  lineItems: EditLineItemDetailModel[];
  isFileUploadRequired: boolean;

  constructor(
    ramLicense: CreateRamLicenseModel,
    expiryDate: string,
    authorisedUser: string[],
    comment: string,
    versionType: RamLicenseVersionTypeEnum,
    versionNumber: number,
    isFileUploadRequired: boolean,
  ) {
    this.ramLicenseId = ramLicense.ramLicenseId;
    this.expiryDate = expiryDate;
    this.authorisedUsers = authorisedUser;
    this.comment = comment;
    this.versionType = versionType;
    this.versionNumber = versionNumber;
    this.lineItems = ramLicense.lineItems.map(
      (lineItem) => new EditLineItemDetailModel(lineItem),
    );
    this.isFileUploadRequired = isFileUploadRequired;
  }
}

export class EditRamLicenseDetailModel {
  ramLicenseId: number;
  nrcRamLicenseId: string;
  expiryDate: string;
  authorisedUsers: string[];
  versionNumber: number;
  comment: string;
  lineItems: EditLineItemDetailModel[];
  contacts: RomeContactsViewModel[];

  constructor(ramLicense: CreateRamLicenseModel, formattedExpiryDate: string) {
    this.ramLicenseId = ramLicense.ramLicenseId;
    this.nrcRamLicenseId = ramLicense.nrcRamLicenseId;
    this.expiryDate = formattedExpiryDate;
    this.authorisedUsers = ramLicense.authorisedUsers;
    this.versionNumber = ramLicense.version;
    this.comment = ramLicense.comment;
    this.lineItems = ramLicense.lineItems.map(
      (lineItem) => new EditLineItemDetailModel(lineItem),
    );
    this.contacts = ramLicense.contacts;
  }
}

export class EditLineItemDetailModel {
  ramLicenseLineItemId: number;
  possessionLimit: number;
  lineItemReference: string;
  productTypeIds: number[];
  accountOrderTypes: EditAccountOrderTypeDetailModel[];

  constructor(lineItem: LineItem) {
    this.ramLicenseLineItemId = lineItem.ramLicenseLineItemId;
    this.possessionLimit = lineItem.possessionLimit;
    this.lineItemReference = lineItem.lineItemReference;
    this.productTypeIds = lineItem.productTypeIds;
    this.accountOrderTypes = lineItem.lineItemAccountOrderTypes.map(
      (aot) => new EditAccountOrderTypeDetailModel(aot),
    );
  }
}

export class EditAccountOrderTypeDetailModel {
  accountId: number;
  accountActive: boolean;
  orderTypeId: number;

  constructor(lineItemAccountOrderType: LineItemAccountOrderType) {
    this.accountId = lineItemAccountOrderType.accountId;
    this.accountActive = lineItemAccountOrderType.accountActive;
    this.orderTypeId = lineItemAccountOrderType.orderTypeId;
  }
}
