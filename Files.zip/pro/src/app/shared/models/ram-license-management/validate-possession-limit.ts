import { CreateRamLicenseModel, LineItem, LineItemAccountOrderType } from "./ram-license";

export class ValidatePossessionLimitModel {
    ramLicenseId: number;
    lineItems: UpdatedLineItem[];

    constructor(ramLicense: CreateRamLicenseModel) {
        this.ramLicenseId = ramLicense.ramLicenseId;
        this.lineItems = ramLicense.lineItems.map(lineItem => new UpdatedLineItem(lineItem));
    }
}

export class UpdatedLineItem {
    ramLicenseLineItemId: number;
    possessionLimit: number;
    accountOrderTypes: UpdatedLineItemAccountOrderType[];

    constructor(lineItem: LineItem) {
        this.ramLicenseLineItemId = lineItem.ramLicenseLineItemId;
        this.possessionLimit = lineItem.possessionLimit;
        this.accountOrderTypes = lineItem.lineItemAccountOrderTypes.map(aot => new UpdatedLineItemAccountOrderType(aot))
    }
}

export class UpdatedLineItemAccountOrderType {
    accountId: number;
    orderTypeId: number;

    constructor(aot: LineItemAccountOrderType) {
        this.accountId = aot.accountId;
        this.orderTypeId = aot.orderTypeId;
    }
}