import { GetRamLicenseModel } from "./ram-license";

export class GetRamLicenseForDeliveryAddressModel {
    deliveryAddress: string;
    institutionId: number;
    ramLicense: GetRamLicenseModel;
}