import { LineItem } from "./ram-license";

export class CheckConflictingRamLicensesModel {
    ramLicenseId: number;
    ramLicenseExpiryDate: string;
    lineItems: CheckConflictingLineItemModel[];

    constructor(ramLicenseId: number, ramLicenseExpiryDate: string, lineItems: LineItem[]) {
        this.ramLicenseId = ramLicenseId;
        this.ramLicenseExpiryDate = ramLicenseExpiryDate;
        this.lineItems = lineItems.map((lineItem, index) => new CheckConflictingLineItemModel(lineItem, index));
    }
}

export class CheckConflictingLineItemModel {
    lineItemAccountOrderTypes: CheckConflictingLineItemAccountOrderTypeModel[];
    index: number;

    constructor(lineItem: LineItem, index: number) {
        this.lineItemAccountOrderTypes = lineItem.lineItemAccountOrderTypes;
        this.index = index;
    }
}

export class CheckConflictingLineItemAccountOrderTypeModel {
    accountId: number;
    orderTypeId: number;

    constructor(accountId: number, orderTypeId: number) {
        this.accountId = accountId;
        this.orderTypeId = orderTypeId;
    }
}

export class ConflictingLineItemModel {
    lineItemIndex: number;
    conflictingNrcRamLicenseIds: string[];
}