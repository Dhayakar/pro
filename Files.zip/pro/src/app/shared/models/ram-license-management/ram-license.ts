import { RamLicenseVersionTypeEnum } from "@shared/enums/ram-license-version-type-enum";
import {
  AccountModel,
  AccountOrderTypeForRamLicense,
  OrderTypeModel,
} from "../ram-licenses/ram-license-accounts";
import { RomeContactsViewModel } from "../rome-contacts-management/rome-contacts-view-model";

export class GetRamLicenseModel {
  ramLicenseId: number;
  nrcRamLicenseId: string;
  type: RamLicenseVersionTypeEnum;
  version: number;
  status: boolean;
  expiryDate: Date;
  authorisedUser: string[];
  comment: string;
  lineItems: RamLicenseLineItemModel[];
  contacts: RomeContactsViewModel[];
}

export class RamLicenseLineItemModel {
  ramLicenseLineItemId: number;
  possessionLimit: number;
  lineItemReference: string;
  products: LineItemProductModel[];
  accountOrderTypes: AccountOrderTypeModel[];
}

export class ViewRamLicenseModel {
  ramLicenseId: number;
  nrcRamLicenseId: string;
  type: RamLicenseVersionTypeEnum;
  expiryDate: Date;
  authorisedUser: string[];
  comment: string;
  status: boolean;
  versionType: RamLicenseVersionTypeEnum;
  version: number;
  lineItems: LineItem[];
  contacts: RomeContactsViewModel[];

  constructor(ramLicense: GetRamLicenseModel = null) {
    if (ramLicense != null) {
      this.ramLicenseId = ramLicense.ramLicenseId;
      this.nrcRamLicenseId = ramLicense.nrcRamLicenseId;
      this.type = ramLicense.type;
      this.version = ramLicense.version;
      this.status = ramLicense.status;
      this.expiryDate = ramLicense.expiryDate;
      this.authorisedUser = ramLicense.authorisedUser;
      this.comment = ramLicense.comment;
      this.lineItems = ramLicense.lineItems.map((li, index) => {
        const lineItem = new LineItem(li);
        lineItem.expanded = index === 0;
        return lineItem;
      });
      this.contacts = ramLicense.contacts;
    }
  }
}

export class LineItemProductModel {
  productTypeId: number;
  description: string;
}

export class AccountOrderTypeModel {
  account: AccountModel;
  orderType: OrderTypeModel;
}

export class CreateRamLicenseModel {
  ramLicenseId: number;
  nrcRamLicenseId: string;
  expiryDate: Date;
  authorisedUsers: string[];
  comment: string;
  versionType: RamLicenseVersionTypeEnum;
  version: number;
  lineItems: LineItem[];
  contacts: RomeContactsViewModel[];

  constructor() {
    this.nrcRamLicenseId = null;
    this.expiryDate = null;
    this.authorisedUsers = [];
    this.comment = null;
    this.version = null;
    this.lineItems = [new LineItem()];
    this.contacts = [new RomeContactsViewModel(-1)];
  }
}

export class LineItem {
  ramLicenseLineItemId: number;
  possessionLimit: number;
  lineItemReference: string;
  productTypeIds: number[];
  lineItemAccountOrderTypes: LineItemAccountOrderType[];
  showDeliveryAddressRequiredError: boolean;
  productIdsThatCannotBeRemoved: number[];
  conflictingNrcRamLicenseIds: string[];
  expanded: boolean;
  identifier: string;

  constructor(lineItem: RamLicenseLineItemModel = null) {
    this.showDeliveryAddressRequiredError = false;
    this.conflictingNrcRamLicenseIds = [];
    this.expanded = true;

    if (lineItem != null) {
      this.ramLicenseLineItemId = lineItem.ramLicenseLineItemId;
      this.possessionLimit = lineItem.possessionLimit;
      this.lineItemReference = lineItem.lineItemReference;
      this.productTypeIds = lineItem.products.map((p) => p.productTypeId);
      this.productIdsThatCannotBeRemoved = lineItem.accountOrderTypes.map(
        (aot) => aot.account.productTypeId,
      );
      this.lineItemAccountOrderTypes = lineItem.accountOrderTypes.map((aot) => {
        const accountOrderType = new AccountOrderTypeForRamLicense();
        accountOrderType.account = aot.account;
        accountOrderType.orderType = aot.orderType;

        return new LineItemAccountOrderType(accountOrderType);
      });
    } else {
      this.productTypeIds = [];
      this.productIdsThatCannotBeRemoved = [];
      this.lineItemAccountOrderTypes = [];
    }
  }
}

export class LineItemAccountOrderType {
  accountId: number;
  orderTypeId: number;
  deliveryAddressId: number;
  institution: string;
  deliveryAddress: string;
  deliveryAddressActive: boolean;
  productTypeId: number;
  product: string;
  orderTypeDescription: string;
  orderTypeAssigned: boolean;
  customerAccountId: string;
  accountActive: boolean;

  gridSelectionKey: string;

  constructor(accountOrderType: AccountOrderTypeForRamLicense) {
    this.accountId = accountOrderType.account.accountId;
    this.orderTypeId = accountOrderType.orderType.orderTypeId;
    this.deliveryAddressId =
      accountOrderType.account.deliveryAddress.deliveryAddressId;
    this.institution = accountOrderType.account.institution;
    this.deliveryAddress = accountOrderType.account.deliveryAddress.description;
    this.deliveryAddressActive =
      accountOrderType.account.deliveryAddress.active;
    this.product = accountOrderType.account.product;
    this.productTypeId = accountOrderType.account.productTypeId;
    this.orderTypeDescription = accountOrderType.orderType.description;
    this.orderTypeAssigned = accountOrderType.orderType.assigned;
    this.customerAccountId = accountOrderType.account.customerAccountId;
    this.accountActive = accountOrderType.account.active;

    this.gridSelectionKey = accountOrderType.gridSelectionKey;
  }
}
