export class TranslationsFilter {
  key: string;
  value: string;
  axEntityTypeId: (number | null);
  productTypeIds: number[];

  constructor() {
    this.clear();
  }

  clear(): void {
    this.key = '';
    this.value = '';
    this.productTypeIds = [];
    this.axEntityTypeId = null;
  }
}

export class TranslationsForConfigurationModel {
  languageKeys: string[];
  translations: TranslationItem[];
  total: number;
}

export class TranslationItem {
  key: string;
  productTypeId: (number | null);
  product: (string | null);
  axEntityTypeId: (number | null);
  languageTranslations: LanguageTranslationItem[];
}

export class LanguageTranslationItem {
  language: string;
  value: string;
}

export class InvalidTranslation {
  key: string;
  language: string;
  productTypeId: number;
  product: string;
  axEntityTypeId: number;
  entity: string;
}

export class UpdatedTranslation extends InvalidTranslation {
  newValue: string;
  isRowValid: boolean;
}
