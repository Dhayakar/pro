import { AxEntityType } from './ax-entity-types/ax-entity-type';
import { UserStatus } from './user-management/user-status';

export class UsersList {
  constructor(public users: UserList[], public count: number) {
  }
}

export class UserList {
  constructor(public romeUserId: number,
              public firstName: string,
              public lastName: string,
              public email: string,
              public primaryPhoneNumber: string,
              public secondaryPhoneNumber: string,
              public activeStatusIndicator: boolean,
              public userStatus: UserStatus,
              public primaryEntity: AxEntityType,
              public isDistributor: boolean,
              public roleId: number,
              public roleName: string,
              public lastSignInDate: Date) {
              }
}
