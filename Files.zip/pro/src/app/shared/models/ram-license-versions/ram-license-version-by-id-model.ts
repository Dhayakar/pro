export class RamLicenseVersionByIdModel {
    ramLicenseId : number;
    ramLicenseVersionNumber: number;
    nrcRamLicenseId: string;
}