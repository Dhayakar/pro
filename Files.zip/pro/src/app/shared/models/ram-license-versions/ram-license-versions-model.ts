export class RamLicenseVersionsModel {
    ramLicenseVersionNumber: number;
    versionNumber: number;
    versionType: string;
    dateUpdated: Date;
    fileCount: number;
}