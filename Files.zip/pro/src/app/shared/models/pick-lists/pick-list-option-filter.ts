import { PickListCategoryEnum } from '@shared/enums/pick-list-category-enum';

export class PickListOptionFilter {
    pickListCategory: PickListCategoryEnum;
    productTypeId: number;

    constructor(pickListCategory?: PickListCategoryEnum, productTypeId?: number) {
        this.pickListCategory = pickListCategory;
        this.productTypeId = productTypeId;
    }
}