import { ResultError } from "../result";

export class PickListData {
  columns: PickListDataColumn[];
  items: PickListDataItem[];
}

export class PickListDataItem {
  lookupOptionProductEntityId: number;
  id: number;
  originalDescription: string;
  data: any;
  readOnly: boolean;
  error: ResultError;

  constructor(columns: PickListDataColumn[]) {
    this.lookupOptionProductEntityId = 0;
    this.id = 0;
    this.data = {};
    columns.forEach((column) => {
      if (column.fieldType == "bool") {
        this.data[column.fieldName] = false;
      } else if (column.fieldType == "string") {
        this.data[column.fieldName] = null;
      } else if (column.fieldType == "dropdownlist") {
        this.data[column.fieldName] = null;
      }
    });
  }
}

export class PickListDataColumn {
  id: number;
  fieldName: string;
  fieldType: string;
  maxLength: number;
  width: number;
  isRequired: boolean;
  uniqueValuesOnly: boolean;
  isEditable: boolean;
  referenceData: any[];
  referenceDataFieldType: string;
}
