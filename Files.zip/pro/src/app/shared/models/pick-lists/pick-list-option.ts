import { PickListOptionEnum } from '@shared/enums/pick-list-option-enum';

export class PickListOption {
    id: PickListOptionEnum;
    translationKey: string;
    description: string;
    isAddEnabled: boolean;
    items: PickListOption[];

    constructor() {
    }
}