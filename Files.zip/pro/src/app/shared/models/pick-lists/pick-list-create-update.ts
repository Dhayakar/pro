import { PickListOptionEnum } from '@shared/enums/pick-list-option-enum';
import { PickListDataItem } from './pick-list-data';

export class PickListCreateUpdate {
    pickListOption: PickListOptionEnum;
    productTypeId: number;
    items: PickListDataItem[];

    constructor(pickListOption: PickListOptionEnum, productTypeId: number, items: PickListDataItem[]) {
        this.pickListOption = pickListOption;
        this.productTypeId = productTypeId;
        this.items = items;
    }
}