export class RomeReport {
    id: number;
    name: string;
    workspaceId: string;
    reportId: string;
    datasetId: string;
    romeUserId: number;
    romeRoleId: number;
  
    constructor(id: number, name: string, workspaceId: string, reportId: string, datasetId: string, romeUserId: number, romeRoleId: number) {
      this.id = id;
      this.name = name;
      this.workspaceId = workspaceId;
      this.reportId = reportId;
      this.datasetId = datasetId;
      this.romeRoleId = romeRoleId;
      this.romeUserId = romeUserId;
    }
  }