export class DuplicatedRadiopharmacyValidation {
    hasDuplicatedGroupName: boolean;
    items: DuplicatedRadiopharmacyItemValidation[];
}

export class DuplicatedRadiopharmacyItemValidation {
    radiopharmacyName: string;
    hasDuplicatedName: boolean;
    hasDuplicatedId: boolean;  
}
