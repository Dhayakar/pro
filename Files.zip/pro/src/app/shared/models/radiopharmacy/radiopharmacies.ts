export class RadiopharmacyList {
    radiopharmacies: Radiopharmacy[];
}

export class Radiopharmacy {
    id: number;
    description: string;
    name: string;
    city: string;
    state: string;
}
