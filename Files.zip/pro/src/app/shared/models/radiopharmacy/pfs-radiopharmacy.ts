export class PfsRadiopharmacy {
  id: number;
  description: string;
}
