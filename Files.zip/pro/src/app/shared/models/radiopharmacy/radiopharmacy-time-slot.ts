export class RadiopharmacyTimeSlot {
    timeSlot: Date;

    constructor(timeSlot: Date) {
        this.timeSlot = timeSlot;
    }
}