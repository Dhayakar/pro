export class RolePermissionMatrix {
    total: number;
    permissions: ClaimViewModel[];
}

export class ClaimViewModel{
    claimDescription: string;
    roleAssociations: any;
}