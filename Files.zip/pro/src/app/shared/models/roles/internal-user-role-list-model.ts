import { Role } from "../user-management/user-role";

export class InternalUserRoleListModel {
    roles: Role[];
}