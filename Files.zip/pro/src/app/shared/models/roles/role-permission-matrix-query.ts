export class RolePermissionMatrixQuery{
    skip: number;
    take: number;
    roleIds: number[];

    constructor(){
        this.skip = 0;
        this.take = 20;
        this.roleIds = [];
    }
}