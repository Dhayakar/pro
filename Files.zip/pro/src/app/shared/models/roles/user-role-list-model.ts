export class UserRoleListViewModel {
    roles: UserRoleListModel[];
}

export class UserRoleListModel {
    roleId: number;
    description: string;
    isInternal: boolean;
    active: boolean;
}

export class UserRoleListGroupedModel extends UserRoleListModel {
    category: string;
}