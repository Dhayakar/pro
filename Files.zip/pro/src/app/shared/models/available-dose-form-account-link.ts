import { AvailableDoseFormsEnum } from "@shared/enums/available-dose-forms-enum";

export class AvailableDoseFormAccountLink{
    id:number;
    accountId:number;
    availableDoseFormId:AvailableDoseFormsEnum
}