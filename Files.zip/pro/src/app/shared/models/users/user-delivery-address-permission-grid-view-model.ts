import { SafeHtml } from "@angular/platform-browser";

export class UserDeliveryAddressPermissionGridViewModel {
  public rowIndex: string;
  public entity: string;
  public product: string | SafeHtml;
  public institution: string;
  public deliveryAddress: string;
  public permissionString: string;

  constructor(
    rowIndex: string,
    entity: string,
    product: string | SafeHtml,
    institution: string,
    deliveryAddress: string,
    permissionString: string,
  ) {
    this.rowIndex = rowIndex;
    this.entity = entity;
    this.product = product;
    this.institution = institution;
    this.deliveryAddress = deliveryAddress;
    this.permissionString = permissionString;
  }
}
