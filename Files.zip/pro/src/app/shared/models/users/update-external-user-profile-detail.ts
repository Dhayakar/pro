export class UpdateExternalUserProfileDetail {
    public romeUserId: number;
    public firstName: string;
    public lastName: string;
    public primaryPhoneNumber: string;
    public secondaryPhoneNumber: string;
    public defaultEntityId: number;  
    public preferredLanguageId: number;
    public preferredTimePatternId: number;
}
