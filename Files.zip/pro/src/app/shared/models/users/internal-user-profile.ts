import { AdarTerritoryModel } from "../user-management/user-details";
import { UserRole } from "../user-management/user-role";

export class InternalUserProfile {
  public firstName: string;
  public lastName: string;
  public email: string;
  public userRoles: UserRole[];
  public status: boolean;
  public isCrossEntity: boolean;
  public primaryEntity: any;
  public defaultEntity: any;
  public preferredLanguageId: number;
  public preferredTimePatternId: number;
  public userProductsDescription: string;
  public userAdarTerritories: number[];
  public userAdarTerritoriesDescription: string;
  public adarTerritores: AdarTerritoryModel[];
  constructor() {
    this.firstName = "";
    this.lastName = "";
    this.email = "";
    this.userRoles = [];
    this.status = false;
    this.isCrossEntity = false;
    this.defaultEntity = null;
    this.primaryEntity = null;
    this.preferredLanguageId = 0;
    this.preferredTimePatternId = 0;
    this.userProductsDescription = "";
    this.userAdarTerritories = [];
    this.userAdarTerritoriesDescription = "";
  }
}
