import { UserStatusEnum } from "@shared/enums/user-status-enum";

export class InternalUserListFilterRequest {
    name: string;
    roleIds: number[];
    statusIds: number[];

    constructor() {
        this.name = '';
        this.roleIds = [];
        this.statusIds = [UserStatusEnum.Active]
    }
}

export class InternalUserListViewModel {
    totalUsers: number;
    users: InternalUserListModel[];
}

export class InternalUserListModel {
    romeUserId: number;
    firstName: string;
    lastName: string;
    userName: string;
    email: string;
    roles: string;
    products: string;
    status: boolean;
}