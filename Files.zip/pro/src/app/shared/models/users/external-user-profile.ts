import { UserRoleEntity } from "@administration/user-management/create-edit-user-shared-fields/models/create-edit-user-details";
import {
  Entity,
  EntityPermissionGroup,
} from "@administration/user-management/create-edit-user-shared-fields/models/user-permission-groups";
import { SafeHtml } from "@angular/platform-browser";

export class ExternalUserProfile {
  public romeUserId: number;
  public firstName: string;
  public lastName: string;
  public email: string;
  public primaryPhoneNumber: string;
  public secondaryPhoneNumber: string;
  public defaultEntity: Entity;
  public defaultEntityId: number;
  public entityPermissionGroups: EntityPermissionGroup[];
  public userRoleEntities: UserRoleEntity[];
  public isDistributor: boolean;
  public preferredLanguageId: number;
  public preferredTimePatternId: number;
  public userProductsDescription: string | SafeHtml;
  public roleDescription: string;
  public hasRAndDCategory: boolean;
  public hasNonRAndDCategory: boolean;
  public userProducts: number[];

  constructor() {
    this.firstName = "";
    this.lastName = "";
    this.email = "";
    this.defaultEntity = new Entity();
  }
}
