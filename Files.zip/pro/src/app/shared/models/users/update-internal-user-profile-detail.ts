export class UpdateInternalUserProfileDetail {
  public firstName: string;
  public lastName: string;
  public defaultEntityId: number;
  public preferredLanguageId: number;
  public preferredTimePatternId: number;
  public userAdarTerritories: number[];
}
