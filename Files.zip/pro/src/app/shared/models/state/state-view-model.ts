export class StateViewModel {
  id: string;
  description: string;
  cities: string[];
}
