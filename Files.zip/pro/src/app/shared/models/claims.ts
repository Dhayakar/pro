export class Claim {
    constructor(public claimId: string,
        public name: string,
        public claimTypeId: number,
        public path: string) {
    }
}