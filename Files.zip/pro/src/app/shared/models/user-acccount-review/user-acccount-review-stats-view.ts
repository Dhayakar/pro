export class UserAccountReviewStatsView {
  unflagged: number;
  flagged: number;
  deactivated: number;
  scanned: number;
  executionToDate: Date;
  executionFromDate: Date;
}
