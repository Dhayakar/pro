import { SystemParameterEnum } from "@shared/enums/system-parameter-enum";

export class SystemParameter {
    systemParameterId: SystemParameterEnum;
    description: string;
    value: string;
}
  