export class SubOrderTypes {
  constructor(public subOrderTypes: SubOrderType[]) {}
}

export class SubOrderType {
  public id: number;
  public description: string;
  public active: boolean;
  public subOrderCategoryType: SubOrderCategoryType;
  public dosimetryWarningEnabled: boolean;
  public primaryManufacturingSiteId: number;
  public backupManufacturingSiteId: number;
  public fullDescription: string;

  constructor(
    id: number,
    description: string,
    active: boolean,
    subOrderCategoryType: SubOrderCategoryType,
    primaryManufacturingSiteId: number = null,
    backupManufacturingSiteId: number = null,
  ) {
    this.id = id;
    this.description = description;
    this.active = active;
    this.subOrderCategoryType = subOrderCategoryType;
    this.primaryManufacturingSiteId = primaryManufacturingSiteId;
    this.backupManufacturingSiteId = backupManufacturingSiteId;
  }
}

export class SubOrderCategoryType {
  constructor(
    public subOrderCategoryTypeId: number,
    public description: string,
  ) {}
}
