import { DatePipe } from "@angular/common";
import { ScheduledJobConfigurationFrequencyEnum } from "@shared/enums/scheduled-job-configuration-frequency-enum";
import { ScheduledJobConfigurationCategoryEnum } from "@shared/enums/scheduled-job-configuration-category-enum";
import { ScheduledJobConfigurationTypeEnum } from "@shared/enums/scheduled-job-configuration-type-enum";
import { ScheduledJobCustomValueTypeEnum } from "@shared/enums/scheduled-job-custom-value-type-enum";

export class ScheduledJobConfiguration {
  scheduledJobConfigurationId: number;
  scheduledJobConfigurationTypeDescription: string;
  scheduledJobConfigurationTypeId: ScheduledJobConfigurationTypeEnum;
  scheduledJobConfigurationCategoryId: ScheduledJobConfigurationCategoryEnum;
  scheduledJobConfigurationFrequencyDescription: string;
  scheduledJobConfigurationFrequencyId: ScheduledJobConfigurationFrequencyEnum;
  isFrequencyEditable: boolean;
  enabled: boolean;
  executionDayDescription: string;
  executionDay: number;
  executionTimeAsDate: Date;
  executionTime: string;
  timeZoneDescription: string;
  customValueDescriptions: string[];
  customValues: number[] | null;
  customValueTypeId: ScheduledJobCustomValueTypeEnum;
  shouldShowNumerictext: boolean;
}

export class UpdateScheduledJobConfiguration {
  items: UpdateScheduledJobConfigurationItem[];

  constructor(
    scheduledJobConfigurations: ScheduledJobConfiguration[],
    datepipe: DatePipe,
  ) {
    this.items = [];
    scheduledJobConfigurations.map((s) =>
      this.items.push(new UpdateScheduledJobConfigurationItem(s, datepipe)),
    );
  }
}

export class UpdateScheduledJobConfigurationItem {
  scheduledJobConfigurationId: number;
  scheduledJobConfigurationFrequencyId: ScheduledJobConfigurationFrequencyEnum;
  enabled: boolean;
  executionDay: number;
  executionTime: string;
  customValues: number[];
  customValueTypeId: ScheduledJobCustomValueTypeEnum;

  constructor(item: ScheduledJobConfiguration, datepipe: DatePipe) {
    this.scheduledJobConfigurationId = item.scheduledJobConfigurationId;
    this.enabled = item.enabled;
    this.scheduledJobConfigurationFrequencyId =
      item.scheduledJobConfigurationFrequencyId;
    this.executionDay = item.executionDay;
    this.executionTime = datepipe.transform(
      item.executionTimeAsDate,
      "H:mm:ss",
    );
    this.customValues = item.customValues;
    this.customValueTypeId = item.customValueTypeId;
  }
}

export class InvalidScheduledJobsConfiguration {
  scheduledJobConfigurationTypeDescription: string;
  invalidMonths: string;

  constructor(
    scheduledJobConfigurationTypeDescription: string,
    invalidMonths: string,
  ) {
    this.scheduledJobConfigurationTypeDescription =
      scheduledJobConfigurationTypeDescription;
    this.invalidMonths = invalidMonths;
  }
}
