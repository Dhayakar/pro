import { ScheduledJobConfigurationCategoryEnum } from "@shared/enums/scheduled-job-configuration-category-enum";

export class ScheduledJobCategoryFilter {
    scheduledJobConfigurationCategory: ScheduledJobConfigurationCategoryEnum;
    productTypeId: number;

    constructor(scheduledJobConfigurationCategory?: ScheduledJobConfigurationCategoryEnum, productTypeId?: number) {
        this.scheduledJobConfigurationCategory = scheduledJobConfigurationCategory;
        this.productTypeId = productTypeId;
    }
}