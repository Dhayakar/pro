export class GetUserAccountReviewSummary{
    data: UserAccountReviewSummary[];
    total: number;
}

export class UserAccountReviewSummary{
    executionDateTime: Date;
    userCountScanned: number;
    userCountFlagged: number;
    userCountUnflagged: number;
    userCountDeactivated: number;
    userAccountReviewSummaryId: number;
    userCountStaged: number;
    userCountUnstaged: number;
}
