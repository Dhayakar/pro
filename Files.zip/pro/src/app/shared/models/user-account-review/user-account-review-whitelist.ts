export class GetUserAccountReviewWhitelist {
    data: UserAccountReviewWhitelist[];
    total: number;
}

export class UserAccountReviewWhitelist {
    firstName: string;
    secondName: string;
    email: string;
    primaryEntity: string;
    romeUserId: number;
}