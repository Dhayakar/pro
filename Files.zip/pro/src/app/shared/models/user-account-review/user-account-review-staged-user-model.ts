export class GetStagedUsersModel {
    stagedUsers: StagedUsersModel[];
    total: number;
    loggedInUser: StagedUsersModel;
}

export class StagedUsersModel {
    romeUserId: number;
    firstName: string;
    lastName: string;
    email: string;
    primaryEntity: string;
    roles: string[];
    productCategory:string[];
    productType: any[];
    totalTherapeuticOrders: number;
    totalCompanionOrders: number;
}
