export class UserAccountReviewExportData {
  
  firstName: string;
  surname: string;
  emailAddress: string;
  primaryEntity: string;
  action: string;
  dateTimeJobExecuted: Date;
  jobType: string;
}
