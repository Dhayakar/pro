export class AccountModel {
    accountId: number;
    institution: string;
    deliveryAddress: DeliveryAddressModel;
    productTypeId: number;
    product: string;
    customerAccountId: string;
    active: boolean;
}

export class OrderTypeModel {
    orderTypeId: number;
    description: string;
    assigned: boolean;
}

export class DeliveryAddressModel {
    deliveryAddressId: number;
    description: string;
    active: boolean;
}

export class SearchAccountsForRamLicensesModel {
    accountOrderTypesForRamLicenses: AccountOrderTypeForRamLicense[];
    totalCount: number;
}

export class AccountOrderTypeForRamLicense {
    account: AccountModel;
    orderType: OrderTypeModel;
    nrcRamLicenseIds: string;
    
    gridSelectionKey: string;
}

export class SelectedAccountOrderType {
    accountId: number;
    orderTypeId: number;

    constructor(accountId: number, orderTypeId: number) {
        this.accountId = accountId;
        this.orderTypeId = orderTypeId;
    }
}

export class SearchRamLicenseAccountsFilter {
    pageSize: number;
    skip: number;

    institutionIds: number[];
    deliveryAddressIds: number[];
    accountOrderTypesToExclude: SelectedAccountOrderType[];
    productTypeIds: number[];
    statusIds: boolean[];
    customerAccountId: string;
    orderTypeIds: number[];

    ramLicenseIdBeingEdited: number;

    constructor(accountOrderTypesToExclude: SelectedAccountOrderType[], productTypeIds: number[], ramLicenseIdBeingEdited: number) {
        this.pageSize = 6;
        this.skip = 0;

        this.institutionIds = [];
        this.deliveryAddressIds = [];
        this.accountOrderTypesToExclude = accountOrderTypesToExclude;
        this.productTypeIds = productTypeIds ? productTypeIds : [];
        this.statusIds = [];
        this.customerAccountId = '';
        this.orderTypeIds = [];

        this.ramLicenseIdBeingEdited = ramLicenseIdBeingEdited;
    }
}