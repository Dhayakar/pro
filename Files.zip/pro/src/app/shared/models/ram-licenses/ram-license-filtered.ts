import internal from "assert";

export class RamLicenseFiltered {
    ramLicenses: RamLicenseFilteredItem[];
    totalRamLicensesCount: number;
}

export class RamLicenseFilteredItem {
    ramLicenseId: number;
    nrcRamLicenseId: number;
    lineItemPossesionLimitDetails: LineItemPossesionLimitDetail[];
    expirationDate: Date;
    active: string;
}

export class InstitutionModel {
    description: string;
    accounts: RamLicenseFilteredAccountModel[];
}

export class LineItemPossesionLimitDetail {
    possesionLimit: number;
    institutionDescription: string;
    deliveryAddress: string;
    deliveryAddressActive: boolean;
    product: string;
    productTypeId: number;
    active: boolean;
    ramLicenseOrderType: number | null;
    ramLicenseLineItemId: number;
    organizationId: number;
    orderTypeAssigned: boolean;
}

export class RamLicenseFilteredAccountModel {
    deliveryAddress: string;
    product: string;
    active: boolean;
    ramLicenseOrderType: number | null;
}

export class RamLicenseFilterRequest {
    nrcRamLicenseId: string;
    institutionIds: number[];
    deliveryAddressIds: number[];
    productTypeIds: number[];
    statusIds: boolean[];
    orderTypeIds: any[];


    constructor() {
        this.nrcRamLicenseId = "";
        this.institutionIds = [];
        this.deliveryAddressIds = [];
        this.productTypeIds = [];
        this.statusIds = [true];
        this.orderTypeIds = [];
    }

    clear() {
        this.nrcRamLicenseId = "";
        this.institutionIds = [];
        this.deliveryAddressIds = [];
        this.productTypeIds = [];
        this.statusIds = [];
        this.orderTypeIds = [];
    }
}
