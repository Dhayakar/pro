export class UpdateOrderCutOffsForProductEntity {
    productTypeId: number;
    axEntityTypeId: number;
    updateOrderCutOffs: UpdateOrderCutOffModel[];
    timeZoneId: string;
}

export class UpdateOrderCutOffModel {
    day: number;
    cutOffLength: number;
    cutOffTime: string;
    cutOffTypeId: number;
}