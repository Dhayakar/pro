export class UnusedDoseCutOffsForProductEntity {
  lastDateCutOffLength: number;
  investigationCutOffLength: number;
  timeZoneId: string;
}
