import { DayOfWeekDropdownItem } from "@administration/product-management/days-of-week";

export class ProductConfigurationDetail {
  productConfigurationTemplateId: number;
  axEntityTypeId: number;
  productTypeId: number;
  isEuropeanEntity: boolean;

  prnCutOff: number;
  scheduledCancellationJobCutOff: number;

  pendingOrderStartDay: number;
  pendingOrderStartTime: string;
  pendingOrderLength: number;

  doseIntervalMinimumUpperLimit: number;
  doseIntervalAcceptableUpperLimit: number;
  doseIntervalMinimumHardWarningEnabled: boolean;
  hardWarningMaxDoseNumber: number;

  unusedDoseCutOffs: UnusedDoseCutOffsConfiguration[] = [];
  productCutOffs: ProductCutOff[];
  productInjectionTimeConfigurations: ProductInjectionTimeConfiguration[];
  timeZoneName: string;
  timeZoneType: TimeZoneType;
  papVoucherCodeValidation: string;
  supplyWarningEnabled: boolean;
  vialQuantityVisible: boolean;
  maximumVialQuantity: number;
  imiInventoryEnabled: boolean;
  lastMinuteInventoryEnabled: boolean;
}

export class ValidateProductConfigurationDetail {
  productCutOffs: ProductCutOff[];
}

export class CutOff {
  productCutOffId: number;
  date: Date;
  cutOffLength: number;
  cutOffTime: string;
  cutOffTimeAsDate: Date;
}

export class ProductCutOff extends CutOff {
  productCutOffType: ProductCutOffType;
  injectionDay: number;
  deliveryDay: number;
  isAvailable: boolean;
  availableInjectionDays: number[];
  allAvailableDays: Array<DayOfWeekDropdownItem> = [];
}

export class ProductCutOffType {
  productCutOffTypeId: number;
  description: string;
}

export class ProductInjectionTimeConfiguration {
  weekDay: number;
  earliestAllowedTime: string;
  latestAllowedTime: string;
}

export class TimeZoneType {
  name: string;
  timeZoneId: string;
  dstName: string;
  offset: string;
}

export interface UnusedDoseCutOffsConfiguration {
  doseFormId: string;
  unusedDoseCutOffId: number;
  unusedDoseCutOffLength: number;
  unusedDoseCutOffType: string;
}
