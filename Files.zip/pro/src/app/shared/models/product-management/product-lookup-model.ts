import { ProductTypeCategoryEnum } from "@shared/enums/product-type-category-enum";

export class ProductLookupModel {
  productConfigurationTemplateId: number;
  productTypeId: number;
  description: string;
  hasVialProductCutOff: boolean;
  hasSyringeProductCutOff: boolean;
  productCategory: ProductTypeCategoryEnum;
  hasLmoCutOff: boolean;
}
