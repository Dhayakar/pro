import { ProductTypeCategoryEnum } from "@shared/enums/product-type-category-enum";

export class ProductOverviewDetails {
    productTypeId: number;
    productConfigurationTemplateId: number;
    description: string;
    fullDescription: string;
    category: ProductTypeCategoryEnum;
    salesOrderPrefix: string;
    status: boolean;
}

export class ProductDeliveryAddresses {
    items: ProductDeliveryAddress[];
    total: number;
}

export class ProductDeliveryAddress {
    accountId: number;
    organization: string;
    axCustomerAccountId: string;
    deliveryAddress: string;
    status: boolean;

    originalStatus: boolean;
}

export class ProductDeliveryAddressFilter {
    organization: string;
    axCustomerAccountId: string;
    deliveryAddress: string;
    statuses: boolean[];

    pageSize: number;
    skip: number;
    sortColumnName: string;
    sortDirection: string;

    constructor(sortColumnName: string, sortDirection: string) {
        this.pageSize = 10;
        this.skip = 0;
        this.statuses = [];
        this.sortColumnName = sortColumnName;
        this.sortDirection = sortDirection;
    }
}

export class ProductOverviewEditDetails {
    productTypeId: number;
    productConfigurationTemplateId: number;
    status: boolean;

    accountsForActivation: number[];

    constructor(product: ProductOverviewDetails) {
        this.productTypeId = product.productTypeId;
        this.productConfigurationTemplateId = product.productConfigurationTemplateId;
        this.status = product.status;
        this.accountsForActivation= [];
    }
}