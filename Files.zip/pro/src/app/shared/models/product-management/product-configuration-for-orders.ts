export class ProductConfigurationForOrders {
    pendingPeriod: PendingPeriodModel;
    entityBlockedDates: EntityBlockedDatesModel;
    suggestedNextDoseDate: SuggestedNextDoseDateModel;
    vialQuantity: VialQuantityModel;
}

export class PendingPeriodModel {
    startDate: Date;
    endDate: Date;
}

export class NewOrderCutOffsModel {
    deliveryDates: DeliveryDateModel[];
    injectionDates: DateModel[];
}

export class DateModel {
    dayOfWeek: number;
    date: Date;
}

export class DeliveryDateModel extends DateModel {
    injectionDays: number[];
}

export class EntityBlockedDatesModel {
    deliveryDates: Date[];
    injectionDates: Date[];
}

export class SuggestedNextDoseDateModel {
    isSuggestedNextDoseEnabled: boolean;
    acceptableUpperLimit: number;
}

export class VialQuantityModel {
    isVialQuantityVisible: boolean;
    maximumQuantity: number;
}