import { ProductInjectionTimeConfiguration } from './product-configuration-detail';

export class AllowedTimesSet {
    allowedTimes: Array<AllowedTime>;

    constructor(productInjectionTimeConfigurations: ProductInjectionTimeConfiguration[]) {
        this.allowedTimes = [];

        if (productInjectionTimeConfigurations.length) {
            productInjectionTimeConfigurations.forEach(e => {
                this.allowedTimes.push(
                    new AllowedTime(e.weekDay, this.parseTimeStringToDate(e.earliestAllowedTime), this.parseTimeStringToDate(e.latestAllowedTime)));
            });
        }
    }

    public getEarliestAllowedTime(injectionDate: Date) {
        const allowedTime = this.findMatchingAllowedTime(injectionDate);

        if (allowedTime) {
            injectionDate.setHours(allowedTime.earliestAllowedTime.getHours(), allowedTime.earliestAllowedTime.getMinutes());
            return injectionDate;
        }
    }

    public getLatestAllowedTime(injectionDate: Date) {
        const allowedTime = this.findMatchingAllowedTime(injectionDate);
        
        if (allowedTime) {
            injectionDate.setHours(allowedTime.latestAllowedTime.getHours(), allowedTime.latestAllowedTime.getMinutes());
            return injectionDate;
        }
    }

    private findMatchingAllowedTime(injectionDate: Date): AllowedTime {
        const injectionDayOfWeek = injectionDate.getDay();
        return this.allowedTimes.find(at => at.weekDay == injectionDayOfWeek);
    }

    private parseTimeStringToDate(timeString: string): Date {
        let timeComponents = timeString.split(":");
        let parsedDate = new Date();
        parsedDate.setHours(
            parseInt(timeComponents[0]), parseInt(timeComponents[1]), parseInt(timeComponents[2]));
        return parsedDate;
    }
}

export class AllowedTime {
    weekDay: number;
    earliestAllowedTime: Date;
    latestAllowedTime: Date;

    constructor(weekDay: number,
        earliestAllowedTime: Date,
        latestAllowedTime: Date) {
        this.weekDay = weekDay;
        this.earliestAllowedTime = earliestAllowedTime;
        this.latestAllowedTime = latestAllowedTime;
    }
}
