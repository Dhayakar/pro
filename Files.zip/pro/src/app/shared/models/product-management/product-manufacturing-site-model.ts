export class ProductManufacturingSiteModel {
    manufacturingSites: ProductManufacturingSite[];
    subOrderTypeManufacturingSites: ProductManufacturingSiteSubOrderType[];
}

export class ProductManufacturingSite {
    manufacturingSiteId: number;
    description: string;
    active: boolean;
    isActiveEditable: boolean;
    isDefaultSyringe: boolean;
    isDefaultVial: boolean;
}

export class ProductManufacturingSiteSubOrderType {
    id: number;
    description: string;
    active: boolean;
    subOrderCategoryType: string;
    primaryManufacturingSiteId: number;
    backupManufacturingSiteId: number;
}
