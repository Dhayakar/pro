
export class UpdateOrderCutOffsForOrder {
    public axEntityTypeId: number;
    public productTypeId: number;
    public earliestDates: EarliestAllowedDate[];
}

export class EarliestAllowedDate {
    dayOfWeek: number;
    date: Date;
    cutOffTypeId: number;
}
