export class UpdateGpsTrackingConfigurationModel {
  enabled: boolean;
  activeFrom: number;
  activeTo: number;
  productConfigurationTemplateId: number;
  productTypeId: number;
  gpsTrackingId: number;
  errorCutOff: number;
}
