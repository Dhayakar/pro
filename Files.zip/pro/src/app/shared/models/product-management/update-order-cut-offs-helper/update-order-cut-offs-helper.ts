import { TimeComparisonHelper } from "@shared/helpers/time-comparison-helper/time-comparison-helper";
import { UpdateOrderCutOffModel } from "../update-order-cut-offs";

export class UpdateOrderCutOffsHelper {
    public static calculateEarliestAllowedDateFromCutOff(cutOff: UpdateOrderCutOffModel, currentTimeInTimeZone: Date): Date {
        // Find the current time at the specified time zone
        // Then, go forward in time by the cut-off length
        // Then, go forward in time until you reach the next occurrence of the cut-off time on the injection day of the week
        // This date will be the earliest allowed date on that day of the week for everyone, regardless of their timezone
        // The process is the exact same for both new order cut-off dates and update/cancellation cut-off dates

        // Find the instant of time at currentTimeInTimeZone + the length of the cut-off period
        let instantAfterCutOffLength = new Date(currentTimeInTimeZone.getTime());
        instantAfterCutOffLength.setDate(currentTimeInTimeZone.getDate() + cutOff.cutOffLength);

        // Find the distance to the next occurrence of the order day of the week (including today)
        let distanceToNextOccurrenceOfAppointmentDayOfWeek = cutOff.day - instantAfterCutOffLength.getDay();

        if (UpdateOrderCutOffsHelper.appointmentDayIsLaterInTheWeek(distanceToNextOccurrenceOfAppointmentDayOfWeek) ||
            this.cutOffForNextPossibleAppointmentDayHasAlreadyPassed(distanceToNextOccurrenceOfAppointmentDayOfWeek,
                instantAfterCutOffLength, cutOff)) {
            distanceToNextOccurrenceOfAppointmentDayOfWeek += 7;
        }

        // Earliest allowed date is that next injection day - regardless of local timezone
        let earliestAllowedDateForAnInjectionOnThisDayOfTheWeek = new Date(instantAfterCutOffLength.getTime());
        earliestAllowedDateForAnInjectionOnThisDayOfTheWeek.setDate(instantAfterCutOffLength.getDate() + distanceToNextOccurrenceOfAppointmentDayOfWeek);
        earliestAllowedDateForAnInjectionOnThisDayOfTheWeek.setHours(0, 0, 0, 0);

        return earliestAllowedDateForAnInjectionOnThisDayOfTheWeek;
    }

    private static appointmentDayIsLaterInTheWeek(distanceToNextDay: number): boolean {
        return (distanceToNextDay < 0);
    }

    private static cutOffForNextPossibleAppointmentDayHasAlreadyPassed(distanceToNextDay: number,
        instantAfterCutOffLength: Date, cutOff: any): boolean {

        let injectionDayIsLastDayOfCutOffPeriod = (distanceToNextDay == 0);
        let cutOffTimeHasAlreadyPassed = TimeComparisonHelper.compareHoursAndMinutesOnly(this.parseTimeStringToDate(cutOff.cutOffTime), instantAfterCutOffLength);

        return (injectionDayIsLastDayOfCutOffPeriod &&
            cutOffTimeHasAlreadyPassed &&
            cutOff.cutOffLength > 0);
    }

    private static parseTimeStringToDate(timeString: string): Date {
        let timeComponents = timeString.split(":");
        let parsedDate = new Date();
        parsedDate.setHours(
            parseInt(timeComponents[0]), parseInt(timeComponents[1]), parseInt(timeComponents[2]));
        return parsedDate;
    }
}
