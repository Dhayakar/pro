import { DaysOfWeek } from '@administration/product-management/days-of-week';
import { TestBed } from '@angular/core/testing';
import { configureTestSuite } from 'ng-bullet';
import { UpdateOrderCutOffModel } from '../update-order-cut-offs';
import { UpdateOrderCutOffsHelper } from './update-order-cut-offs-helper';

describe('UpdateOrderCutOffsHelper', () => {
    configureTestSuite(() => {
        TestBed.configureTestingModule({});
    });

    describe('calculateEarliestAllowedDateFromCutOff Tests', () => {
        it('should return date later in the week, if cut-off will happen later in the week', () => {
            const currentTime = new Date(2020, 0, 13);  // Monday, Jan 13
            const cutOff = createUpdateCutOff('Wednesday', 1);    // Length is 1: cut-off on Tuesday, Jan 14
            const expectedEarliestAllowedDate = new Date(2020, 0, 15); // Wednesday, Jan 15

            checkEarliestAllowedDate(currentTime, expectedEarliestAllowedDate, cutOff);
        });

        it('should return date next week, if cut-off happened earlier in the week', () => {
            const currentTime = new Date(2020, 0, 15);  // Wednesday, Jan 15
            const cutOff = createUpdateCutOff('Tuesday', 1,);    // Length is 1: cut-off on Monday, Jan 13
            const expectedEarliestAllowedDate = new Date(2020, 0, 21); // Tuesday, Jan 21

            checkEarliestAllowedDate(currentTime, expectedEarliestAllowedDate, cutOff);
        });

        it('should return date later in the week, if cut-off will happen later today', () => {
            const currentTime = new Date(2020, 0, 13, 8);  // Monday, Jan 13, 8:00 AM
            const cutOff = createUpdateCutOff('Tuesday', 1, "09:00:00");    // Length is 1: cut-off on Monday, Jan 13, 9:00 AM
            const expectedEarliestAllowedDate = new Date(2020, 0, 14); // Tuesday, Jan 14

            checkEarliestAllowedDate(currentTime, expectedEarliestAllowedDate, cutOff);
        });

        it('should return date next week, if appointment day is today and cut-off time is earlier today (i.e. cut-off happened earlier today)', () => {
            const currentTime = new Date(2020, 0, 13, 10);  // Monday, Jan 13, 10:00 AM
            const cutOff = createUpdateCutOff('Tuesday', 1, "09:00:00");    // Length is 1: cut-off on Monday, Jan 13, 9:00 AM
            const expectedEarliestAllowedDate = new Date(2020, 0, 21); // Tuesday, Jan 21

            checkEarliestAllowedDate(currentTime, expectedEarliestAllowedDate, cutOff);
        });

        function createUpdateCutOff(dayOfWeek: string, cutOffLength: number, cutOffTime: string = "00:00:00"): UpdateOrderCutOffModel {
            const cutOff = new UpdateOrderCutOffModel();
            cutOff.day = DaysOfWeek.find(d => d.description === dayOfWeek).value;
            cutOff.cutOffLength = cutOffLength;
            cutOff.cutOffTime = cutOffTime;

            return cutOff;
        }

        function checkEarliestAllowedDate(currentTime: Date, expectedEarliestAllowedDate: Date, cutOff: UpdateOrderCutOffModel): void {
            const earliestAllowedDate = UpdateOrderCutOffsHelper.calculateEarliestAllowedDateFromCutOff(cutOff, currentTime);
            expect(earliestAllowedDate).toEqual(expectedEarliestAllowedDate);
        }
    });
});
