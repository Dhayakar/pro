export class ManufacturingSite {
    warehouseId: number;
    description: string;
    d365ItemNumberSuffix: string;
    axShippingSiteId: string;
    axShippingWarehouseId: string;
}

export class UpdateManufacturingSite {
    warehouseId: number;
    d365ItemNumberSuffix: string;
    axShippingSiteId: string;
    axShippingWarehouseId: string;

    constructor(manufacturingSite: ManufacturingSite) {
        this.warehouseId = manufacturingSite.warehouseId;
        this.d365ItemNumberSuffix = manufacturingSite.d365ItemNumberSuffix;
        this.axShippingSiteId = manufacturingSite.axShippingSiteId;
        this.axShippingWarehouseId = manufacturingSite.axShippingWarehouseId;
    }
}
