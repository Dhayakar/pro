import { TimeZoneType } from "../orders/time-zone-type";
import { ProductConfigurationDetail, ProductCutOff } from "./product-configuration-detail";
import { ProductConfigurationForEntity } from "./product-configuration-for-entity";

describe('ProductConfigurationForEntity', () => {
    describe('constructor tests', () => {
        const INTERVAL_TO = 2;

        const configurationDetail = createConfigurationDetail();
        configurationDetail.doseIntervalMinimumUpperLimit = INTERVAL_TO;

        it('should set all properties', () => {
            const axEntityTypeId = 1;
            const productTypeId = 2;
            const timeZoneId = 'timeZoneId';
            const papVoucherCodeValidation = 'pap';
            const supplyWarningEnabled = true;


            configurationDetail.axEntityTypeId = axEntityTypeId;
            configurationDetail.productTypeId = productTypeId;
            configurationDetail.timeZoneType.timeZoneId = timeZoneId;
            configurationDetail.papVoucherCodeValidation = papVoucherCodeValidation;
            configurationDetail.supplyWarningEnabled = supplyWarningEnabled;

            const productConfigurationForEntity = new ProductConfigurationForEntity(configurationDetail);
            expect(productConfigurationForEntity.axEntityTypeId).toEqual(axEntityTypeId);
            expect(productConfigurationForEntity.productTypeId).toEqual(productTypeId);
            expect(productConfigurationForEntity.timeZoneId).toEqual(timeZoneId);
            expect(productConfigurationForEntity.papVoucherCodeValidation).toEqual(papVoucherCodeValidation);
            expect(productConfigurationForEntity.supplyWarningEnabled).toBeTrue();

            expect(productConfigurationForEntity.allowedTimesSet).toBeDefined();
            expect(productConfigurationForEntity.doseIntervalMinimumUpperLimit).toEqual(INTERVAL_TO);
        });
    });

    function createConfigurationDetail(): ProductConfigurationDetail {
        const configurationDetail = new ProductConfigurationDetail();
        configurationDetail.productInjectionTimeConfigurations = [];
        configurationDetail.timeZoneType = new TimeZoneType(null, null, null, null, null, null, null, null, null);
        configurationDetail.productCutOffs = [];

        return configurationDetail;
    }
});