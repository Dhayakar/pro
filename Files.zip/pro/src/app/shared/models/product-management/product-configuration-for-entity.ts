import { ProductConfigurationDetail } from './product-configuration-detail';
import { AllowedTimesSet } from './allowed-times-set';

export class ProductConfigurationForEntity {
    constructor(configuration: ProductConfigurationDetail) {
        this.axEntityTypeId = configuration.axEntityTypeId;
        this.timeZoneId = configuration.timeZoneType.timeZoneId;
        this.papVoucherCodeValidation = configuration.papVoucherCodeValidation;
        this.productTypeId = configuration.productTypeId;
        this.supplyWarningEnabled = configuration.supplyWarningEnabled;

        this.initialiseAllowedTimes(configuration);
        this.initialiseDoseIntervalDetails(configuration);
    }

    public axEntityTypeId: number;
    public productTypeId: number;
    public doseIntervalMinimumUpperLimit: number;
    public doseIntervalAcceptableUpperLimit: number;
    public doseIntervalMinimumHardWarningEnabled: boolean;
    public supplyWarningEnabled: boolean;
    public hardWarningMaxDoseNumber: number;

    public allowedTimesSet: AllowedTimesSet;
    public timeZoneId: string;
    public papVoucherCodeValidation: string;

    private initialiseAllowedTimes(data: ProductConfigurationDetail) {
        this.allowedTimesSet = new AllowedTimesSet(data.productInjectionTimeConfigurations);
    }

    private initialiseDoseIntervalDetails(data: ProductConfigurationDetail) {
        this.doseIntervalMinimumUpperLimit = data.doseIntervalMinimumUpperLimit;
        this.doseIntervalAcceptableUpperLimit = data.doseIntervalAcceptableUpperLimit;
        this.doseIntervalMinimumHardWarningEnabled = data.doseIntervalMinimumHardWarningEnabled;
        this.hardWarningMaxDoseNumber = data.hardWarningMaxDoseNumber;
    }
}
