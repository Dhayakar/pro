import { ProductTypeCategoryEnum } from "@shared/enums/product-type-category-enum"

export class ProductCreationModel {
    productTypeDescription:string
    productTypeCategory:ProductTypeCategoryEnum
    productTypeFullDescription:string
    salesOrderPrefix:string

    constructor(category: ProductTypeCategoryEnum) {
        this.productTypeCategory = category
    }
}
