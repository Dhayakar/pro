export class WarehouseBlocksModel {
    warehouseId: number;

    productionDates: Date[];
    deliveryDates: Date[];
    injectionDates: Date[];
}