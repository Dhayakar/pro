import { formatDate } from '@angular/common';
import { EntityBlocks, EntityBlocksForDateModel } from '@shared/models/orders/block-date';

export class EntityBlockSet {
    deliveryDates: Array<EntityBlock>;
    injectionDates: Array<EntityBlock>;

    constructor(entityBlocks: EntityBlocks) {
        this.deliveryDates = entityBlocks.deliveryDateBlocks.map(block => new EntityBlock(block));
        this.injectionDates = entityBlocks.injectionDateBlocks.map(block => new EntityBlock(block));
    }
}

export class EntityBlock {
    date: string;

    constructor(block: EntityBlocksForDateModel) {
        this.date = formatDate(block.date, 'MM-dd-yyyy', 'en-US');
    }
}