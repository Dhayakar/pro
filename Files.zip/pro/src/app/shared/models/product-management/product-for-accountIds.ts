export class ProductForAccountIds {
    productTypeId:number;
}