export class ProductGpsTrackingConfigurationModel {
  enabled: boolean;
  activeFrom: number;
  activeTo: number;
  gpsTrackingId: number;
  timeZoneId: string;
  errorCutOff: number;
}
