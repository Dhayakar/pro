export class QuantityConfigurationModel {
    minimumQuantity: number;
    maximumQuantity: number;
    quantityIncrements: number;
}