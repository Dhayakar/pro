export class ProductWarningConfiguration {
  warningMessage: string;
}
