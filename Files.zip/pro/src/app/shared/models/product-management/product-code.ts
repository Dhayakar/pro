export class ProductCode {
    axProductCodeId: number;
    orderType: string;
    subOrderType: SubOrderTypeModel;
    warehouseId: number;
    manufacturingSite: string;
    itemNumber: string;
    active: boolean;
}

export class SubOrderTypeModel {
    description: string;
    categoryDescription: string;
    active: boolean;
}
