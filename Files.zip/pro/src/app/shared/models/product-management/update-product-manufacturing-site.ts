import { ProductManufacturingSite, ProductManufacturingSiteSubOrderType } from "./product-manufacturing-site-model";

export class UpdateProductManufacturingSite {
    productTypeId: number;
    manufacturingSites: UpdateProductManufacturingSiteItem[];
    subOrderTypes: UpdateProductManufacturingSiteSubOrderTypeItem[];


  constructor(productTypeId: number, items: ProductManufacturingSite[], subOrderTypes: ProductManufacturingSiteSubOrderType[],  defaultVialManufacturingSiteId: number, defaultSyringeManufacturingSiteId: number ) {
        this.productTypeId = productTypeId;
    this.manufacturingSites = items.map(i => new UpdateProductManufacturingSiteItem(i, defaultVialManufacturingSiteId, defaultSyringeManufacturingSiteId));
        this.subOrderTypes = subOrderTypes.map(i => new UpdateProductManufacturingSiteSubOrderTypeItem(i));
    }
}

export class UpdateProductManufacturingSiteItem {
    manufacturingSiteId: number;
    active: boolean;
  isDefaultVial: boolean;
  isDefaultSyringe: boolean;


  constructor(item: ProductManufacturingSite,defaultVialManufacturingSiteId: number = null, defaultSyringeManufacturingSiteId: number = null) {

    this.manufacturingSiteId = item.manufacturingSiteId;
      this.active = item.active;

      this.isDefaultVial = item.manufacturingSiteId == defaultVialManufacturingSiteId ? true : false;
      this.isDefaultSyringe = item.manufacturingSiteId == defaultSyringeManufacturingSiteId ? true : false;
    }
}

export class UpdateProductManufacturingSiteSubOrderTypeItem {
    subOrderTypeId: number;
    primaryManufacturingSiteId: number;
    backupManufacturingSiteId: number;

    constructor(item: ProductManufacturingSiteSubOrderType) {
        this.subOrderTypeId = item.id;
        this.primaryManufacturingSiteId = item.primaryManufacturingSiteId;
        this.backupManufacturingSiteId = item.backupManufacturingSiteId;
    }
}
