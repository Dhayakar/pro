import { ManufacturingSite, UpdateManufacturingSite } from './manufacturing-site';
import { ProductCode } from './product-code';

export class DynamicsIntegrationData {
    itemNumberPrefix: string;
    activityMbq: number;
    manufacturingSites: ManufacturingSite[];
    itemNumbers: ProductCode[];
}

export class UpdateDynamicsIntegrationData {
    productTypeId: number;
    itemNumberPrefix: string;
    activityMbq: string;
    manufacturingSites: UpdateManufacturingSite[];
    inactiveAxProductCodes: number[];

    constructor(productTypeId: number, dynamicsIntegrationData: DynamicsIntegrationData) {
        this.productTypeId = productTypeId;
        this.itemNumberPrefix = dynamicsIntegrationData.itemNumberPrefix;
        this.activityMbq = dynamicsIntegrationData.activityMbq.toString();
        this.manufacturingSites = dynamicsIntegrationData.manufacturingSites.map(m => new UpdateManufacturingSite(m));
        this.inactiveAxProductCodes = dynamicsIntegrationData.itemNumbers.filter(i => !i.active).map(i => i.axProductCodeId);
    }
}

