import { ProductWarningValidationEnum } from "@shared/enums/product-warning-validation-enum";

export class ProductWarningValidation {
    productTypeId: number;
    productConfigurationTemplateId: number;
    maximumDoseAvailable: number;
    productInjectionTimeConfigurations: ProductInjectionTimeConfiguration[];
    productDoseIntervalConfiguration: ProductDoseIntervalConfigurationModel;
    papVoucherCodeValidation:string;
}

export class ValidateProductWarningValidation {
    productTypeId: number;
    productInjectionTimeConfigurations: ProductInjectionTimeConfiguration[];

    constructor(productWarningValidation: ProductWarningValidation) {
        this.productTypeId = productWarningValidation.productTypeId;
        this.productInjectionTimeConfigurations = productWarningValidation.productInjectionTimeConfigurations;
    }
}

export class ProductInjectionTimeConfiguration {
    isAvailable: boolean;
    weekDay: number;
    earliestAllowedTime: string;
    latestAllowedTime: string;

    earliestAllowedTimeAsDate: Date;
    latestAllowedTimeAsDate: Date;
}

export class ProductDoseIntervalConfigurationModel {
    minimumUpperLimit: number;
    acceptableUpperLimit: number;

    minimumHardWarningEnabled: boolean;
    minimumSoftWarningNextDoseEnabled: boolean;
    minimumSoftWarningPreviousDoseEnabled: boolean;
    acceptableSoftWarningEnabled: boolean;
    hardWarningMaxDoseNumber: number;
    clinicalTrialSingleDoseValidationEnabled:boolean;
    clinicalTrialMultiDoseValidationEnabled:boolean;
}

export class ProductDoseIntervalLimitModel {
    intervalType: string;
    lowerLimit: number;
    upperLimit: number;

    constructor(intervalType, lowerLimit, upperLimit) {
        this.intervalType = intervalType;
        this.lowerLimit = lowerLimit;
        this.upperLimit = upperLimit;
    }
}

export class ProductDoseIntervalWarningModel {
    intervalType: string;
    user: string;
    description: string;
    enabled: boolean;
    applicableOrderTypes:ProductWarningValidationEnum;

    constructor(intervalType, user, description, enabled, applicableOrderTypes) {
        this.intervalType = intervalType;
        this.user = user;
        this.description = description;
        this.enabled = enabled;
        this.applicableOrderTypes = applicableOrderTypes;
    }
}
