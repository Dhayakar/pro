export class SyringeDoseCutOffModel {
  productTypeId: number;
  cutOffDate: Date;
  changePrnCutOff: number;
  scheduledCancellationJobCutOff: number;
}
