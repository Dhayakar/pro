import { ProductMatrixItemRelationEnum } from "@shared/enums/product-matrix-status-enum";

export class ProductMatrixListModel {
    total: number;
    products: ProductMatrixEntry[]
}

export class ProductMatrixEntry {
    productTypeId: number;
    productDescription: string;
    entities: ProductMatrixItemModel[];
    orderTypes: ProductMatrixItemModel[];
}

export class ProductMatrixItemModel {
    description: string;
    matrixStatus: ProductMatrixItemRelationEnum;
    tooltipItemsForTranslation: string[];
    tooltipText:string;
}

