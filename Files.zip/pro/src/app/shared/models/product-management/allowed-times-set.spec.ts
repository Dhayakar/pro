import { AllowedTimesSet } from "./allowed-times-set";
import { ProductInjectionTimeConfiguration } from "./product-configuration-detail";

describe('AllowedTimesSet', () => {
    const timeConfiguration = new ProductInjectionTimeConfiguration();
    timeConfiguration.earliestAllowedTime = "01:02:00";
    timeConfiguration.latestAllowedTime = "03:04:00";
    timeConfiguration.weekDay = 1;  // Monday

    const allowedTimesSet = new AllowedTimesSet([timeConfiguration]);

    const mondayDate = new Date(2020, 0, 13);  // Monday, Jan 13

    it('should get earliest allowed time correctly', () => {
        const earliestAllowedTime = allowedTimesSet.getEarliestAllowedTime(mondayDate);
        expect(earliestAllowedTime.getHours()).toEqual(1);
        expect(earliestAllowedTime.getMinutes()).toEqual(2);
    });

    it('should get latest allowed time correctly', () => {
        const latestAllowedTime = allowedTimesSet.getLatestAllowedTime(mondayDate);
        expect(latestAllowedTime.getHours()).toEqual(3);
        expect(latestAllowedTime.getMinutes()).toEqual(4);
    });

    it('should return null for allowed times if no match found for weekday', () => {
        const tuesdayDate = new Date(2020, 0, 14);  // Tuesday, Jan 14
        expect(allowedTimesSet.getEarliestAllowedTime(tuesdayDate)).toBeUndefined();
        expect(allowedTimesSet.getLatestAllowedTime(tuesdayDate)).toBeUndefined();
    });
});