export class OrderAndSubOrderTypes {
  constructor(public orderTypes: number[], public subOrderTypes: number[]) {
  }
}