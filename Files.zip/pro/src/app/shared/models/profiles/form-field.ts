export declare class FormField {
    public Visible: boolean;
    public Disabled?: boolean;
}