import { formatDate } from '@angular/common';
import { CreateBlock } from './orders/calendar/create-block';

export class AnyOrdersByDatesQueryModel {
    blockByWarehouse: boolean;
    potentialInjectionBlocks: BlockWithDateStringToCheck[];
    potentialDeliveryBlocks: BlockWithDateStringToCheck[];
    potentialProductionBlocks: BlockWithDateStringToCheck[];

    constructor(injectionBlocks: CreateBlock[], deliveryBlocks: CreateBlock[], productionBlocks: CreateBlock[], blockByWarehouse: boolean) {
        this.potentialInjectionBlocks = injectionBlocks.map(block => new BlockWithDateStringToCheck(block));
        this.potentialDeliveryBlocks = deliveryBlocks.map(block => new BlockWithDateStringToCheck(block));
        this.potentialProductionBlocks = productionBlocks.map(block => new BlockWithDateStringToCheck(block));
        this.blockByWarehouse = blockByWarehouse;
    }
}

class BlockWithDateStringToCheck {
    dateString: string;
    warehouseId: number;
    productTypeIds: number[];

    constructor(createBlock: CreateBlock) {
        this.dateString = formatDate(createBlock.date, "yyyy-MM-dd", "en-US");
        this.warehouseId = createBlock.warehouseId;
        this.productTypeIds = createBlock.productTypeIds;
    }
}
