export class Statistic {
  value: number;
  description: string;
  cssClass?: string;

  constructor(value: number, description: string, cssClass: string) {
    this.value = value;
    this.description = description;
    this.cssClass = cssClass;
  }
}
