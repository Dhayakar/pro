export class Result {
  isSuccess: boolean;
  list: ResultError[];
  success: any;
}

export class ResultError {
  code: number;
  message: string;
  callback: any;
}
