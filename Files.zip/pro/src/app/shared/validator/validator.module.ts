import { NgModule } from "@angular/core";
import { RequiredValidatorComponent } from "./required-validator/required-validator.component";
import { CommonModule } from "@angular/common";

@NgModule({
  declarations: [RequiredValidatorComponent],
  imports: [CommonModule],
  exports: [RequiredValidatorComponent],
})
export class ValidatorModule {}
