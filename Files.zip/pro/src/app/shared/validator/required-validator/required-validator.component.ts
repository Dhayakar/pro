import { Component, Input, OnInit } from "@angular/core";

@Component({
  selector: "app-required-validator",
  templateUrl: "./required-validator.component.html",
})
export class RequiredValidatorComponent implements OnInit {
  @Input() model: any;
  @Input() message: string;
  @Input() submitted: boolean;
  @Input() rangeError: string;
  constructor() {}

  ngOnInit() {}
}
