import { TimeZoneHelperServiceMock } from '@shared/mocks/services/time-zones/timeZoneHelper.service.mock';
import { TimeZoneType } from '@shared/models/orders/time-zone-type';
import { DisplayTimeZonePipe } from "./displayTimeZonePipe";

let timeZoneHelperServiceMock = new TimeZoneHelperServiceMock();

describe('Display time zone pipe', () => {
  it('should create', () => {
    const pipe = new DisplayTimeZonePipe(timeZoneHelperServiceMock.getMockedEstService());
    expect(pipe).toBeTruthy();
  });

  it('should display EST when offsets are equal', () => {
    let timeZoneType = new TimeZoneType(1, "EST", "-5", "Eastern Standard Time", "Eastern Standard Time", "EDT", "America/New_York", "", "");
    const pipe = new DisplayTimeZonePipe(timeZoneHelperServiceMock.getMockedEstService());
    let result = pipe.transform(timeZoneType, new Date(), true);

    expect(result).toBe('EST');
  });
  
  it('should display EDT when offsets are not equal', () => {
    let timeZoneType = new TimeZoneType(1, "EST", "-5", "Eastern Standard Time", "Eastern Standard Time", "EDT", "America/New_York", "", "");
    const pipe = new DisplayTimeZonePipe(timeZoneHelperServiceMock.getMockedEdtService());
    let result = pipe.transform(timeZoneType, new Date(), true);

    expect(result).toBe('EDT');
  });
    
  it('should display NT when offsets are equal', () => {
    let timeZoneType = new TimeZoneType(1, "NT", "-3.30", "Newfoundland Time", "Newfoundland Time", "NDT", "America/St_Johns", "", "");
    const pipe = new DisplayTimeZonePipe(timeZoneHelperServiceMock.getMockedNtService());
    let result = pipe.transform(timeZoneType, new Date(), true);

    expect(result).toBe('NT');
  });
    
  it('should display NDT when offsets are not equal', () => {
    let timeZoneType = new TimeZoneType(1, "NT", "-3.30", "Newfoundland Time", "Newfoundland Time", "NDT", "America/St_Johns", "", "");
    const pipe = new DisplayTimeZonePipe(timeZoneHelperServiceMock.getMockedNdtService());
    let result = pipe.transform(timeZoneType, new Date(), true);

    expect(result).toBe('NDT');
  });

  it('should display name when offsets are not equal but no DST name exists', () => {
    let timeZoneType = new TimeZoneType(1, "EST", "-5", "Eastern Standard Time", "Eastern Standard Time", null, "America/New_York", "", "");
    const pipe = new DisplayTimeZonePipe(timeZoneHelperServiceMock.getMockedEdtService());
    let result = pipe.transform(timeZoneType, new Date(), true);

    expect(result).toBe('EST');
  });
});
