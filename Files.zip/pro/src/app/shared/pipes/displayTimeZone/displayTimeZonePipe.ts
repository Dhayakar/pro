import { Pipe, PipeTransform } from '@angular/core';
import { TimeZoneHelperService } from '../../helpers/timeZone.helper.service';

@Pipe({name: 'displayTimeZone'})
export class DisplayTimeZonePipe implements PipeTransform {
    constructor(private timeZoneHelperService: TimeZoneHelperService) {

    }

    transform(timeZoneType: any, date: Date, useBrowserTimeZone: boolean = false): string {
        if(timeZoneType != null){
            date = this.parseDate(date);
                
            if(this.isDateInDst(timeZoneType, date, useBrowserTimeZone) && timeZoneType.dstName)
                return timeZoneType.dstName;

            return timeZoneType.name;
        }
        return "";
    }

    private parseDate(date: Date): Date{
        if (date == null)
            date = new Date();

        if(typeof date === "string")
            date = new Date(date);
        
        return date;
    }

    private isDateInDst(timeZoneType: any, date: Date, useBrowserTimeZone: boolean){
        let offsetInMinutesForDate = useBrowserTimeZone 
            ? this.timeZoneHelperService.getOffsetForTimeZoneUsingLocalTimeZone(date, timeZoneType.timeZoneId)
            : this.timeZoneHelperService.getOffsetForTimeZoneUsingNonLocalTimeZone(date, timeZoneType.timeZoneId);

        let normalOffsetInMinutes = this.getNormalOffsetInMinutesForTimeZone(timeZoneType);
        
        return Math.abs(offsetInMinutesForDate) != Math.abs(normalOffsetInMinutes);
    }

    private getNormalOffsetInMinutesForTimeZone(timeZoneType: any): number{
        let offset = timeZoneType.offset.split(".");
        let normalOffsetInHours = Math.abs(+offset[0]);
        let normalOffsetInMinutes = normalOffsetInHours * 60;
        
        if(offset.length > 1)
            normalOffsetInMinutes += Math.abs(+offset[1]);

        return normalOffsetInMinutes;
    }
}
