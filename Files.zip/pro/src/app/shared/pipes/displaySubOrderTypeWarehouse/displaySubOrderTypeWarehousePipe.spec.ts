import { TestBed } from '@angular/core/testing';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SubOrderType } from '@shared/models/sub-order-type';
import { DisplaySubOrderTypeWarehousePipe } from './displaySubOrderTypeWarehousePipe';

describe('DisplaySubOrderTypeWarehousePipe', () => {
  let pipe: DisplaySubOrderTypeWarehousePipe;

  beforeEach(() => {
    TestBed
      .configureTestingModule({
        imports: [
          TranslateModule.forRoot(),
        ],
        providers: [
          TranslateService
        ]
      });
      pipe = new DisplaySubOrderTypeWarehousePipe(TestBed.get(TranslateService));
  });

  it('should identify backup site correctly', () => {
    let value = pipe.transform(1, "Test", getMockSubOrderType());
    expect(value).toEqual("Test (orders.order-view-details.backup-warehouse)");
  });

  it('should identify primary site correctly', () => {
    let value = pipe.transform(2, "Test", getMockSubOrderType());
    expect(value).toEqual("Test (orders.order-view-details.primary-warehouse)");
  });

  it('should return warehouse description when the site is not primary/backup', () => {
    let value = pipe.transform(3, "Test", getMockSubOrderType());
    expect(value).toEqual("Test");
  });

  it('should return warehouse description when the subOrderType is null', () => {
    let value = pipe.transform(1, "Test", null);
    expect(value).toEqual("Test");
  });

  it('should return empty string when no warehouse is passed in', () => {
    let value = pipe.transform(1, null, getMockSubOrderType());
    expect(value).toEqual("");

    value = pipe.transform(null, "Test", getMockSubOrderType());
    expect(value).toEqual("");

    value = pipe.transform(null, null, getMockSubOrderType());
    expect(value).toEqual("");
  });

  function getMockSubOrderType(): SubOrderType{
    return {
      id: 1,
      active: true,
      backupManufacturingSiteId: 1,
      primaryManufacturingSiteId: 2,
      description: '123',
      dosimetryWarningEnabled: true,
      subOrderCategoryType: null,
      fullDescription: ''
    };
  }
});
