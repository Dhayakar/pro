import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SubOrderType } from '@shared/models/sub-order-type';

@Pipe({
  name: 'displaySubOrderTypeWarehouse'
})
export class DisplaySubOrderTypeWarehousePipe implements PipeTransform {
  constructor(private translate: TranslateService){}

  transform(warehouseId: number, warehouseDescription: string, subOrderType: SubOrderType): any {
    if(!warehouseId || !warehouseDescription)
      return "";

    if (!subOrderType)
      return warehouseDescription;

    if (warehouseId === subOrderType.primaryManufacturingSiteId)
      return `${warehouseDescription} (${this.translate.instant('orders.order-view-details.primary-warehouse')})`;

    if (warehouseId === subOrderType.backupManufacturingSiteId)
      return `${warehouseDescription} (${this.translate.instant('orders.order-view-details.backup-warehouse')})`;

    return warehouseDescription;
  }
}