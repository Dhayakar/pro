import { RemoveTimeFromDatePipe } from './remove-time-from-date.pipe';

describe('RemoveTimeFromDatePipe', () => {
  it('it should clear time', () => {
    const pipe = new RemoveTimeFromDatePipe();
    let testDate = new Date(2021, 1, 1, 19, 0, 0);
    let expectedDate = new Date(2021, 1, 1, 0, 0, 0);
    expect(pipe.transform(testDate)).toEqual(expectedDate);
  });
});
