import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'removeTimeFromDate'
})
export class RemoveTimeFromDatePipe implements PipeTransform {

  transform(date: Date): Date {
    date.setHours(0, 0, 0, 0);
    return date;
  }
}
