import { Pipe, PipeTransform } from '@angular/core';
import { UserPreferencesService } from '@services/user-preferences/user-preferences.service';

@Pipe({name: 'convertToLocalTime'})
export class ConvertToLocalTimePipe implements PipeTransform {
    constructor(public userPreferences: UserPreferencesService) {}

    //Pass in date in UTC time, returns date converted to local time
    transform(date: string, dateFormat: string = this.userPreferences.getPreferredDateAndTimeFormat(), hideTimeZoneDescription: boolean = false,longTimeZone: boolean=false ): string {
        let dateToConvert = new Date(date);
        let offset = this.getCurrentTimeZoneOffset();
        dateToConvert.setMinutes(dateToConvert.getMinutes() + offset);
        let dateToConvertString = this.userPreferences.getLocalizedDate(dateToConvert, dateFormat);

        if (!hideTimeZoneDescription)
            dateToConvertString = `${dateToConvertString} (${this.getTimeZoneDescription(longTimeZone)})`;

        return dateToConvertString;
    }

    //Returns the current time zone's offset from UTC in minutes
    public getCurrentTimeZoneOffset(): number{
        let offset = new Date().getTimezoneOffset();
        offset *= -1;

        return offset;
    }

    //Returns the current time zone's abbreviation, full name or UTC offset (depending on what is available)
    public getTimeZoneDescription(longTimeZone: boolean = false): string {
        let currentDate = new Date();
        let localeStrings = ['en-us', 'en-ca', 'en-gb', 'en-ie', 'en-au', 'en-nz', 'en-cb', 'en-za', 'en-in'];
        let count = 0;
        let timeZoneName = null;
        
        //Loops through locales checking for the time zone's abbreviation
        while(!this.isTimeZoneNameAbbreviated(timeZoneName) && count < localeStrings.length){
            let localeTimeString = currentDate.toLocaleTimeString(localeStrings[count],longTimeZone? {timeZoneName:'long'} : {timeZoneName:'short'}).split(' ');

            if(localeTimeString.length >= 3){
                if(longTimeZone){
                    timeZoneName= localeTimeString[1] +' '+ localeTimeString[2]+' '+ localeTimeString[3];
                }else{
                timeZoneName = localeTimeString[2];
                }
            }
            
            count++;
        }
        
        if(!this.isTimeZoneNameAbbreviated(timeZoneName)){
            let dateString = String(currentDate);
            let firstBracketIndex = dateString.indexOf("(");
            let secondBracketIndex = dateString.indexOf(")");

            if(firstBracketIndex >= 0 && secondBracketIndex >= 0){
                //Sets timeZoneName to the full name
                timeZoneName = dateString.substring(firstBracketIndex + 1, secondBracketIndex);
            }
            else{
                let offset = this.getCurrentTimeZoneOffset() / 60.0;
                
                //Sets timeZoneName to the UTC offset in hours
                timeZoneName = "UTC " + (offset >= 0 ? "+" + offset : offset);
            }
        }

        return timeZoneName;
    }

    //Returns true if the time zone name is abbreviated, otherwise returns false
    public isTimeZoneNameAbbreviated(timeZoneName: string): boolean{
        if(timeZoneName == undefined || timeZoneName == null || timeZoneName.indexOf("+") >= 0  || timeZoneName.indexOf("-") >= 0 || timeZoneName.indexOf(" ") >= 0 ){
            return false;
        }

        return true;
    }
}