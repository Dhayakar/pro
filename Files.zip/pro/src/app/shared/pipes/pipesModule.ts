import { NgModule } from "@angular/core";
import { ConvertToLocalTimePipe } from "./convertToLocalTime/convertToLocalTimePipe";
import { DisplayTimeZonePipe } from "./displayTimeZone/displayTimeZonePipe";
import { FilterOrderStatusByClaimsPipe } from "./filterOrderStatusByClaims/filterOrderStatusByClaimsPipe";
import { DisplaySubOrderTypeWarehousePipe } from "./displaySubOrderTypeWarehouse/displaySubOrderTypeWarehousePipe";
import { RemoveTimeFromDatePipe } from "./removeTimeFromDate/remove-time-from-date.pipe";
import { DisplayHtmlWithoutSanitizationPipe } from "./displayHtmlWithoutSanitization/display-html-without-sanitization.pipe";
import { DisplayProductDescriptionPipe } from "./productDescription/displayProductDescriptionPipe";
import { DisplayProductDescriptionPipeMock } from "../mocks/pipes/displayProductDescriptionPipeMock";

@NgModule({
  declarations: [
    ConvertToLocalTimePipe,
    DisplayTimeZonePipe,
    FilterOrderStatusByClaimsPipe,
    DisplaySubOrderTypeWarehousePipe,
    RemoveTimeFromDatePipe,
    DisplayHtmlWithoutSanitizationPipe,
    DisplayProductDescriptionPipe,
    DisplayProductDescriptionPipeMock,
  ],
  exports: [
    ConvertToLocalTimePipe,
    DisplayTimeZonePipe,
    FilterOrderStatusByClaimsPipe,
    DisplaySubOrderTypeWarehousePipe,
    RemoveTimeFromDatePipe,
    DisplayHtmlWithoutSanitizationPipe,
    DisplayProductDescriptionPipe,
  ],
  providers: [DisplayProductDescriptionPipe, DisplaySubOrderTypeWarehousePipe],
})
export class PipesModule {}
