import { Injectable, Pipe, PipeTransform } from '@angular/core';
import { OrderStatusType } from '../../models/orders/order-status-type';
import { AuthorisationService } from 'src/app/services/authorisation/authorisation.service';

@Pipe({ name: 'filterOrderStatusByClaims' })
@Injectable({
    providedIn: 'root'
})
export class FilterOrderStatusByClaimsPipe implements PipeTransform {
    constructor(private authorisationService: AuthorisationService) { }

    transform(statusTypes: Array<OrderStatusType>): Array<OrderStatusType> {

        let filteredStatusTypes: Array<OrderStatusType> = [];

        statusTypes.forEach(statusType => {
            let claim = "ORDERS_ORDER_STATUS_" + statusType.description;

            if (this.authorisationService.currentUser.checkClaim(claim)) {
                filteredStatusTypes.push(statusType);
            }
        });

        return filteredStatusTypes;
    }
}