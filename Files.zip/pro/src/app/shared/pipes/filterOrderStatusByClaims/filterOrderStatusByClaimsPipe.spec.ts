import { TestBed } from "@angular/core/testing";
import { BrowserModule } from "@angular/platform-browser";
import { AuthorisationService } from "@services/authorisation/authorisation.service";
import { RolesEnum } from "@shared/enums/roles-enum";
import { AuthorisationServiceMock } from "@shared/mocks/services/authorisation.service.mock";
import {
  OrderStatusCategoryType,
  OrderStatusType,
} from "@shared/models/orders/order-status-type";
import { FilterOrderStatusByClaimsPipe } from "./filterOrderStatusByClaimsPipe";

describe("FilterOrderStatusByClaimsPipe", () => {
  let pipe: FilterOrderStatusByClaimsPipe;

  const authServiceMock =
    new AuthorisationServiceMock().createAuthorisationServiceMock(
      RolesEnum.ROLE_CUSTOMER_SERVICE,
    );

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [BrowserModule],
      providers: [{ provide: AuthorisationService, useValue: authServiceMock }],
    });

    pipe = new FilterOrderStatusByClaimsPipe(TestBed.get(AuthorisationService));
  });

  it("should create", () => {
    expect(pipe).toBeTruthy();
  });

  it("should filter out statuses that user does not have claims for", () => {
    const approved = createMockStatus("Approved");
    const pending = createMockStatus("Pending Order Approval Required");
    const cancelled = createMockStatus("Cancelled");
    const other = createMockStatus("Other");

    const filteredStatuses = pipe.transform([
      approved,
      pending,
      cancelled,
      other,
    ]);

    expect(
      filteredStatuses.find(
        (status) => status.description === approved.description,
      ),
    ).toBeDefined();
    expect(
      filteredStatuses.find(
        (status) => status.description === pending.description,
      ),
    ).toBeDefined();

    expect(
      filteredStatuses.find(
        (status) => status.description === cancelled.description,
      ),
    ).toBeUndefined();
    expect(
      filteredStatuses.find(
        (status) => status.description === other.description,
      ),
    ).toBeUndefined();
  });

  function createMockStatus(statusDescription: string): OrderStatusType {
    let orderStatusType: OrderStatusType = {
      id: 0,
      description: statusDescription,
      isSelectable: true,
      orderStatusCategoryType: new OrderStatusCategoryType(
        1,
        "statusCategoryDescription",
      ),
    };

    return orderStatusType;
  }
});
