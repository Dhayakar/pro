import { DisplayHtmlWithoutSanitizationPipe } from './display-html-without-sanitization.pipe';

describe('DisplayHtmlWithoutSanitizationPipe', () => {
  let pipe: DisplayHtmlWithoutSanitizationPipe;

  beforeEach(() => {
    let spy = jasmine
        .createSpyObj('DomSanitizer', [
            'bypassSecurityTrustHtml'
        ]);
    
    spy.bypassSecurityTrustHtml.and.returnValue('<p style="color: green">Test</p>');
    pipe = new DisplayHtmlWithoutSanitizationPipe(spy);
  });

  it('return correct result when null', () => {
    expect(pipe.transform(null)).toEqual('');
  });

  it('return correct result when HTML passed in', () => {
    expect(pipe.transform('<p style="color: green">Test</p>')).toEqual('<p style="color: green">Test</p>');
  });
});
