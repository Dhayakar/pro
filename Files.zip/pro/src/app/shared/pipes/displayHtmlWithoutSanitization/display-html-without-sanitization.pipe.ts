import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Pipe({
  name: 'displayHtmlWithoutSanitization'
})
export class DisplayHtmlWithoutSanitizationPipe implements PipeTransform {
  constructor(private domSaniziter: DomSanitizer){

  }

  transform(html: any): SafeHtml {
    if(!html)
      return '';
    
    // Note: The bypassSecurityTrustHtml method is needed to ensure that styles are correctly displayed when displaying HTML through the innerHTML property
    return this.domSaniziter.bypassSecurityTrustHtml(html);
  }
}
