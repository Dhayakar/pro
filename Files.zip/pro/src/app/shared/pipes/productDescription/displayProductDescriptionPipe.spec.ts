import { DisplayProductDescriptionPipe } from "./displayProductDescriptionPipe";
import { AllProductsModel } from "@shared/models/products/all-products-model";
import { SubOrderCategoryTypeEnum } from "@shared/enums/sub-order-category-type-enum";
import { SafeHtml } from "@angular/platform-browser";

describe("Display Product Description pipe", () => {
  let pipe: DisplayProductDescriptionPipe;
  let defaultProduct: AllProductsModel;
  let commercialEntityId = 2;
  let nonCommercialEntityId = 3;

  let domSanitizerSpy = jasmine.createSpyObj("DomSanitizer", [
    "bypassSecurityTrustHtml",
  ]);
  let productHelperServiceSpy = jasmine.createSpyObj("ProductHelperService", [
    "convertSuperscriptToHTML",
  ]);

  beforeEach(() => {
    pipe = new DisplayProductDescriptionPipe(
      domSanitizerSpy,
      productHelperServiceSpy,
    );

    defaultProduct = new AllProductsModel();
    defaultProduct.productTypeId = 1;
    defaultProduct.description = "Description";
    defaultProduct.commercialDescription = "Commercial Description";
    defaultProduct.clinicalTrialDescription = "Clinical Trial Description";

    setAllProducts([defaultProduct]);
    setCommercialEntityIds([commercialEntityId]);
  });

  it("should return regularDescription as string if both descriptions are the same", () => {
    const result = getResult(
      nonCommercialEntityId,
      SubOrderCategoryTypeEnum.RAndD,
    );
    expect(result).toEqual("Clinical Trial Description");
  });

  it("should use Clinical Trial description as string when R&D SubOrderCategoryTypeId supplied and needHTML is false", () => {
    const result = getResult(
      nonCommercialEntityId,
      SubOrderCategoryTypeEnum.RAndD,
      false,
    );
    expect(result).toEqual("Clinical Trial Description");
  });

  it("should use regular description when non-R&D SubOrderCategoryTypeId supplied", () => {
    let result = getResult(
      nonCommercialEntityId,
      SubOrderCategoryTypeEnum.MedicalAffairs,
    );
    expect(result).toEqual("Description");
  });

  it("should use Commercial description when entity ID is commercial", () => {
    let result = getResult(commercialEntityId, null);
    expect(result).toEqual("Commercial Description");
  });

  it("should use Clinical Trial description when R&D SubOrderCategoryTypeId supplied and entity ID is commercial", () => {
    let result = getResult(commercialEntityId, SubOrderCategoryTypeEnum.RAndD);
    expect(result).toEqual("Clinical Trial Description");
  });

  it("should use description that matches the given product", () => {
    const productOne = createProduct(1, "Product One");
    const productTwo = createProduct(2, "Product Two");

    setAllProducts([productOne, productTwo]);

    const productOneResult = getResultForProduct(productOne);
    expect(productOneResult).toEqual("Product One");

    const productTwoResult = getResultForProduct(productTwo);
    expect(productTwoResult).toEqual("Product Two");

    function createProduct(
      productTypeId: number,
      description: string,
    ): AllProductsModel {
      const product = new AllProductsModel();
      product.productTypeId = productTypeId;
      product.description = description;

      return product;
    }

    function getResultForProduct(product: AllProductsModel): string | SafeHtml {
      return pipe.transform(
        product.productTypeId,
        [nonCommercialEntityId],
        null,
        false,
      );
    }
  });

  it("should return empty string if products not set", () => {
    setAllProducts(null);

    let result = getResult(nonCommercialEntityId, null);
    expect(result).toEqual("");
  });

  it("should return empty string if commercial Entity IDs not set", () => {
    setCommercialEntityIds(null);

    let result = getResult(nonCommercialEntityId, null);
    expect(result).toEqual("");
  });

  function getResult(
    axEntityTypeId: number,
    subOrderCategoryTypeId: SubOrderCategoryTypeEnum,
    needHtml: boolean = false,
  ): string | SafeHtml {
    return pipe.transform(
      defaultProduct.productTypeId,
      [axEntityTypeId],
      subOrderCategoryTypeId,
      needHtml,
    );
  }

  function setAllProducts(products: AllProductsModel[]): void {
    localStorage.setItem("allProducts", JSON.stringify(products));
  }

  function setCommercialEntityIds(commercialEntityIds: number[]): void {
    localStorage.setItem(
      "commercialEntityIds",
      JSON.stringify(commercialEntityIds),
    );
  }
});
