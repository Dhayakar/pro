import { Pipe, PipeTransform } from "@angular/core";
import { SubOrderCategoryTypeEnum } from "@shared/enums/sub-order-category-type-enum";
import { AllProductsModel } from "@shared/models/products/all-products-model";
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { ProductDisplayHelper } from "../../helpers/product-display-helper.service";

@Pipe({ name: "displayProductDescription" })
export class DisplayProductDescriptionPipe implements PipeTransform {
  constructor(
    protected sanitizer: DomSanitizer,
    protected ProductDisplayHelperService: ProductDisplayHelper,
  ) {}

  transform(
    productTypeId: number,
    axEntityTypeIds: number[],
    subOrderCategoryTypeId: number,
    returnAsHtml: boolean,
  ): string | SafeHtml {
    const productDescription = this.getProductDescription(
      productTypeId,
      axEntityTypeIds,
      subOrderCategoryTypeId,
    );

    if (!returnAsHtml) return productDescription;

    return this.sanitizer.bypassSecurityTrustHtml(
      this.ProductDisplayHelperService.convertSuperscriptToHTML(
        productDescription,
      ),
    );
  }

  private getProductDescription(
    productTypeId: number,
    axEntityTypeId: number[],
    subOrderCategoryTypeId: number,
  ): string {
    const products = this.getProducts();
    const commercialEntityIds = this.getCommercialEntityIds();

    if (!products || !commercialEntityIds) return "";

    const product = products.find((p) => p.productTypeId === productTypeId);

    if (subOrderCategoryTypeId === SubOrderCategoryTypeEnum.RAndD)
      return product.clinicalTrialDescription;

    return axEntityTypeId.some((x) => commercialEntityIds.includes(x))
      ? product.commercialDescription
      : product.description;
  }

  private getProducts(): AllProductsModel[] {
    const productsStorage = localStorage.getItem("allProducts");
    return JSON.parse(productsStorage) as AllProductsModel[];
  }

  private getCommercialEntityIds(): number[] {
    const commercialEntityIdsStorage = localStorage.getItem(
      "commercialEntityIds",
    );
    return JSON.parse(commercialEntityIdsStorage) as number[];
  }
}
