import { NgModule } from "@angular/core";
import { Routes, RouterModule, PreloadAllModules } from "@angular/router";

const routes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full",
  },
  {
    path: "login",
    loadChildren: () =>
      import("./modules/login/login.module").then((m) => m.LoginModule),
  },
  {
    path: "logout",
    loadChildren: () =>
      import("./modules/logout/logout.module").then((m) => m.LogoutModule),
  },
  {
    path: "dashboard",
    loadChildren: () =>
      import("./modules/dashboard/dashboard.module").then(
        (m) => m.DashboardModule,
      ),
  },
  {
    path: "orders",
    loadChildren: () =>
      import("./modules/orders/orders.module").then((m) => m.OrdersModule),
  },
  {
    path: "administration",
    loadChildren: () =>
      import("./modules/administration/administration.module").then(
        (m) => m.AdministrationModule,
      ),
  },
  {
    path: "inventory",
    loadChildren: () =>
      import("./modules/inventory/inventory.module").then(
        (m) => m.InventoryModule,
      ),
  },
  {
    path: "users",
    loadChildren: () =>
      import("./modules/users/users.module").then((m) => m.UsersModule),
  },
  {
    path: "policies-and-procedures",
    loadChildren: () =>
      import(
        "./modules/policies-and-reference-material/policies-and-reference-material.module"
      ).then((m) => m.PoliciesAndReferenceMaterialsModule),
  },
  {
    path: "reports",
    loadChildren: () =>
      import("./modules/reports/reports.module").then((m) => m.ReportsModule),
  },
  {
    path: "messaging",
    loadChildren: () =>
      import("./modules/messaging-system/messaging-system.module").then(
        (m) => m.MessagingSystemModule,
      ),
  },
  {
    path: "last-minute-inventory",
    loadChildren: () =>
      import(
        "./modules/last-minute-inventory/last-minute-inventory.module"
      ).then((m) => m.LastMinuteInventoryModule),
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules }),
  ],
  exports: [RouterModule],
  providers: [],
})
export class AppRoutingModule {}
