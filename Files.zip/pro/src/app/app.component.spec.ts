import { ComponentFixture, TestBed } from "@angular/core/testing";
import { AppComponent } from "./app.component";
import { HeaderComponent } from "@progress/kendo-angular-dateinputs";
import { MockComponent } from "ng-mocks";
import { CoreModule } from "./core/core.module";
import { NgxUiLoaderModule } from "ngx-ui-loader";
import { RouterTestingModule } from "@angular/router/testing";
import { LoggingServiceMock } from "@shared/mocks/services/logging/logging.service.mock";
import { LoggingService } from "@services/logging/logging.service";
import {
  TranslateCacheModule,
  TranslateCacheService,
  TranslateCacheSettings,
} from "ngx-translate-cache";
import { TranslateCacheFactory } from "./app.module";
import { TranslateModule, TranslateService } from "@ngx-translate/core";
import { HttpClientModule } from "@angular/common/http";
import { AuthorisationServiceMock } from "@shared/mocks/services/authorisation.service.mock";
import { RolesEnum } from "@shared/enums/roles-enum";
import { AuthorisationService } from "@services/authorisation/authorisation.service";
import { ProductServiceMock } from "@shared/mocks/services/products/product.service.mock";
import { ProductService } from "@services/products/product.service";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { OrderCreateSelectorComponent } from "@orders/order-create/order-create-selector/order-create-selector.component";
import { OrderCreateTherapeuticComponent } from "@orders/order-create/order-create-therapeutic/order-create-therapeutic.component";
import { OrderCreateCompanionComponent } from "@orders/order-create/order-create-companion/order-create-companion.component";
import { MsalServiceMock } from "@shared/mocks/msal.service.mock";
import { MsalService } from "@azure/msal-angular";
import { DashboardComponent } from "@dashboard/dashboard/dashboard.component";
import { RomeButtonComponent } from "@ui-components/rome-button-module/rome-button/rome-button.component";
import { DisplayBannerComponent } from "@dashboard/display-banner/display-banner.component";
import { DashboardInternalUsersComponent } from "@dashboard/dashboard-internal-users/dashboard-internal-users.component";
import { DashboardExternalUsersComponent } from "@dashboard/dashboard-external-users/dashboard-external-users.component";
import { LoaderServiceMock } from "@shared/mocks/services/loader/loader.service.mock";
import { LoaderService } from "@services/loader/loader.service";
import { AppConfigService } from "@services/app-config/app-config.service";
import { AppConfigServiceMock } from "@shared/mocks/services/app-config/app-config.service.mock";
import { IdleWatchServiceMock } from "@shared/mocks/services/idle-watch/idle-watch.service.mock";
import { IdleWatchPopupComponent } from "@shared/components/idle-watch-popup/idle-watch-popup.component";
import { IdleWatchService } from "@services/idle-watch/idle-watch.service";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { NewOrderButtonComponent } from "@shared/components/new-order-button/new-order-button.component";
import { OrderCreateSingleFlowComponent } from "@orders/order-create/order-create-single-flow/order-create-single-flow.component";

export function cleanStylesFromDOM(): void {
  const head: HTMLHeadElement = document.getElementsByTagName("head")[0];
  const styles: HTMLCollectionOf<HTMLStyleElement> | [] =
    head.getElementsByTagName("style");

  for (let idx: number = 0; idx < styles.length; idx++) {
    head.removeChild(styles[idx]);
  }
}

afterAll(() => {
  cleanStylesFromDOM();
});

describe("AppComponent", () => {
  let productServiceMock = new ProductServiceMock();
  const loggingServiceMock = new LoggingServiceMock();
  let authServiceMock =
    new AuthorisationServiceMock().createAuthorisationServiceMock(
      RolesEnum.ROLE_SERVICE_ADMIN,
      true,
    );
  let msalServiceMock = new MsalServiceMock();
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  const loaderServiceMock = new LoaderServiceMock();
  const appConfigureServiceMock = new AppConfigServiceMock();
  const idleWatchServiceMock = new IdleWatchServiceMock();

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        CoreModule,
        HttpClientModule,
        BrowserModule,
        BrowserAnimationsModule,
        RouterTestingModule,
        NgxUiLoaderModule,
        TranslateModule.forRoot(),
        RomeTooltipModule,
        TranslateCacheModule.forRoot({
          cacheService: {
            provide: TranslateCacheService,
            useFactory: TranslateCacheFactory,
            deps: [TranslateService, TranslateCacheSettings],
          },
        }),
      ],

      declarations: [
        AppComponent,
        MockComponent(HeaderComponent),
        DashboardComponent,
        OrderCreateSelectorComponent,
        MockComponent(NewOrderButtonComponent),
        MockComponent(OrderCreateTherapeuticComponent),
        MockComponent(OrderCreateCompanionComponent),
        MockComponent(RomeButtonComponent),
        MockComponent(DisplayBannerComponent),
        MockComponent(DashboardInternalUsersComponent),
        MockComponent(DashboardExternalUsersComponent),
        MockComponent(IdleWatchPopupComponent),
        MockComponent(OrderCreateSingleFlowComponent),
      ],
      providers: [
        {
          provide: LoggingService,
          useValue: loggingServiceMock.getMockedService(),
        },
        TranslateService,
        { provide: AuthorisationService, useValue: authServiceMock },
        {
          provide: ProductService,
          useValue: productServiceMock.getMockedService(),
        },
        { provide: MsalService, useValue: msalServiceMock.getMockedService() },
        {
          provide: LoaderService,
          useValue: loaderServiceMock.getMockedService(),
        },
        {
          provide: AppConfigService,
          useValue: appConfigureServiceMock.getMockedService(),
        },
        {
          provide: IdleWatchService,
          useValue: idleWatchServiceMock.getMockedService(),
        },
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;

    let store = {
      block_order_status:
        '{"blockStatusFlag":"NO_BLOCK","disableNewOrderButton":false}',
    };
    const mockSessionStorage = {
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
    };

    spyOn(sessionStorage, "getItem").and.callFake(mockSessionStorage.getItem);

    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("Return customHeader True", () => {
    let customComponent: OrderCreateSelectorComponent;
    let customfixture: ComponentFixture<OrderCreateSelectorComponent>;
    customfixture = TestBed.createComponent(OrderCreateSelectorComponent);
    customComponent = customfixture.componentInstance;
    component.setCustomHeader(customComponent);
    expect(component.customHeader).toBeTrue();
  });

  it("Return customHeader False", () => {
    let customComponent: DashboardComponent;
    let customfixture: ComponentFixture<DashboardComponent>;
    customfixture = TestBed.createComponent(DashboardComponent);
    customComponent = customfixture.componentInstance;
    component.setCustomHeader(customComponent);
    expect(component.customHeader).toBeFalse();
  });
});
