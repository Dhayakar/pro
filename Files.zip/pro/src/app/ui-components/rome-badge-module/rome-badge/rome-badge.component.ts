import { Component, EventEmitter, Input, Output } from "@angular/core";
import { BadgeTypeEnum } from "@shared/enums/badge-type-enum";

@Component({
  selector: "rome-badge",
  templateUrl: "./rome-badge.component.html",
  styleUrls: ["./rome-badge.component.scss"],
})
export class RomeBadgeComponent {
  @Input() text: string;
  @Input() type: string;
  @Input() showWarningIcon: boolean = false;
  @Input() warningPopout: boolean = false;
  @Input() showCursor: boolean = false;
  @Output() onClick = new EventEmitter<boolean>();

  public shouldShow: boolean;

  constructor() {}

  getBadgeClass(): string {
    switch (this.type) {
      case BadgeTypeEnum.Warning:
        return "badge bdg-warning";
      case BadgeTypeEnum.Information:
        return "badge bdg-information";
      case BadgeTypeEnum.Success:
        return "badge bdg-success";
      case BadgeTypeEnum.Error:
        return "badge bdg-error";
      default:
        break;
    }
  }

  isWarning(): boolean {
    return this.type === BadgeTypeEnum.Warning;
  }

  isInformation(): boolean {
    return this.type === BadgeTypeEnum.Information;
  }

  shouldShowPopup(): void {
    this.onClick.emit(true);
  }
}
