import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RomeBadgeComponent } from "./rome-badge/rome-badge.component";

@NgModule({
  declarations: [RomeBadgeComponent],
  imports: [CommonModule],
  exports: [RomeBadgeComponent],
})
export class RomeBadgeModule {}
