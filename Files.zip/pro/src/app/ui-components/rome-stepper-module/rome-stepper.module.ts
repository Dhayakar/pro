import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RomeStepperComponent } from './rome-stepper/rome-stepper.component';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { TranslateModule } from '@ngx-translate/core';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { LayoutModule } from '@progress/kendo-angular-layout';
import { RomeTooltipModule } from '@ui-components/rome-tooltip/rome-tooltip.module';

@NgModule({
  declarations: [
    RomeStepperComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    ButtonsModule,
    DialogModule,
    LayoutModule,
    RomeTooltipModule
  ],
  exports: [
    RomeStepperComponent
  ],
})
export class RomeStepperModule { }
