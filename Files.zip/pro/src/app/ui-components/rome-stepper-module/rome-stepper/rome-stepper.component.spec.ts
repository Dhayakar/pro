import { ComponentFixture, TestBed } from "@angular/core/testing";
import { TranslateModule } from "@ngx-translate/core";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { OrderFormNavigationService } from "@services/orders/order-form-navigation.service";
import { OrderFormNavigationServiceMock } from "@shared/mocks/services/orders/order-form-navigation.service.mock";
import { configureTestSuite } from "ng-bullet";

import { RomeStepperComponent } from "./rome-stepper.component";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { RomeStepperStep } from "@shared/models/rome-stepper/rome-stepper-step";
import { MockModule } from "ng-mocks";

describe("RomeStepperComponent", () => {
  let component: RomeStepperComponent;
  let fixture: ComponentFixture<RomeStepperComponent>;

  let orderFormNavigationServiceMock = new OrderFormNavigationServiceMock();

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MockModule(LayoutModule),
        MockModule(RomeTooltipModule),
        TranslateModule.forRoot(),
      ],
      providers: [
        {
          provide: OrderFormNavigationService,
          useValue: orderFormNavigationServiceMock.getMockedService(),
        },
      ],
      declarations: [RomeStepperComponent],
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeStepperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("onGoToChosenStep should only emit step key if step is clickable", () => {
    const spy = spyOn(component.chosenStep, "emit");
    const step = new RomeStepperStep("stepKey", "");

    step.isClickable = false;
    component.onGoToChosenStage(step);
    expect(spy).not.toHaveBeenCalled();

    step.isClickable = true;
    component.onGoToChosenStage(step);
    expect(spy).toHaveBeenCalled();
  });
});
