import { Component, Output, EventEmitter, Input } from "@angular/core";
import { RomeStepperStep } from "@shared/models/rome-stepper/rome-stepper-step";

@Component({
  selector: "rome-stepper",
  templateUrl: "./rome-stepper.component.html",
  styleUrls: ["./rome-stepper.component.scss"],
})
export class RomeStepperComponent {
  @Input() steps: RomeStepperStep[] = [];
  @Input() currentStep: number;
  @Output() chosenStep = new EventEmitter<string>();

  constructor() {}

  index(key: string): number {
    return this.steps.findIndex((step) => step.key === key) + 1;
  }

  totalSteps(): number {
    return this.steps.length;
  }

  onlyOneStep(): boolean {
    return this.steps.length === 1;
  }

  onGoToChosenStage(step: RomeStepperStep) {
    if (!step.isClickable) return;

    this.chosenStep.emit(step.key);
  }
}
