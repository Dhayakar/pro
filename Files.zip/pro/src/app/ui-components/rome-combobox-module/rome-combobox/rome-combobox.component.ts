import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  Output,
  ViewEncapsulation,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
@Component({
  selector: "rome-combobox",
  templateUrl: "./rome-combobox.component.html",
  styleUrls: ["./rome-combobox.component.scss"],
  encapsulation: ViewEncapsulation.None,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeComboboxComponent {
  @Input() dropdownLabel: string;
  @Input() className: string;
  @Input() dropdownId: string = "dropdownlist";
  @Input() ngModelValue: any = null;
  @Input() data: any[];
  @Input() isRequired: boolean;
  @Input() requiredMessage: string;
  @Input() isDisabled: boolean;
  @Input() shouldShowClearButton: boolean = true;
  @Output() ngModelValueChange = new EventEmitter<any>();
  @Input() maxLength: string;
  @Input() displaySideLabel: boolean = false;
  @Input() displayHeader: boolean = false;
  @Input() regexPattern: string;
  constructor(
    public control: NgForm,
    private cdr: ChangeDetectorRef,
  ) {}

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }

  valueChanged(selectedValue: any) {
    this.ngModelValueChange.emit(selectedValue.trim());
  }
  clearComboBox() {
    this.ngModelValue = "";
    this.valueChanged("");
  }
}
