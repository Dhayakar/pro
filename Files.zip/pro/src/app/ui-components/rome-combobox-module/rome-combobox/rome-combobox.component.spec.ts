import { HttpClientModule } from "@angular/common/http";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateModule } from "@ngx-translate/core";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { LabelModule } from "@progress/kendo-angular-label";
import { DirectiveModule } from "@shared/directives/directive.module";
import { ValidatorModule } from "@shared/validator/validator.module";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { MockModule } from "ng-mocks";
import { RomeComboboxComponent } from "./rome-combobox.component";

describe("RomeComboboxComponent", () => {
  let component: RomeComboboxComponent;
  let fixture: ComponentFixture<RomeComboboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        TranslateModule.forRoot(),
        MockModule(FormsModule),
        MockModule(DropDownsModule),
        MockModule(BrowserAnimationsModule),
        MockModule(ValidatorModule),
        MockModule(DirectiveModule),
        MockModule(HttpClientModule),
        MockModule(LabelModule),
        MockModule(RomeTooltipModule),
      ],
      declarations: [RomeComboboxComponent],
      providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeComboboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create the component", () => {
    expect(component).toBeTruthy();
  });

  it("should emit ngModelValueChange event when value is changed", () => {
    const newValue = "New Value";
    const ngModelValueChangeSpy = spyOn(component.ngModelValueChange, "emit");

    component.valueChanged(newValue);

    expect(ngModelValueChangeSpy).toHaveBeenCalledWith(newValue);
  });

  it("should emit onChange event when value is changed", () => {
    const newValue = "New Value";
    const onChangeSpy = spyOn(component.ngModelValueChange, "emit");

    component.valueChanged(newValue);

    expect(onChangeSpy).toHaveBeenCalledWith(newValue);
  });
});
