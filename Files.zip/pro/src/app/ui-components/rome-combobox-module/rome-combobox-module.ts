import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { LabelModule } from "@progress/kendo-angular-label";
import { RomeComboboxComponent } from "./rome-combobox/rome-combobox.component";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { ValidatorModule } from "@shared/validator/validator.module";
import { DirectiveModule } from "../../shared/directives/directive.module";

@NgModule({
  declarations: [RomeComboboxComponent],
  imports: [
    CommonModule,
    DropDownsModule,
    FormsModule,
    TranslateModule,
    LabelModule,
    ValidatorModule,
    RomeTooltipModule,
    DirectiveModule,
  ],
  exports: [RomeComboboxComponent],
})
export class RomeComboboxModule {}
