import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { RomePopUpComponent } from "./rome-pop-up.component";
import { RomeButtonModule } from "@ui-components/rome-button-module/rome-button.module";
import { DialogModule } from "@progress/kendo-angular-dialog";
import { TranslateModule, TranslateService } from "@ngx-translate/core";
import { CommonModule } from "@angular/common";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { By } from "@angular/platform-browser";

describe("RomePopUpComponent", () => {
  let component: RomePopUpComponent;
  let fixture: ComponentFixture<RomePopUpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        CommonModule,
        DialogModule,
        RomeButtonModule,
        TranslateModule.forRoot(),
      ],
      declarations: [RomePopUpComponent],
      providers: [TranslateService],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RomePopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("Expect Default value of element to be initialized value - title", async(() => {
    expect(component.titleLabel).toEqual("navigation.dialog.title");

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      let input = fixture.debugElement.query(By.css("span"));
      let el = input.nativeElement;

      expect(el.innerHTML).toBe("navigation.dialog.title");
    });
  }));

  it("Expect Default value of element to be initialized value - save message", async(() => {
    expect(component.messageLabel).toEqual("navigation.dialog.save-message");

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      let input = fixture.debugElement.query(By.css("#messageLabel"));
      let el = input.nativeElement;

      expect(el.innerText).toBe("navigation.dialog.save-message");
    });
  }));

  it("Expect Default value of element to be initialized default button value - no", async(() => {
    expect(component.noLabel).toEqual("navigation.dialog.no");

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      let input = fixture.debugElement.query(
        By.css("#cancelSavedChangesButton"),
      );
      let el = input.nativeElement;

      expect(el.innerText).toBe("navigation.dialog.no");
    });
  }));

  it("Expect Default value of element to be initialized default button value - yes", async(() => {
    expect(component.yesLabel).toEqual("navigation.dialog.yes");

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      let input = fixture.debugElement.query(
        By.css("#continueSavedChangesButton"),
      );
      let el = input.nativeElement;

      expect(el.innerText).toBe("navigation.dialog.yes");
    });
  }));

  it("should emit the provided value when onOtherClick is called", () => {
    // Arrange
    let emittedValue: any;
    component.onClickOther.subscribe((value: any) => (emittedValue = value));

    // Act
    component.onOtherClick(true);

    // Assert
    expect(emittedValue).toBe(true);
  });
});
