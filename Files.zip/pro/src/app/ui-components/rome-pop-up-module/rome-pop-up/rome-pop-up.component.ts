import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef,
} from "@angular/core";
import { ButtonsConst } from "@shared/consts/button-const";

@Component({
  selector: "rome-pop-up",
  templateUrl: "./rome-pop-up.component.html",
  styleUrls: ["./rome-pop-up.component.scss"],
})
export class RomePopUpComponent implements OnInit {
  @Input() titleLabel: string;
  @Input() messageLabel: string;
  @Input() subMessageLabel: string;
  @Input() noLabel: string;
  @Input() yesLabel: string;
  @Input() otherLabel: string = "Other";
  @Input() showNoButton: boolean = true;
  @Input() showCloseButton: boolean = true;
  @Input() showotherButton: boolean;
  @Input() imageId: string = "closeWarning";
  @Input() continueButtonId: string = "continueSavedChangesButton";
  @Input() cancelButtonId: string = "cancelSavedChangesButton";
  @Input() showYesButton: boolean = true;
  @Input() width: number;
  @Input() emitData: boolean = false;
  @Input() icon: string = "";
  @Input() iconRight: string = "";
  @Input() buttonType: string = "button";
  @Input() buttonDisabled: boolean = false;
  @Input() template: TemplateRef<any>;
  @Input() primaryIconRight: string = "";
  @Input() otherIconRight: string = "";
  @Input() innerHTMLContent: boolean = false;
  @Output() onClickYes: EventEmitter<any> = new EventEmitter<any>();
  @Output() onClickOther: EventEmitter<any> = new EventEmitter<any>();
  @Output() closePopup: EventEmitter<boolean> = new EventEmitter<boolean>();

  primaryButton: string = ButtonsConst.PRIMARY_BUTTON;
  secondaryButton: string = ButtonsConst.SECONDARY_BUTTON;
  tertiaryButton: string = ButtonsConst.TERTIARY_BUTTON;

  constructor() {}
  ngOnInit(): void {
    this.assignDefaultLabels();
  }

  private assignDefaultLabels() {
    if (!this.titleLabel) {
      this.titleLabel = "navigation.dialog.title";
    }
    if (!this.template && !this.messageLabel) {
      this.messageLabel = "navigation.dialog.save-message";
    }
    if (!this.noLabel) {
      this.noLabel = "navigation.dialog.no";
    }
    if (!this.yesLabel) {
      this.yesLabel = "navigation.dialog.yes";
    }
  }

  onClosePopup(shouldContinue: boolean) {
    this.closePopup.emit(shouldContinue);
  }
  onOtherClick(shouldContinue: any) {
    this.onClickOther.emit(shouldContinue);
  }

  onClick(shouldContinue: any) {
    if (this.emitData) {
      this.onClickYes.emit(shouldContinue);
    } else {
      this.closePopup.emit(true);
    }
  }
}
