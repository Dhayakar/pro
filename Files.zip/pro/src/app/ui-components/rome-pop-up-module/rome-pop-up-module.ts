import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { TranslateModule } from "@ngx-translate/core";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DialogModule } from "@progress/kendo-angular-dialog";
import { RomeButtonModule } from "../rome-button-module/rome-button.module";
import { RomePopUpComponent } from "./rome-pop-up/rome-pop-up.component";

@NgModule({
  declarations: [RomePopUpComponent],
  imports: [
    CommonModule,
    TranslateModule,
    ButtonsModule,
    DialogModule,
    RomeButtonModule,
  ],
  exports: [RomePopUpComponent],
})
export class RomePopUpModule {}
