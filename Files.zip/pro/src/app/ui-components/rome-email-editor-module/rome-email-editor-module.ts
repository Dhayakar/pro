import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RomeEmailEditorComponent } from './rome-email-editor/rome-email-editor.component';
import { CKEditorModule } from 'ckeditor4-angular';


@NgModule({
  declarations: [
    RomeEmailEditorComponent
    
  ],
  imports: [
    CommonModule,
    FormsModule, 
    CKEditorModule 
  ],
  exports: [
    RomeEmailEditorComponent
  ]
})
export class RomeEmailEditorModule{ }
