import { Component, EventEmitter, Input, Output } from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
  selector: "rome-email-editor",
  templateUrl: "./rome-email-editor.component.html",
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeEmailEditorComponent {
  @Input() name: string = "";
  @Input() content: string;
  @Input() readonly: string | boolean = "";
  @Output() onContentChange: EventEmitter<string> = new EventEmitter<string>();

  editorConfig: any;

  public isDataTheSameAsInitialLoad: boolean = false;

  ngOnInit() {
    this.editorConfig = {
      versionCheck: false,
      toolbar: [
        { name: "clipboard", items: ["Undo", "Redo"] },
        {
          name: "basicstyles",
          items: [
            "Bold",
            "Italic",
            "Underline",
            "Strike",
            "Subscript",
            "Superscript",
            "-",
            "CopyFormatting",
            "RemoveFormat",
          ],
        },
        {
          name: "paragraph",
          items: [
            "NumberedList",
            "BulletedList",
            "-",
            "Outdent",
            "Indent",
            "-",
            "JustifyLeft",
            "JustifyCenter",
            "JustifyRight",
            "JustifyBlock",
          ],
        },
        { name: "links", items: ["Link", "Unlink", "Anchor"] },
        { name: "insert", items: ["Image", "Table", "HorizontalRule"] },
        {
          name: "styles",
          items: ["Format", "Font", "FontSize", "TextColor", "BGColor"],
        },
        { name: "tools", items: ["Maximize"] },
        { name: "document", items: ["Source"] },
      ],
      wordcount: {
        showParagraphs: false,
      },
      allowedContent: true,
      fullPage: true,
      font_defaultLabel: "Volta Modern Display",
      font_names:
        "Arial;" +
        "Tahoma;" +
        "Verdana;" +
        "Volta Modern Display/volta_modern_display55_roman, Arial;" +
        "Volta Modern Text/volta_modern_text55_roman, Arial",
      readOnly: this.readonly,
      pasteFilter: "plain-text",
    };
  }

  constructor() {}

  onDataChange(updatedContent: string) {
    if (!this.isDataTheSameAsInitialLoad) {
      this.onContentChange.emit(updatedContent);
    }
  }

  onDataReady() {
    this.isDataTheSameAsInitialLoad = true;
  }

  onChange() {
    this.isDataTheSameAsInitialLoad = false;
  }
}
