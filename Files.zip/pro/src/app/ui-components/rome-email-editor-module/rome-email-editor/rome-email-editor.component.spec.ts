import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RomeEmailEditorComponent } from "./rome-email-editor.component";
import { FormsModule } from "@angular/forms";
import { MockModule } from "ng-mocks";

describe("RomeEmailEditorComponent", () => {
  let component: RomeEmailEditorComponent;
  let fixture: ComponentFixture<RomeEmailEditorComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RomeEmailEditorComponent],
      imports: [MockModule(FormsModule)],
    })
      .overrideComponent(RomeEmailEditorComponent, {
        set: { template: "" },
      })
      .compileComponents();

    fixture = TestBed.createComponent(RomeEmailEditorComponent);
    component = fixture.componentInstance;
    component.editorConfig = {};
  });

  it("should set isDataTheSameAsInitialLoad to false when onChange is called", () => {
    component.onChange();

    expect(component).toBeTruthy();
    expect(component.isDataTheSameAsInitialLoad).toBeFalse();
  });

  it("should set isDataTheSameAsInitialLoad to true when onDataReady is called", () => {
    component.onDataReady();

    expect(component.isDataTheSameAsInitialLoad).toBeTrue();
  });

  it("should emit content when onDataChange is called", () => {
    const updatedContent = "Updated content";
    spyOn(component.onContentChange, "emit");
    component.isDataTheSameAsInitialLoad = false;

    component.onDataChange(updatedContent);

    expect(component.onContentChange.emit).toHaveBeenCalledWith(updatedContent);
  });
});
