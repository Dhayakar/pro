import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';

@Component({
  selector: 'rome-toggle',
  templateUrl: './rome-toggle.component.html',
  styleUrls: ['./rome-toggle.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeToggleComponent {
  
    @Input() name: string;
    @Input() checked: boolean;
    @Input() toggleLabel: string;
    @Input() readonly: boolean = false;
    @Input() disabled: boolean = false;
    @Input() ngModelValue: string;
    @Input() onLabel: string = " ";
    @Input() offLabel: string = " ";
    @Output() valuechange: EventEmitter<any> = new EventEmitter<any>();
    @Output() ngModelValueChange = new EventEmitter();
  
    constructor(public control: NgForm) { }

    public onChange(value: any): void {
        this.ngModelValueChange.emit(value);
        this.valuechange.emit(value);
      }

}
