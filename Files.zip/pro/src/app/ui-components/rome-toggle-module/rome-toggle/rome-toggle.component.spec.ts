import { CommonModule } from "@angular/common";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { ControlContainer, FormsModule, NgForm } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { MockModule } from "ng-mocks";
import { RomeToggleComponent } from "./rome-toggle.component";

describe("RomeToggleComponent", () => {
  let component: RomeToggleComponent;
  let fixture: ComponentFixture<RomeToggleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        MockModule(TranslateModule),
        MockModule(CommonModule),
        MockModule(LabelModule),
        MockModule(InputsModule),
        MockModule(FormsModule),
        MockModule(ButtonsModule),
      ],
      providers: [{ provide: ControlContainer, useExisting: NgForm }, NgForm],
      declarations: [RomeToggleComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeToggleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should emit value on change", () => {
    spyOn(component.valuechange, "emit");
    const val = true;

    component.onChange(val);
    expect(component.valuechange.emit).toHaveBeenCalledWith(val);
  });
});
