import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RomeToggleComponent } from "./rome-toggle/rome-toggle.component";
import { LabelModule } from "@progress/kendo-angular-label";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { ButtonsModule } from "@progress/kendo-angular-buttons";

@NgModule({
  declarations: [RomeToggleComponent],
  imports: [
    TranslateModule,
    CommonModule,
    LabelModule,
    InputsModule,
    FormsModule,
    ButtonsModule,
  ],
  exports: [RomeToggleComponent],
})
export class RomeToggleModule {}
