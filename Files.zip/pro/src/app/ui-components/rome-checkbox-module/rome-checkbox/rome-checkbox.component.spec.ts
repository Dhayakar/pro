import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { configureTestSuite } from "ng-bullet";
import { MockModule } from "ng-mocks";

import { ValidatorModule } from "@shared/validator/validator.module";
import { RomeCheckboxComponent } from "./rome-checkbox.component";

describe("RomeCheckboxComponent", () => {
  let component: RomeCheckboxComponent;
  let fixture: ComponentFixture<RomeCheckboxComponent>;

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      declarations: [RomeCheckboxComponent],
      imports: [
        MockModule(FormsModule),
        MockModule(ValidatorModule),
        TranslateModule.forRoot(),
      ],
      providers: [NgForm],
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeCheckboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should emit value on change", () => {
    spyOn(component.valueChange, "emit");
    const val = true;
    component.value = val;

    component.onChange();
    expect(component.valueChange.emit).toHaveBeenCalledWith(val);
  });
});
