import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';

@Component({
  selector: 'rome-checkbox',
  templateUrl: './rome-checkbox.component.html',
  styleUrls: ['./rome-checkbox.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeCheckboxComponent {

  @Input() value: boolean;
  @Input() disabled: boolean = false;
  @Input() identifier: string = 'checkbox';
  @Input() label: string;
  @Input() submitted: boolean;
  @Input() required: boolean = false;
  @Input() requiredMessage: string;
  @Input() bold: boolean = false;
  @Input() labelOnRight: boolean = true;
  @Input() isRequired: boolean;

  @Output() valueChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  onChange(): void {
    this.valueChange.emit(this.value);
  }
}
