import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RomeCheckboxComponent } from "./rome-checkbox/rome-checkbox.component";
import { TranslateModule } from "@ngx-translate/core";
import { FormsModule } from "@angular/forms";
import { ValidatorModule } from "@shared/validator/validator.module";

@NgModule({
  declarations: [RomeCheckboxComponent],
  imports: [CommonModule, TranslateModule, FormsModule, ValidatorModule],
  exports: [RomeCheckboxComponent],
})
export class RomeCheckboxModule {}
