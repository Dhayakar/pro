import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  TemplateRef,
} from "@angular/core";
import { DropdownDataItem } from "../../model/dropdown-data-item";
import { DropDownFilterSettings } from "@progress/kendo-angular-dropdowns";
import { ControlContainer, NgForm } from "@angular/forms";
import { FilterConstants } from "@shared/helpers/filter.constants";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { TranslateService } from "@ngx-translate/core";

@Component({
  selector: "rome-multi-select-dropdown",
  templateUrl: "./rome-multi-select-dropdown.component.html",
  styleUrls: ["./rome-multi-select-dropdown.component.scss"],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeMultiSelectDropdownComponent implements OnInit {
  @Input() isSummaryTag: boolean = false;
  @Input() dropdownLabel: string = "Order Status";
  @Input() dropdownId: string = "dropdownlist";
  @Input() ngModelValue: any[] = [];
  @Input() data: DropdownDataItem[];
  @Input() isValuePrimitive: boolean;
  @Input() isRequired: boolean;
  @Input() requiredMessage: string;
  @Input() isDisabled: boolean;
  @Input() className: string;
  @Input() ngClassValue: string;
  @Input() isFilterable: boolean;
  @Input() labelClass: string;
  @Input() displaySideLabel: boolean = false;
  @Input() displayHeader: boolean = false;
  @Output() ngModelValueChange = new EventEmitter<any>();
  @Output() filteredItemEvent = new EventEmitter<any>();
  @Output() keyPressEvent = new EventEmitter<any>();
  @Output() focus = new EventEmitter<any>();
  @Input() filterable: boolean = false;
  @Input() textField: string = "description";
  @Input() valueField: string = "id";
  @Input() listItemTemplate: TemplateRef<any> = null;
  @Input() multiSelectItemTemplate: TemplateRef<any> = null;
  @Input() autoClose: boolean;
  @Input() allowCustom: boolean;
  @Input() form: NgForm;
  @Input() isSingleSelectField: boolean;
  @Input() popupClass: string = "rome-multi-select-popup";

  public filterSettings: DropDownFilterSettings =
    FilterConstants.FilterSettings;

  itemsToShowBeforeSummarising: number;
  defaultItem: any;

  ngOnInit() {
    this.itemsToShowBeforeSummarising = this.isSummaryTag == true ? 0 : 1000;
    this.setDefaultValue();
  }

  constructor(
    public control: NgForm,
    private translation: TranslateService,
  ) {}

  public itemDisabled(itemArgs: { dataItem: any; index: number }) {
    return itemArgs.dataItem.isDisabled;
  }

  setDefaultValue() {
    if (this.isSingleSelectField)
      this.defaultItem = this.translation.instant("orders.select");
    else this.defaultItem = null;
  }

  onFocus() {
    this.focus.emit();
  }

  valueChanged(selectedValue: any) {
    this.ngModelValueChange.emit(selectedValue);
  }

  filterChanged(filterValue: any) {
    this.filteredItemEvent.emit(filterValue);
  }

  keyPress(data: any) {
    this.keyPressEvent.emit(data);
  }

  public isItemSelected(item) {
    return this.isValuePrimitive
      ? this.ngModelValue &&
          this.ngModelValue.some((x) => x === item[this.valueField])
      : this.ngModelValue &&
          this.ngModelValue.some(
            (x) => x[this.valueField] === item[this.valueField],
          );
  }

  clear() {
    if (this.form) this.form.controls[this.dropdownId].markAsDirty();
    this.ngModelValue = [];
    this.valueChanged([]);
  }

  getSelectedValue(dataItem: any): any {
    return dataItem[this.textField];
  }

  valueNormalizerForCustomValues = (text$: Observable<string>) =>
    text$.pipe(
      map((text: string) => {
        if (this.data) {
          const matchingAvailableItem = this.data.find(
            (d) => d.description.toLowerCase() === text.toLowerCase(),
          );

          if (matchingAvailableItem) return matchingAvailableItem;
        }
        const textIsNonNumeric = isNaN(+text);

        if (textIsNonNumeric) return null;

        return {
          id: text,
          description: text,
        };
      }),
    );
}
