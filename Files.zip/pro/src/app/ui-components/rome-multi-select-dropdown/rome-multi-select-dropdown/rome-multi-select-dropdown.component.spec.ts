import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { FormsModule, NgForm } from "@angular/forms";
import { TranslateModule, TranslateService } from "@ngx-translate/core";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { TranslateServiceMock } from "@shared/mocks/services/translate/translate.service.mock";
import { ValidatorModule } from "@shared/validator/validator.module";
import { DropdownDataItem } from "@ui-components/model/dropdown-data-item";
import { RomeTooltipDirective } from "@ui-components/rome-tooltip/rome-tooltip/rome-tooltip-directive/rome-tooltip.directive";
import { MockDirective, MockModule } from "ng-mocks";
import { of } from "rxjs";
import { RomeMultiSelectDropdownComponent } from "./rome-multi-select-dropdown.component";

describe("RomeMultiSelectDropdownComponent", () => {
  let component: RomeMultiSelectDropdownComponent;
  let fixture: ComponentFixture<RomeMultiSelectDropdownComponent>;
  const translateServiceMock = new TranslateServiceMock();

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        RomeMultiSelectDropdownComponent,
        MockDirective(RomeTooltipDirective),
      ],
      imports: [
        MockModule(LabelModule),
        MockModule(FormsModule),
        MockModule(DropDownsModule),
        MockModule(InputsModule),
        MockModule(ButtonsModule),
        MockModule(ValidatorModule),
        TranslateModule.forRoot(),
      ],
      providers: [
        { provide: NgForm, useValue: new NgForm([], []) },
        {
          provide: TranslateService,
          useValue: translateServiceMock.getMockedService(),
        },
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeMultiSelectDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should return true if the primitive item is selected in the ngModelValue", () => {
    const ngModelValue = [1, 2, 3];
    const item = { id: 2, name: "Item 2" };
    component.ngModelValue = ngModelValue;
    component.isValuePrimitive = true;
    component.valueField = "id";

    const result = component.isItemSelected(item);

    expect(result).toBeTruthy();
  });

  it("should return true if the complex item is selected in the ngModelValue", () => {
    const ngModelValue = [
      { id: 1, name: "Item 1" },
      { id: 2, name: "Item 2" },
      { id: 3, name: "Item 3" },
    ];
    const item = { id: 2, name: "Item 2" };
    component.ngModelValue = ngModelValue;
    component.isValuePrimitive = false;
    component.valueField = "id";

    const result = component.isItemSelected(item);

    expect(result).toBeTruthy();
  });

  it("should return false if the item is not selected in the ngModelValue", () => {
    const ngModelValue = [
      { id: 1, name: "Item 1" },
      { id: 3, name: "Item 3" },
    ];
    const item = { id: 2, name: "Item 2" };
    component.ngModelValue = ngModelValue;
    component.isValuePrimitive = false;
    component.valueField = "id";

    const result = component.isItemSelected(item);

    expect(result).toBeFalsy();
  });

  describe("valueNormalizerForCustomValues Tests", () => {
    beforeEach(() => {
      component.data = [{ id: "N/A", description: "N/A", isDisabled: false }];
    });

    it("should convert numeric value to dropdown item", () => {
      component
        .valueNormalizerForCustomValues(of("123"))
        .subscribe((updatedItem: DropdownDataItem) => {
          expect(updatedItem.id).toEqual("123");
          expect(updatedItem.description).toEqual("123");
        });
    });

    it("should convert non-numeric value to dropdown item if it is a selectable item", () => {
      component
        .valueNormalizerForCustomValues(of("n/a"))
        .subscribe((updatedItem: DropdownDataItem) => {
          expect(updatedItem.id).toEqual("N/A");
          expect(updatedItem.description).toEqual("N/A");
        });
    });

    it("should return null for non-numeric value if it is not a selectable item", () => {
      component
        .valueNormalizerForCustomValues(of("Some Text"))
        .subscribe((updatedItem: DropdownDataItem) => {
          expect(updatedItem).toBeNull();
        });
    });
  });
});
