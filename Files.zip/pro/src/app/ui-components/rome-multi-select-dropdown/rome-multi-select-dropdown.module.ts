import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { ValidatorModule } from "@shared/validator/validator.module";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { RomeMultiSelectDropdownComponent } from "./rome-multi-select-dropdown/rome-multi-select-dropdown.component";

@NgModule({
  declarations: [RomeMultiSelectDropdownComponent],
  imports: [
    CommonModule,
    DropDownsModule,
    InputsModule,
    ButtonsModule,
    FormsModule,
    LabelModule,
    ValidatorModule,
    TranslateModule,
    RomeTooltipModule,
  ],
  exports: [RomeMultiSelectDropdownComponent],
})
export class RomeMultiSelectDropdownModule {}
