import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RomeDropdownComponent } from "./rome-drop-down.component";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { FormsModule, NgForm } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { LabelModule } from "@progress/kendo-angular-label";
import { RouterTestingModule } from "@angular/router/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from "@angular/common/http";
import { MockModule } from "ng-mocks";
import { DirectiveModule } from "@shared/directives/directive.module";
import { ValidatorModule } from "@shared/validator/validator.module";

describe("RomeDropDownComponent", () => {
  let component: RomeDropdownComponent;
  let fixture: ComponentFixture<RomeDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        MockModule(FormsModule),
        MockModule(DropDownsModule),
        MockModule(BrowserAnimationsModule),
        MockModule(HttpClientModule),
        MockModule(LabelModule),
        MockModule(DirectiveModule),
        MockModule(ValidatorModule),
        TranslateModule.forRoot(),
        RouterTestingModule,
      ],
      providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
      declarations: [RomeDropdownComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  describe("getValue Tests", () => {
    let dataItem;
    beforeEach(() => {
      dataItem = {
        description: "Test",
        id: 1,
      };
    });
    it("should set default value when no placeholder is passed", () => {
      component.placeholder = null;
      component.setDefaultItem();

      expect(component.defaultItem.description).toEqual("orders.select");
    });

    it("should set placeholder value when passed", () => {
      component.placeholder = "orders.physician.view-recent-physicians";
      component.setDefaultItem();

      expect(component.defaultItem.description).toEqual(
        "orders.physician.view-recent-physicians",
      );
    });

    it("should return translated value when shouldTranslateDataItem() returns true", () => {
      const dataItem = {
        description: "Test",
        id: 1,
      };
      component.isValuePrimitive = false;
      spyOn<any>(component, "shouldTranslateDataItem").and.returnValue(true);
      spyOn<any>(component, "getTranslationKey").and.returnValue(
        "translation-key",
      );

      expect(component.getValue(dataItem)).toEqual("translation-key");
    });

    it("should set defaultItem as blank when noPlaceHolder is set to true", () => {
      component.noSelectPlaceholder = true;

      component.setDefaultItem();
      expect(component.defaultItem).toEqual("");
    });
  });

  describe("getSelectedValue Tests", () => {
    it("should return over write value when passed", () => {
      const dataItem = {
        description: "Test",
        id: 1,
      };
      component.textOverwrite = "Overwrite";

      expect(component.getSelectedValue(dataItem)).toEqual(
        component.textOverwrite,
      );
    });

    it("should return ngModelValue when not primitive", () => {
      const dataItem = {
        description: "Test",
        id: 1,
      };
      component.isValuePrimitive = false;
      component.ngModelValue = 1;

      expect(component.getSelectedValue(dataItem)).toEqual(
        component.ngModelValue.description,
      );
    });

    it("should return translated value when shouldTranslateDataItem() returns true", () => {
      const dataItem = {
        description: "Test",
        id: 1,
      };
      component.isValuePrimitive = false;
      spyOn<any>(component, "shouldTranslateDataItem").and.returnValue(true);
      spyOn<any>(component, "getTranslationKey").and.returnValue(
        "translation-key",
      );

      expect(component.getSelectedValue(dataItem)).toEqual("translation-key");
    });

    it("should return default when no other value passed", () => {
      const dataItem = {
        description: "Test",
        id: 1,
      };

      expect(component.getSelectedValue(dataItem)).toEqual(
        dataItem.description,
      );
    });
  });

  describe("shouldTranslateDataItem tests", () => {
    it("should return the correct value", () => {
      let params = [
        {
          dataItem: null,
          defaultItem: { id: 1 },
          prefix: "prefix",
          suffix: "suffix",
          expectedResult: false,
        },
        {
          dataItem: { id: 1 },
          defaultItem: { id: 1 },
          prefix: "prefix",
          suffix: "suffix",
          expectedResult: false,
        },
        {
          dataItem: { id: 2 },
          defaultItem: { id: 1 },
          prefix: "prefix",
          suffix: "suffix",
          expectedResult: true,
        },
        {
          dataItem: { id: 2 },
          defaultItem: { id: 1 },
          prefix: "",
          suffix: "suffix",
          expectedResult: true,
        },
        {
          dataItem: { id: 2 },
          defaultItem: { id: 1 },
          prefix: "prefix",
          suffix: "",
          expectedResult: true,
        },
        {
          dataItem: { id: 2 },
          defaultItem: null,
          prefix: "prefix",
          suffix: "",
          expectedResult: true,
        },
        {
          dataItem: { id: 2 },
          defaultItem: { id: 1 },
          prefix: "",
          suffix: "",
          expectedResult: false,
        },
      ];

      params.forEach((param) => {
        component.defaultItem = param.defaultItem;
        component.dataItemTranslationPrefix = param.prefix;
        component.dataItemTranslationSuffix = param.suffix;
        expect(component["shouldTranslateDataItem"](param.dataItem)).toEqual(
          param.expectedResult,
        );
      });
    });
  });

  describe("getTranslationKey tests", () => {
    it("should return the correct value", () => {
      let params = [
        {
          dataItem: { description: "Test Description" },
          prefix: "prefix.",
          suffix: ".suffix",
          translationProperty: "",
          expectedResult: "prefix.test description.suffix",
        },
        {
          dataItem: { description: "Test Description" },
          prefix: "",
          suffix: ".suffix",
          translationProperty: "",
          expectedResult: "test description.suffix",
        },
        {
          dataItem: { description: "Test Description" },
          prefix: "prefix.",
          suffix: "",
          translationProperty: "",
          expectedResult: "prefix.test description",
        },
        {
          dataItem: {
            description: "Test Description",
            nestedObject: { nestedProperty: "Test Nested Property" },
          },
          prefix: "prefix.",
          suffix: ".suffix",
          translationProperty: "nestedObject.nestedProperty",
          expectedResult: "prefix.test nested property.suffix",
        },
        {
          dataItem: {
            description: "Test Description",
            nestedObject: { nestedProperty: "Test Nested Property" },
          },
          prefix: "prefix.",
          suffix: ".suffix",
          translationProperty: "nonExistentObject.property",
          expectedResult: "prefix..suffix",
        },
        {
          dataItem: {
            description: "Test Description",
            nestedObject: { nestedProperty: "Test Nested Property" },
          },
          prefix: "prefix.",
          suffix: ".suffix",
          translationProperty: "nestedObject.nonExistentProperty",
          expectedResult: "prefix..suffix",
        },
      ];

      params.forEach((param) => {
        component.dataItemTranslationPrefix = param.prefix;
        component.dataItemTranslationSuffix = param.suffix;
        component.dataItemTranslationProperty = param.translationProperty;
        expect(component["getTranslationKey"](param.dataItem)).toEqual(
          param.expectedResult,
        );
      });
    });
  });
});
