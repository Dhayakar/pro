import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation, TemplateRef, AfterViewInit } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { DropDownFilterSettings, ItemDisabledFn } from '@progress/kendo-angular-dropdowns';
import { FilterConstants } from '@shared/helpers/filter.constants';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'rome-drop-down',
  templateUrl: './rome-drop-down.component.html',
  styleUrls: ['./rome-drop-down.component.scss'],
  encapsulation: ViewEncapsulation.None,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class RomeDropdownComponent implements OnInit {
  @Input() dropdownLabel: string;
  @Input() dropdownId: string = 'dropdownlist';
  @Input() ngModelValue: any;
  @Input() data: any[];
  @Input() isValuePrimitive: boolean;
  @Input() isRequired: boolean;
  @Input() requiredMessage: string;
  @Input() isDisabled: boolean = false;
  @Input() className: string;
  @Input() ngClassValue: string;
  @Input() displaySideLabel: boolean = false;
  @Input() displayHeader: boolean = false;
  @Input() isFilterable: boolean;
  @Input() labelClass: string;
  @Input() isLeftIconVisible: boolean = true;
  @Input() isRightIconVisible: boolean = true;
  @Input() appDeliveryAddressRamLicenseValidatorData: any = null;
  @Input() appActiveDeliveryAddressValidatorData: any = null;
  @Input() textField: string = 'description';
  @Input() valueField: string = 'id'
  @Output() ngModelValueChange = new EventEmitter<any>();
  @Output() onChange = new EventEmitter();
  @Input() isStandalone: boolean;
  @Input() dropdownType: string;
  @Input() placeholder: string;
  @Input() textOverwrite: string;
  @Input() template: TemplateRef<any>;
  @Input() bgColor: string;
  @Input() noSelectPlaceholder: boolean;
  @Input() hideFilterText: boolean = false;
  @Input() dataItemTranslationPrefix: string;
  @Input() dataItemTranslationSuffix: string;
  @Input() dataItemTranslationProperty: string;
  @Input() isDisableOnSelected: boolean = false;
  @Input() isItemDisabled: ItemDisabledFn;


  public filterSettings: DropDownFilterSettings = FilterConstants.FilterSettings;
  defaultItem: any;
  @Output() filteredItemEvent = new EventEmitter<any>();

  constructor(public control: NgForm, private translation: TranslateService, private cdr: ChangeDetectorRef) {
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
    setTimeout(()=>{
      this.setDefaultItem();
    }, 0)
  }

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }

  public itemDisabled = (itemArgs: { dataItem: any, index: number }) => {
    return (this.isDisableOnSelected) ? itemArgs.dataItem.isSelected : itemArgs.dataItem.isDisabled;
  };
  
  getItemDisabledCallback(): ItemDisabledFn {
    if (!this.isItemDisabled)
      return this.defaultItemDisabled;

    return this.isItemDisabled;
  }

  private defaultItemDisabled(itemArgs: { dataItem: any; index: number }) {
    return itemArgs.dataItem.isDisabled;
  }

  valueChanged(selectedValue:any){
    this.ngModelValueChange.emit(selectedValue);
    this.onChange.emit(selectedValue);
  }

  isPrimaryDropdown(): boolean {
    return this.dropdownType === 'primaryDropdown';
  }

  getValue(dataItem: any): any {

    if (dataItem == null) {
      return;
    }

    return this.shouldTranslateDataItem(dataItem) 
      ? this.translation.instant(this.getTranslationKey(dataItem)) 
      : dataItem[this.textField];
  }

  setDefaultItem(): void {
    if (this.placeholder) {
      this.defaultItem = {
        [this.valueField]: null,
        [this.textField]: this.translation.instant(this.placeholder),
        isDisabled: true
      }
    }
    else if (this.noSelectPlaceholder) {
      this.defaultItem = '';
  }
  else {
    this.defaultItem = {
      [this.valueField]: null,
      [this.textField]: this.translation.instant('orders.select'),
      isDisabled: true
    };
  }
  }

  getSelectedValue(dataItem: any): any {
    if (this.textOverwrite) {
      return this.textOverwrite;
    }

    if (!this.isValuePrimitive && this.ngModelValue) {
      return this.shouldTranslateDataItem(this.ngModelValue)
        ? this.translation.instant(this.getTranslationKey(dataItem))
        : this.ngModelValue[this.textField];
    }

    return this.getValue(dataItem);
  }

  filterChanged(filterValue: any) {
    this.filteredItemEvent.emit(filterValue);
  }

  private shouldTranslateDataItem(dataItem: any): boolean {
    if (!dataItem || (!this.dataItemTranslationPrefix && !this.dataItemTranslationSuffix))
      return false;
    
    if(!this.defaultItem)
      return true;

    return dataItem[this.valueField] != this.defaultItem[this.valueField];
  }

  private getTranslationKey(dataItem: any): string {
    return `${this.dataItemTranslationPrefix}${this.getTranslationKeyDataItemText(dataItem)}${this.dataItemTranslationSuffix}`;
  }

  private getTranslationKeyDataItemText(dataItem: any): string {
    let propertyToUseForTranslation = this.dataItemTranslationProperty 
      ? this.dataItemTranslationProperty 
      : this.textField;

    var dataItemText = propertyToUseForTranslation.split('.').reduce((objectToCheck, keyToAccess) => {
      return objectToCheck
        ? objectToCheck[keyToAccess]
        : '';
    }, dataItem);

    return dataItemText ? dataItemText.toLowerCase() : '';
  }
}