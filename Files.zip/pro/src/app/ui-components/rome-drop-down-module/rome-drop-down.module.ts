import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RomeDropdownComponent } from "./rome-drop-down/rome-drop-down.component";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { LabelModule } from "@progress/kendo-angular-label";
import { ValidatorModule } from "@shared/validator/validator.module";
import { DirectiveModule } from "@shared/directives/directive.module";

@NgModule({
  declarations: [RomeDropdownComponent],
  imports: [
    CommonModule,
    DropDownsModule,
    FormsModule,
    TranslateModule,
    LabelModule,
    ValidatorModule,
    DirectiveModule,
  ],
  exports: [RomeDropdownComponent],
})
export class RomeDropDownModule {}
