import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { FormsModule } from "@angular/forms";
import { LabelModule } from "@progress/kendo-angular-label";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { TranslateModule } from "@ngx-translate/core";
import { RomeActionDropdownComponent } from "./rome-action-dropdown/rome-action-dropdown.component";

@NgModule({
  declarations: [RomeActionDropdownComponent],
  imports: [
    CommonModule,
    DropDownsModule,
    InputsModule,
    ButtonsModule,
    FormsModule,
    LabelModule,
    TranslateModule,
    RomeTooltipModule,
  ],
  exports: [
    DropDownsModule,
    InputsModule,
    ButtonsModule,
    RomeActionDropdownComponent,
  ],
})
export class RomeActionDropdownModule {}
