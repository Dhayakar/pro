import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewChild,
} from "@angular/core";
import { DropDownButton } from "@progress/kendo-angular-buttons";
@Component({
  selector: "app-rome-action-dropdown",
  templateUrl: "./rome-action-dropdown.component.html",
  styleUrls: ["./rome-action-dropdown.component.scss"],
})
export class RomeActionDropdownComponent implements OnInit {
  @ViewChild("dropdownButton", { static: false })
  dropdownButton: DropDownButton;
  // @Input() buttonVisible = false;
  @Input() dropDownItems: any[] = [];
  @Input() buttonLabel = "";
  @Input() icon = "";
  @Input() caretIconUp = "";
  @Input() caretIconDown = "";
  @Input() listItemIcon = "";
  @Input() headerClass: string[] = [];
  @Input() itemClass: string[] = [];
  @Input() isDisabled = false;
  @Input() iconRightToLabel = "";
  @Input() buttonType: string;
  @Input() type = "button";
  @Input() iconCustomWidth: string | number;
  @Input() iconCustomHeight: string | number;
  @Input() customWidth: string | number;
  @Input() customHeight: string | number;
  @Input() customMinHeight: string | number;
  @Input() title = "";
  @Input() iconToRightCustomWidth: string | number;
  @Input() iconToRightCustomHeight: string | number;
  @Input() additionalLabelStyling: any = {};
  @Input() label = "";

  isCaretUp = false;
  caretIcon: string;

  @Output() itemClick = new EventEmitter<any>();

  constructor() {}

  toggleCaretIcon(isOpen: boolean, event: any) {
    event.preventDefault();
    this.isCaretUp = isOpen;
    this.caretIcon = isOpen ? this.caretIconUp : this.caretIconDown;
  }

  onItemClick(event: any) {
    this.itemClick.emit(event);
  }

  ngOnInit() {
    this.caretIcon = this.caretIconDown;
  }

  toggleActionButton() {
    this.dropdownButton.toggle(!this.dropdownButton.isOpen);
  }
}
