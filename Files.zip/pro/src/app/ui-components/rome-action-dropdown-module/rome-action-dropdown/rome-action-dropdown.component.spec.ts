import { async, ComponentFixture, TestBed } from "@angular/core/testing";
import { RomeActionDropdownComponent } from "./rome-action-dropdown.component";
import { By } from "@angular/platform-browser";
import { CommonModule } from "@angular/common";
import { DropDownButtonModule } from "@progress/kendo-angular-buttons";
import { FormsModule } from "@angular/forms";
import { ButtonsModule } from "@progress/kendo-angular-buttons";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { DialogModule } from "@progress/kendo-angular-dialog";
import { DropDownsModule } from "@progress/kendo-angular-dropdowns";
import { InputsModule } from "@progress/kendo-angular-inputs";

describe("RomeActionDropdownComponent", () => {
  let component: RomeActionDropdownComponent;
  let fixture: ComponentFixture<RomeActionDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RomeActionDropdownComponent],
      imports: [
        CommonModule,
        FormsModule,
        DropDownButtonModule,
        ButtonsModule,
        DropDownsModule,
      ],
    }).compileComponents();
  }));
  const eventSpy = jasmine.createSpyObj("event", ["preventDefault"]);
  beforeEach(() => {
    fixture = TestBed.createComponent(RomeActionDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should have default @Input values", () => {
    //expect(component.buttonVisible).toBe(false);
    expect(component.dropDownItems).toEqual([]);
    expect(component.buttonLabel).toBe("");
    expect(component.icon).toBe("");
    expect(component.caretIconUp).toBe("");
    expect(component.caretIconDown).toBe("");
    expect(component.isDisabled).toBe(false);
    expect(component.type).toBe("button");
  });

  it("should set caretIcon to caretIconDown on init", () => {
    component.caretIconDown = "down-icon";
    component.ngOnInit();
    expect(component.caretIcon).toBe("down-icon");
  });

  it("should toggle caretIcon based on isOpen input", () => {
    component.caretIconUp = "up-icon";
    component.caretIconDown = "down-icon";

    component.toggleCaretIcon(true, eventSpy);
    expect(component.isCaretUp).toBeTrue();
    expect(component.caretIcon).toBe("up-icon");

    component.toggleCaretIcon(false, eventSpy);
    expect(component.isCaretUp).toBeFalse();
    expect(component.caretIcon).toBe("down-icon");
  });

  it("should emit itemClick event on onItemClick", () => {
    spyOn(component.itemClick, "emit");

    const event = { id: 1, name: "Test Item" };
    component.onItemClick(event);

    expect(component.itemClick.emit).toHaveBeenCalledWith(event);
  });
});
