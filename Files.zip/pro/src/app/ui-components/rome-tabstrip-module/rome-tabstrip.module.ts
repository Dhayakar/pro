import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RomeTabstripComponent } from './rome-tabstrip/rome-tabstrip.component';
import { ButtonsModule } from '@progress/kendo-angular-buttons';
import { TranslateModule } from '@ngx-translate/core';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { LayoutModule } from '@progress/kendo-angular-layout';

@NgModule({
  declarations: [
    RomeTabstripComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    ButtonsModule,
    DialogModule,
    LayoutModule
  ],
  exports: [
    RomeTabstripComponent
  ],
})
export class RomeTabstripModule { }
