import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RomeTabstripComponent } from "./rome-tabstrip.component";
import { TranslateModule, TranslateService } from "@ngx-translate/core";
import { RouterTestingModule } from "@angular/router/testing";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { LayoutModule } from "@progress/kendo-angular-layout";
import { TabProperties } from "@ui-components/model/tabstrip-data-item";
import { Routes } from "@angular/router";
import { MockModule } from "ng-mocks";

describe("RomeTabstripComponent", () => {
  let component: RomeTabstripComponent;
  let fixture: ComponentFixture<RomeTabstripComponent>;
  let tabData: TabProperties[] = [];

  class StubComponent {}

  const routes: Routes = [
    { path: "orders/grid/therapeutic", component: StubComponent },
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        MockModule(LayoutModule),
        MockModule(BrowserAnimationsModule),
        MockModule(BrowserAnimationsModule),
        TranslateModule.forRoot(),
        RouterTestingModule.withRoutes(routes),
      ],
      providers: [TranslateService],
      declarations: [RomeTabstripComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeTabstripComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  describe("ngOnInit Tests", () => {
    it("should set active tab", () => {
      tabData.push(new TabProperties("test", false, null, "test"));
      component.tabstripData = tabData;
      component.ngOnInit();

      expect(component.activeTab).toBe("test");
    });

    it("should not set active tab", () => {
      component.ngOnInit();

      expect(component.activeTab).toBe(null);
    });
  });

  describe("onSelect Tests", () => {
    it("should set active tab", () => {
      tabData.push(new TabProperties("test", false, null, "test"));
      component.tabstripData = tabData;
      component.ngOnInit();

      expect(component.activeTab).toBe("test");
    });

    it("should not set active tab", () => {
      component.ngOnInit();

      expect(component.activeTab).toBe(null);
    });
  });

  describe("getTitle Tests", () => {
    it("should set active tab", () => {
      tabData.push(new TabProperties("test", false, null, "test"));
      component.tabstripData = tabData;
      component.ngOnInit();

      expect(component.activeTab).toBe("test");
    });

    it("should not set active tab", () => {
      component.ngOnInit();

      expect(component.activeTab).toBe(null);
    });
  });

  describe("onSelect Tests", () => {
    beforeEach(() => {
      tabData.push(
        new TabProperties("test", false, null, "test"),
        new TabProperties(
          "test2",
          false,
          "orders/grid/therapeutic",
          "test2",
          "extra",
        ),
      );
      component.tabstripData = tabData;
    });

    it("should emit event when link provided", () => {
      spyOn(component.tabSelect, "emit");
      var event = { index: 1, prevented: false, title: "test2" };
      component.onSelect(event);

      expect(component.tabSelect.emit).toHaveBeenCalledWith({
        index: 1,
        prevented: false,
        title: "test2",
      });
    });

    it("should emit event when no link provided", () => {
      spyOn(component.tabSelect, "emit");
      var event = { index: 0, prevented: false, title: "test" };
      component.onSelect(event);

      expect(component.tabSelect.emit).toHaveBeenCalledWith({
        index: 0,
        prevented: false,
        title: "test",
      });
    });
  });
});
