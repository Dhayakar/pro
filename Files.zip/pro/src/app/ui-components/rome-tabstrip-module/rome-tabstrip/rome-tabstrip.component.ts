import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { TabProperties } from '../../model/tabstrip-data-item';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'rome-tabstrip',
  templateUrl: './rome-tabstrip.component.html',
  styleUrls: ['./rome-tabstrip.component.scss']
})

export class RomeTabstripComponent implements OnInit {
  @Input() tabstripData:TabProperties[];
  @Input() templates:TemplateRef<any>;
  @Input() activeTab: string = null;
  @Input() activeTabSelected: string;
  @Output() tabSelect = new EventEmitter();

  constructor(readonly router: Router,
    protected readonly translateService: TranslateService,
    ) { }

  ngOnInit() {
    if(this.activeTab == null && this.tabstripData != undefined){
      this.activeTab = this.tabstripData[0].readableName;
    }
  }

  onSelect(event){
    var properties = this.tabstripData[event.index];
    if(properties.link != null){
      this.tabSelect.emit(this.router.navigate([properties.link]));
    }
    else {
      this.tabSelect.emit(event);
    }
  }

  getTitle(tabDetails: TabProperties): string {
    let title = this.translateService.instant(tabDetails.header);
  
    if (tabDetails.additionalHeaderText)
      title += ` ${tabDetails.additionalHeaderText}`;
  
    return title;
  }
}
