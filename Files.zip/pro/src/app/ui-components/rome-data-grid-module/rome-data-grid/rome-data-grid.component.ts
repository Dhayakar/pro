import {
  Component,
  OnInit,
  ViewEncapsulation,
  Input,
  Output,
  EventEmitter,
  TemplateRef,
  ChangeDetectorRef,
  AfterViewInit,
  SimpleChanges,
} from "@angular/core";
import { RomeDataGridTitle } from "@shared/models/orders/grid/order-romeDataGridTitle";
import { SelectableSettings, SortSettings } from "@progress/kendo-angular-grid";
import { SortDescriptor } from "@progress/kendo-data-query";
import { AuthorisationService } from "@services/authorisation/authorisation.service";

export interface ColumnSetting {
  field: string;
  title: string;
  format?: string;
  type: any;
  minresizeablewidth?: number;
  width?: number;
  template?: any;
  sortable?: boolean;
  isHTML?: boolean;
}

@Component({
  selector: "rome-data-grid",
  templateUrl: "./rome-data-grid.component.html",
  encapsulation: ViewEncapsulation.None,
  styleUrls: ["./rome-data-grid.component.scss"],
})
export class RomeDataGridComponent implements OnInit, AfterViewInit {
  @Input() gridData: any;

  public columns: ColumnSetting[] = [];

  //Ordering
  @Input() reorderable: boolean = true;

  //Paging
  @Input() defaultPageSize: number = 10;

  @Input() selectedKeys: string[] = [];

  @Input() selectableObj: any;

  @Input() resizeable: boolean = true;
  @Input() isGridLoading: number = 0;
  @Input() sizes = [5, 10, 20, 50, 100];

  //Row Selection
  @Input() selectable: boolean = true;

  public selectableSettings: SelectableSettings = null;
  @Input() selectableMode: SelectableSettings = {
    checkboxOnly: true,
    mode: "multiple",
  };
  @Input() selectableColumnTitle: string = "";

  public sortSettings: SortSettings = null;
  public selectedRowItems: unknown[] = [];
  public rowSelectionIdentifier: any;
  public selectedRadioButton: any;

  //Edit
  @Input() editBtnRequired: boolean = true;

  //View
  @Input() viewBtnRequired: boolean = true;

  //Delete
  @Input() deleteBtnRequired: boolean = true;

  //Action Column
  public actionColVisible: boolean = false;

  //Pagination
  @Input() pagination: boolean = true;

  //sortable
  @Input() isSortable: any;

  //reorderable
  @Input() isReorderable: boolean = true;
  @Input() deSelectRow: boolean = false;
  @Input() sort: SortDescriptor[];
  @Input() selectAllState: string = "unchecked";
  @Input() template: TemplateRef<any>;
  @Input() customTemplatePrevDoseNoOrder: TemplateRef<any>;
  @Input() previousDoseNoOrdersFound: TemplateRef<any>;
  @Input() selectedOrderKeys: string[] = [];
  @Input() skip = 0;
  @Input() noRecordsFoundText: string = "orders.orders-grid.no-orders-found";
  @Input() showPagerInfo: boolean;
  @Input() isOrderCreation: boolean = false;
  @Input() isPreviousDose: boolean = false;
  @Input() showRadioButton: boolean = false;
  @Input() showRadioButtonTitle: string;

  @Input() showGridHeader: boolean;
  @Input() gridHeader: string = "";
  @Input() actionColumnRequired: boolean;
  @Input() actionColumnWidth: number = 172;
  @Input() isGenericTableUI: boolean = true;
  @Output() rowSelectEventHandler = new EventEmitter();
  @Output() pageChangeEventHandler = new EventEmitter();
  @Input() gridTitles: RomeDataGridTitle[];
  @Input() kendoHeaderRequired: boolean = true;
  @Output() onSelectAllChangeHandler = new EventEmitter();
  @Output() sortChangeHandler = new EventEmitter();
  @Input() shouldShowSelectAllCheckBox: boolean = false;
  @Output() selectionChange: EventEmitter<any> = new EventEmitter<any>();
  public gridDataProps: string[] = [];
  public gridDataLength: number;

  constructor(
    private cdr: ChangeDetectorRef,
    public authorisationService: AuthorisationService,
  ) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (this.deSelectRow == true) {
      this.selectedOrderKeys = [];
      this.selectedRowItems = [];
    }

    if (this.gridData) {
      this.gridDataLength =
        this.gridData.data === undefined
          ? this.gridData.length
          : this.gridData.data.length;
      this.actionColVisible = this.shouldShowActionColumn();
    }

    this.emitSelectedRadioButton();
  }

  private emitSelectedRadioButton() {
    if (
      this.showRadioButton &&
      this.gridData != undefined &&
      this.gridDataLength > 0
    ) {
      this.selectedRadioButton = this.gridData[0];
      this.selectionChange.emit(this.selectedRadioButton);
    }
  }

  ngOnInit() {
    if (this.gridData !== undefined) {
      this.gridDataLength =
        this.gridData.data === undefined
          ? this.gridData.length
          : this.gridData.data.length;
      if (this.gridDataLength > 0) {
        this.gridDataProps =
          this.gridData.data === undefined
            ? Object.keys(this.gridData[0])
            : Object.keys(this.gridData.data[0]);
        this.rowSelectionIdentifier = this.gridDataProps[0];

        this.gridDataProps.sort(
          (a, b) =>
            this.gridTitles.indexOf(
              this.gridTitles.find((t) => t.fieldName === a),
            ) -
            this.gridTitles.indexOf(
              this.gridTitles.find((t) => t.fieldName === b),
            ),
        );

        for (let prop of this.gridDataProps) {
          var availableObj = this.gridTitles.find((t) => t.fieldName === prop);
          if (availableObj) {
            const title = availableObj.title;
            const gridTitle = availableObj;
            const width = availableObj.width;
            const minResizeableWidth = availableObj.minResizeableWidth;
            this.columns.push({
              field: prop,
              title: title,
              type: "any",
              format: "",
              minresizeablewidth: minResizeableWidth,
              width: width,
              template: gridTitle.template,
              sortable: gridTitle.sortable ? true : false,
              isHTML: prop === "productName",
            });
          }
        }

        if (this.selectable) this.selectableSettings = this.selectableMode;
      }

      this.emitSelectedRadioButton();

      this.actionColVisible = this.shouldShowActionColumn();
    }
    if (this.gridTitles !== undefined && this.columns.length == 0) {
      for (let item of this.gridTitles) {
        this.columns.push({
          field: item.fieldName,
          title: item.title,
          type: "any",
          format: "",
          template: item.template,
          minresizeablewidth: item.minResizeableWidth,
          width: item.width,
          sortable: item.sortable ? true : false,
          isHTML: item.fieldName === "productName",
        });
      }
    }
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  public rowsSelected(args) {
    if (!this.selectable) return false;
    if (
      args.length == this.gridDataLength &&
      this.gridData.data[0].salesOrderNumber != null &&
      this.gridData.data.every((gridItem) =>
        args.includes(gridItem.salesOrderNumber),
      )
    )
      //Select All
      this.selectedRowItems =
        this.gridData.data === undefined
          ? this.gridData.filter((x) => !x["isCheckboxDisabled"])
          : this.gridData.data.filter((x) => !x["isCheckboxDisabled"]);
    else {
      let selectedItems = args.map((idx) => {
        let result =
          this.gridData.data === undefined
            ? this.gridData.find(
                (item) =>
                  item[
                    this.gridDataProps[
                      this.gridDataProps.indexOf(this.rowSelectionIdentifier)
                    ]
                  ] === idx,
              )
            : this.gridData.data.find(
                (item) =>
                  item[
                    this.gridDataProps[
                      this.gridDataProps.indexOf(this.rowSelectionIdentifier)
                    ]
                  ] === idx,
              );
        return result;
      });
      this.selectedRowItems = selectedItems.filter((x) => x !== undefined);
    }

    this.rowSelectEventHandler.emit(
      this.selectedRowItems != null && this.selectedRowItems.length > 0
        ? this.selectedRowItems
        : args,
    );
  }

  pageChangeHandler(args) {
    this.pageChangeEventHandler.emit(args);
  }

  public onSelectAllChange(args): void {
    this.onSelectAllChangeHandler.emit(args);
  }

  sortChange(args) {
    this.sortChangeHandler.emit(args);
  }

  public isCheckboxDisabled(args): boolean {
    return args.isCheckboxDisabled;
  }

  public isSelectAllCheckBoxDisabled(data: any): boolean {
    return !data.some((dataItem: any) => !dataItem.isCheckboxDisabled);
  }

  private shouldShowActionColumn() {
    return (
      this.editBtnRequired ||
      this.viewBtnRequired ||
      this.deleteBtnRequired ||
      this.actionColumnRequired
    );
  }

  hasPermission(claim: string): boolean {
    return this.authorisationService.currentUser.checkClaim(claim);
  }

  onRadioButtonChange(dataItem: any) {
    this.selectedRadioButton = dataItem;
    this.selectionChange.emit(this.selectedRadioButton);
  }
}
