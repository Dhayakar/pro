import { ComponentFixture, TestBed } from "@angular/core/testing";
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { RouterTestingModule } from "@angular/router/testing";
import { TranslateModule } from "@ngx-translate/core";
import { RomeDataGridComponent } from "./rome-data-grid.component";
import { GridModule } from "@progress/kendo-angular-grid";
import { configureTestSuite } from "ng-bullet";
import { RomeTooltipDirective } from "@ui-components/rome-tooltip/rome-tooltip/rome-tooltip-directive/rome-tooltip.directive";
import { MockDirective, MockModule } from "ng-mocks";
import { AuthorisationServiceMock } from "@shared/mocks/services/authorisation.service.mock";
import { RolesEnum } from "@shared/enums/roles-enum";
import { AuthorisationService } from "@services/authorisation/authorisation.service";
import { SimpleChange } from "@angular/core";
import { OrderByTreatmentId } from "@shared/models/orders/edit-multiple/order-edit-multiple";

describe("RomeDataGridComponent", () => {
  let component: RomeDataGridComponent;
  let fixture: ComponentFixture<RomeDataGridComponent>;
  let authServiceMock =
    new AuthorisationServiceMock().createAuthorisationServiceMock(
      RolesEnum.ROLE_SERVICE_ADMIN,
      true,
    );

  configureTestSuite(() => {
    TestBed.configureTestingModule({
      imports: [
        MockModule(CommonModule),
        MockModule(HttpClientModule),
        MockModule(GridModule),
        RouterTestingModule,
        TranslateModule.forRoot(),
      ],
      declarations: [
        RomeDataGridComponent,
        MockDirective(RomeTooltipDirective),
      ],
      providers: [{ provide: AuthorisationService, useValue: authServiceMock }],
    }).compileComponents();
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RomeDataGridComponent],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeDataGridComponent);
    component = fixture.componentInstance;
    component.gridData = { data: [], total: 0 };
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  describe("ngOnChanges tests", () => {
    it("should reset selectOrderkey and selectRowitems, if deselectRow flag has updated as true", () => {
      component.deSelectRow = true;

      component.selectedOrderKeys = ["ORDER1", "ORDER2"];
      component.selectedRowItems = [
        new OrderByTreatmentId(),
        new OrderByTreatmentId(),
      ];

      component.ngOnChanges({
        deSelectRow: new SimpleChange(false, component.deSelectRow, false),
      });
      expect(component.selectedOrderKeys.length).toEqual(0);
      expect(component.selectedRowItems.length).toEqual(0);
    });

    it("should not reset selectOrderkey and selectRowitems, if deselectRow flag has not updated or updated as false", () => {
      component.deSelectRow = false;

      component.selectedOrderKeys = ["ORDER1", "ORDER2"];
      component.selectedRowItems = [
        new OrderByTreatmentId(),
        new OrderByTreatmentId(),
      ];

      component.ngOnChanges({
        deSelectRow: new SimpleChange(true, component.deSelectRow, false),
      });
      expect(component.selectedOrderKeys.length).toEqual(2);
      expect(component.selectedRowItems.length).toEqual(2);
    });

    it("Should assign the selected radio button details when radio button column is displayed in a grid", () => {
      component.deSelectRow = true;
      component.showRadioButton = true;
      component.gridData = { data: ["order1"], total: 1 };
      component.gridDataLength = 1;
      component.ngOnChanges({
        deSelectRow: new SimpleChange(false, component.deSelectRow, false),
      });
      expect(component.selectedRadioButton).toEqual(component.gridData[0]);
    });
  });

  describe("onRadioButtonChange test", () => {
    it("should emit selectedRow and call onClose when onUseSelectedDose is called", () => {
      let selectionChangeSpy: jasmine.Spy;
      selectionChangeSpy = spyOn(component.selectionChange, "emit");

      component.onRadioButtonChange(["order1"]);

      expect(selectionChangeSpy).toHaveBeenCalledWith(
        component.selectedRadioButton,
      );
    });
  });
});
