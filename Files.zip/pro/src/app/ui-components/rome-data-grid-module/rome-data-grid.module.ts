import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RomeDataGridComponent } from "./rome-data-grid/rome-data-grid.component";
import {
  DomEventsService,
  GridModule,
  LocalDataChangesService,
  SelectionService,
} from "@progress/kendo-angular-grid";
import { TranslateModule } from "@ngx-translate/core";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";

@NgModule({
  declarations: [RomeDataGridComponent],
  imports: [CommonModule, GridModule, TranslateModule, RomeTooltipModule],
  providers: [SelectionService, DomEventsService, LocalDataChangesService],
  exports: [RomeDataGridComponent],
})
export class RomeDataGridModule {}
