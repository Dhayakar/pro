export interface DropdownDataItem {
    id: number | string;
    description: string;
    isDisabled: boolean;
}
