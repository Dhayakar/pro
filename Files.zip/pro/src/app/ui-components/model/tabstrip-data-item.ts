export class TabProperties {
    public header: string;
    public disabled: boolean = false;
    public link: string = null;
    public readableName: string = null;
    public additionalHeaderText: string = null;

    constructor(header: string, disabled: boolean, link: string = null, readableName: string = null,
        additionalHeaderText: string = null) {
    
        this.header = header;
        this.readableName = readableName
        this.disabled = disabled;
        this.link = link;
        this.additionalHeaderText = additionalHeaderText;
    }
}