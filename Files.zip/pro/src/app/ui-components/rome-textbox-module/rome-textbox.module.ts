import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { DirectiveModule } from "@shared/directives/directive.module";
import { ValidatorModule } from "@shared/validator/validator.module";
import { RomeNumericTextboxComponent } from "./rome-numeric-textbox/rome-numeric-textbox.component";
import { RomeTextboxComponent } from "./rome-textbox/rome-textbox.component";

@NgModule({
  declarations: [RomeTextboxComponent, RomeNumericTextboxComponent],
  imports: [
    CommonModule,
    FormsModule,
    TranslateModule,
    InputsModule,
    LabelModule,
    ValidatorModule,
    DirectiveModule,
  ],
  exports: [RomeTextboxComponent, RomeNumericTextboxComponent],
})
export class RomeTextboxModule {}
