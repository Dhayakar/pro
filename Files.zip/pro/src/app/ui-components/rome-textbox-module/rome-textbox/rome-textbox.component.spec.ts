import { ComponentFixture, TestBed } from "@angular/core/testing";
import { RomeTextboxComponent } from "./rome-textbox.component";
import { FormsModule, NgForm } from "@angular/forms";
import { MockModule } from "ng-mocks";
import { CommonModule } from "@angular/common";
import { TranslateModule } from "@ngx-translate/core";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { ValidatorModule } from "@shared/validator/validator.module";
import { DirectiveModule } from "@shared/directives/directive.module";

describe("RomeInputFieldsComponent", () => {
  let component: RomeTextboxComponent;
  let fixture: ComponentFixture<RomeTextboxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RomeTextboxComponent],
      imports: [
        MockModule(CommonModule),
        MockModule(FormsModule),
        MockModule(TranslateModule),
        MockModule(InputsModule),
        MockModule(LabelModule),
        MockModule(ValidatorModule),
        MockModule(DirectiveModule),
      ],
      providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeTextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
