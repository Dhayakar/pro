import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  ViewEncapsulation,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
  selector: "rome-textbox",
  templateUrl: "./rome-textbox.component.html",
  styleUrls: ["./rome-textbox.component.scss"],
  encapsulation: ViewEncapsulation.None,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeTextboxComponent implements OnInit {
  @Input() submitted: boolean = false;
  @Input() inputLabel: string;
  @Input() inputLabelClass: string = "'label-text'";
  @Input() inputText: string = "Input Text";
  @Input() inputClassName: string = "'field-box'";
  @Input() inputReference: string = "input-field";
  @Input() isDisabled: boolean = false;
  @Input() isReadOnly: boolean = false;
  @Input() isRequired: boolean = false;
  @Input() requiredMessage: string = "Assistive";
  @Input() validationMessage: string;
  @Input() ngModelValue: string;
  @Input() maxLength: number = 255;
  @Input() minLength: number = 0;
  @Input() trim: string = null;
  @Input() displaySideLabel: boolean = true;
  @Input() labelInputWidth: string = "130";
  @Input() hasPlaceholder: boolean = false;
  @Input() displayTopLabel: boolean = true;
  @Input() shouldApplyNumberOnlyValidation: boolean = false;
  @Input() shouldApplyEmailValidation: boolean = false;
  @Input() shouldApplyPapVoucherCodeValidation: boolean = false;
  @Output() ngModelValueChange = new EventEmitter();
  @Input() prefixValue: string = "";
  @Output() keyPressEvent = new EventEmitter<any>();
  @Output() blurEvent = new EventEmitter();

  constructor(
    public control: NgForm,
    private cdr: ChangeDetectorRef,
  ) {}

  ngOnInit() {}

  public onChange() {
    this.ngModelValueChange.emit(this.ngModelValue);
  }

  public keyPress(data: any) {
    if (this.keyPressEvent.observers.length > 0) {
      this.keyPressEvent.emit(data);
    }
  }

  public blur() {
    if (this.ngModelValue) this.ngModelValue = this.ngModelValue.trim();
    this.onChange();

    this.blurEvent.emit();
  }

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }
}
