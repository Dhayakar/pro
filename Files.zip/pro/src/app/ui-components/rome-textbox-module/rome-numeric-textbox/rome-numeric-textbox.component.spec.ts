import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { CommonModule } from "@angular/common";
import { FormsModule, NgForm } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import { InputsModule } from "@progress/kendo-angular-inputs";
import { LabelModule } from "@progress/kendo-angular-label";
import { DirectiveModule } from "@shared/directives/directive.module";
import { ValidatorModule } from "@shared/validator/validator.module";
import { MockModule } from "ng-mocks";
import { RomeNumericTextboxComponent } from "./rome-numeric-textbox.component";

describe("RomeNumericTextboxComponent", () => {
  let component: RomeNumericTextboxComponent;
  let fixture: ComponentFixture<RomeNumericTextboxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RomeNumericTextboxComponent],
      imports: [
        MockModule(CommonModule),
        MockModule(FormsModule),
        MockModule(TranslateModule),
        MockModule(InputsModule),
        MockModule(LabelModule),
        MockModule(ValidatorModule),
        MockModule(DirectiveModule),
      ],
      providers: [{ provide: NgForm, useValue: new NgForm([], []) }],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeNumericTextboxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });

  it("should emit coorect value", () => {
    spyOn(component.ngModelValueChange, "emit");
    spyOn(component.valueChange, "emit");

    component.onValueChange("Test Data");

    expect(component.ngModelValueChange.emit).toHaveBeenCalledWith("Test Data");
    expect(component.valueChange.emit).toHaveBeenCalledWith("Test Data");
  });
});
