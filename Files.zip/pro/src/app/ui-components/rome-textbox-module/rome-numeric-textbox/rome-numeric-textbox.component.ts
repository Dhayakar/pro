import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  ViewEncapsulation,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";

@Component({
  selector: "rome-numeric-textbox",
  templateUrl: "./rome-numeric-textbox.component.html",
  styleUrls: ["./rome-numeric-textbox.component.scss"],
  encapsulation: ViewEncapsulation.None,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeNumericTextboxComponent implements OnInit {
  @Input() displaySideLabel: boolean;
  @Input() labelInputWidth: string;
  @Input() inputLabelClass: string;
  @Input() inputLabel: string;
  @Input() isRequired: boolean;
  @Input() isDisabled: boolean;
  @Input() displayTopLabel: boolean;
  @Input() ngModelValue: any;
  @Input() inputIdentifier: string = "numeric-input";
  @Input() min: number;
  @Input() max: number;
  @Input() autoCorrect: boolean;
  @Input() decimal: number;
  @Input() format: string;
  @Input() requiredMessage: string;

  @Output() valueChange = new EventEmitter();
  @Output() ngModelValueChange = new EventEmitter<any>();

  constructor(public control: NgForm) {}

  ngOnInit() {}

  onValueChange(data) {
    this.ngModelValueChange.emit(data);
    this.valueChange.emit(data);
  }
}
