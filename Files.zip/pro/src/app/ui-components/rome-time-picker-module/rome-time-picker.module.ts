import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { FormsModule } from '@angular/forms';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { RomeTimePickerComponent } from './rome-time-picker/rome-time-picker.component';
import { LabelModule } from '@progress/kendo-angular-label';

@NgModule({
  declarations: [
    RomeTimePickerComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    FormsModule,
    DateInputsModule,
    LabelModule
  ],
  exports: [
    RomeTimePickerComponent
  ]
})
export class RomeTimePickerModule { }
