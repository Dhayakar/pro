import { Component, HostListener} from '@angular/core';
import { EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { ControlContainer, NgForm } from '@angular/forms';
import { UserPreferencesService } from '@services/user-preferences/user-preferences.service';

@Component({
  selector: 'rome-time-picker',
  templateUrl: './rome-time-picker.component.html',
  styleUrls: ['./rome-time-picker.component.scss'],
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }]
})
export class RomeTimePickerComponent {
  @ViewChild('timepicker', { static: false }) timepicker: any;
  @Input() time: Date;
  @Output() timeChange: EventEmitter<Date> = new EventEmitter<Date>();
  @Input() minTime: Date;
  @Input() maxTime: Date;
  @Input() identifier: string;
  @Input() timeZoneDescription: string;
  @Input() disabled: boolean = false;
  @Input() required: boolean = false;
  @Input() requiredMessage: string;
  @Input() submitted: boolean;
  @Input() rangeValidation: boolean = false;
  @Input() steps: any;
  @Input() pattern: string;
  @Input() placeholder: string;
  @Input() formatPlaceholder: any;
  @Input() ngClass: any;
  @Input() rangeErrorMessage:string;
  @Input() displaySideLabel:boolean=false;
  @Input() displayHeader:boolean=true;
  @Input() timePickerLabel: string='';
  constructor(public control: NgForm,readonly userPreferences: UserPreferencesService) {
  }

  shouldShowTimeZone: boolean = true;

  ngOnInit() {
    if (!this.steps) {
      this.steps = { minute: 15 }
    }
    if (!this.pattern) {
      this.pattern = "^.*([0-9]{2}):(00|15|30|45):([0-9]{2}).*$"
    }
    if (!this.placeholder) {
      this.placeholder = "hh:mm"
    }
    if (!this.formatPlaceholder) {
      this.formatPlaceholder = { hour: 'hh', minute: 'mm'};
    }
    if(window.screen.width < 1170){
      this.shouldShowTimeZone = false;
    }
  
  }
  openTimepicker(): void {
    this.timepicker.toggle(true);
    this.timepicker.focus();
  }
  handleTimeChange(): void {
    this.timeChange.emit(this.time);
  }

  @HostListener('window:resize', ['$event'])onResize(event) {
    if(window.screen.width < 1170){
      this.shouldShowTimeZone = false;
    }
    else{
      this.shouldShowTimeZone = true;
    }
  }

}
