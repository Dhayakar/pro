import { ComponentFixture, TestBed } from "@angular/core/testing";

import { RomeButtonComponent } from "./rome-button.component";
import { MockModule } from "ng-mocks";
import { ButtonsModule } from "@progress/kendo-angular-buttons";

describe("RomeButtonComponent", () => {
  let component: RomeButtonComponent;
  let fixture: ComponentFixture<RomeButtonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RomeButtonComponent],
      imports: [MockModule(ButtonsModule)],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeButtonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
