import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';

@Component({
  selector: 'rome-button',
  templateUrl: './rome-button.component.html',
  styleUrls: ['./rome-button.component.scss']
})
export class RomeButtonComponent implements OnInit {
  @ViewChild('romeButton', {static:false}) romeButton: ElementRef;
  @Output() onClick  = new EventEmitter<any>();
  @Input() label: string;
  @Input() icon: string ="";
  @Input() iconRightToLabel: string ="";
  @Input() buttonType:string;
  @Input() isDisabled:boolean=false;
  @Input() type: string = 'button'
  @Input() iconCustomWidth: string;
  @Input() iconCustomHeight: string;
  @Input() customWidth: string;
  @Input() customHeight: string;
  @Input() customMinHeight: string;
  @Input() title: string;
  @Input() iconToRightCustomWidth: string;
  @Input() iconToRightCustomHeight: string;
  @Input() additionalLabelStyling: any = {};
  constructor() { }

  ngOnInit() {
  }

  onClickButton(event : any) {
    this.onClick.emit(event);
   this.romeButton.nativeElement.blur();
  }

}
