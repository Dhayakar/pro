import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RomeButtonComponent } from "./rome-button/rome-button.component";
import { ButtonsModule } from "@progress/kendo-angular-buttons";

@NgModule({
  declarations: [RomeButtonComponent],
  imports: [CommonModule, ButtonsModule],
  exports: [RomeButtonComponent],
})
export class RomeButtonModule {}
