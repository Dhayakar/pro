import {
  ApplicationRef,
  ComponentFactoryResolver,
  ComponentRef,
  Directive,
  ElementRef,
  EmbeddedViewRef,
  HostListener,
  Injector,
  Input,
  TemplateRef,
} from "@angular/core";
import { RomeTooltipComponent } from "../rome-tooltip.component";

@Directive({
  selector: "[romeTooltip]",
})
export class RomeTooltipDirective {
  @Input() romeTooltip = "";
  @Input() romeTooltipTemplate: TemplateRef<any>;
  @Input() romeTooltipArrow: boolean = false;
  @Input() romeTooltipIsClick: boolean = false;
  @Input() romeTooltipShowTop: boolean = false;
  @Input() romeTooltipOnHover: boolean = false;
  @Input() romeTooltipShowBottom: boolean = false;
  @Input() romeTooltipShowLeft: boolean = false;
  @Input() romeTooltipWhiteSpace: boolean = false;
  @Input() romeTooltipIsEnabled: boolean = true;
  @Input() romeTooltipApplyMaxWidth: boolean = false;

  private componentRef: ComponentRef<RomeTooltipComponent> = null;
  private xCoordinate: number;
  private yCoordinate: number;
  private initialWindowClick: boolean;

  constructor(
    private elementRef: ElementRef,
    private appRef: ApplicationRef,
    private componentFactoryResolver: ComponentFactoryResolver,
    private injector: Injector,
  ) {}

  @HostListener("mouseenter")
  onMouseEnter(): void {
    if (this.romeTooltipIsClick === false) {
      this.showToolTip(500);
    }
  }

  @HostListener("click")
  onClick(): void {
    if (this.romeTooltipIsClick === true) {
      this.initialWindowClick = false;
      this.showToolTip(0);
    }
  }

  @HostListener("mousemove", ["$event"]) onMouseMove(event) {
    this.xCoordinate = event.clientX;
    this.yCoordinate = event.clientY;
  }

  private setTooltipComponentProperties() {
    if (this.componentRef !== null) {
      this.componentRef.instance.romeTooltip = this.romeTooltip;
      this.componentRef.instance.romeTooltipTemplate = this.romeTooltipTemplate;
      this.componentRef.instance.romeTooltipArrow = this.romeTooltipArrow;
      this.componentRef.instance.romeTooltipOnHover = this.romeTooltipOnHover;
      this.componentRef.instance.romeTooltipShowBottom =
        this.romeTooltipShowBottom;
      this.componentRef.instance.romeTooltipShowLeft = this.romeTooltipShowLeft;
      this.componentRef.instance.romeTooltipWhiteSpace =
        this.romeTooltipWhiteSpace;
      this.componentRef.instance.romeTooltipIsClick = this.romeTooltipIsClick;
      this.componentRef.instance.romeTooltipIsEnabled =
        this.romeTooltipIsEnabled;
      this.componentRef.instance.romeTooltipApplyMaxWidth =
        this.romeTooltipApplyMaxWidth;

      const { right, top, bottom, left } =
        this.elementRef.nativeElement.getBoundingClientRect();
      if (this.romeTooltipShowTop) {
        this.componentRef.instance.left = Math.round(
          (right - left) / 2 + left - 50,
        );
        this.componentRef.instance.top = Math.round(top - 45);
      } else if (this.romeTooltipOnHover) {
        this.componentRef.instance.left = Math.round(this.xCoordinate + 20);
        this.componentRef.instance.top = Math.round(this.yCoordinate + 20);
      } else if (this.romeTooltipShowBottom) {
        this.componentRef.instance.left = Math.round(
          (right - left) / 2 + left - 50,
        );
        this.componentRef.instance.top = Math.round(
          top + (bottom - top) / 2 + 20,
        );
      } else if (this.romeTooltipShowLeft) {
        this.componentRef.instance.left = Math.round(left - 278);
        this.componentRef.instance.top = Math.round(this.yCoordinate + 5);
      } else {
        this.componentRef.instance.left = Math.round(right);
        this.componentRef.instance.top = Math.round(top + (bottom - top) / 2);
      }
    }
  }

  private showToolTip(delay: number) {
    if (this.componentRef === null) {
      const componentFactory =
        this.componentFactoryResolver.resolveComponentFactory(
          RomeTooltipComponent,
        );
      this.componentRef = componentFactory.create(this.injector);
      this.appRef.attachView(this.componentRef.hostView);
      const domElement = (this.componentRef.hostView as EmbeddedViewRef<any>)
        .rootNodes[0] as HTMLElement;
      document.body.appendChild(domElement);

      setTimeout(() => {
        this.setTooltipComponentProperties();
      }, delay);
    } else {
      this.destroy();
    }
  }

  @HostListener("mouseleave")
  onMouseLeave(): void {
    if (this.romeTooltipIsClick === false) {
      this.destroy();
    }
  }

  ngOnDestroy(): void {
    this.destroy();
  }

  private destroy(): void {
    if (this.componentRef !== null) {
      this.appRef.detachView(this.componentRef.hostView);
      this.componentRef.destroy();
      this.componentRef = null;
    }
  }
}
