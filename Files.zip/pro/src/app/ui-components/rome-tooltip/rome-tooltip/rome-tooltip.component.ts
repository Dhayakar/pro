import { Component, TemplateRef, ViewChild } from "@angular/core";

@Component({
  selector: "rome-tooltip",
  templateUrl: "./rome-tooltip.component.html",
  styleUrls: ["./rome-tooltip.component.scss"],
})
export class RomeTooltipComponent {
  romeTooltip: string = "";
  romeTooltipTemplate: TemplateRef<any>;
  romeTooltipArrow: boolean;
  romeTooltipIsClick: boolean;
  romeTooltipShowBottom: boolean;
  romeTooltipShowLeft: boolean;
  romeTooltipWhiteSpace: boolean;
  left: number = 0;
  right: number = 0;
  top: number = 0;
  romeTooltipOnHover: boolean;
  romeTooltipIsEnabled: boolean = true;
  romeTooltipApplyMaxWidth: boolean;

  @ViewChild("tooltipElement", { static: false }) tooltipElement: any;

  constructor() {}
}
