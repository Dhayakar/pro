import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RomeTooltipComponent } from './rome-tooltip.component';

describe('RomeTooltipComponent', () => {
  let component: RomeTooltipComponent;
  let fixture: ComponentFixture<RomeTooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RomeTooltipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
