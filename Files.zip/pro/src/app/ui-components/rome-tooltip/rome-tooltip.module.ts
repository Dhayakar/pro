import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RomeTooltipDirective } from './rome-tooltip/rome-tooltip-directive/rome-tooltip.directive';
import { RomeTooltipComponent } from './rome-tooltip/rome-tooltip.component';

@NgModule({
  declarations: [
    RomeTooltipComponent,
    RomeTooltipDirective
  ],
  imports: [
    CommonModule
  ],
  exports: [
    RomeTooltipComponent,
    RomeTooltipDirective
  ]
})
export class RomeTooltipModule { }
