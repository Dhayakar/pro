import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RomeWidgetComponent } from "./rome-widget/rome-widget.component";

@NgModule({
  declarations: [RomeWidgetComponent],
  imports: [CommonModule],
  exports: [RomeWidgetComponent],
})
export class RomeWidgetModule {}
