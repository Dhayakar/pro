import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RomeWidgetComponent } from './rome-widget.component';

describe('RomeWidgetComponent', () => {
  let component: RomeWidgetComponent;
  let fixture: ComponentFixture<RomeWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RomeWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
