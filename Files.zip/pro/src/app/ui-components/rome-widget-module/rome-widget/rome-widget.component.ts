import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'rome-widget',
  templateUrl: './rome-widget.component.html',
  styleUrls: ['./rome-widget.component.scss']
})
export class RomeWidgetComponent {
  @Output() onClick  = new EventEmitter<any>();
  @Input() headerLabel: string;
  @Input() subheaderLabel: string ="";
  @Input() itemQuantity: string='';
  @Input() isExternalUserShortWidget:boolean=false;
  @Input() isWarningWidget: boolean = false;
  
  constructor() { }

  onClickButton(event : any) {
    this.onClick.emit(event);
  }
}