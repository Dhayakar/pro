import { ComponentFixture, TestBed } from "@angular/core/testing";
import { CommonModule } from "@angular/common";
import { FormsModule, NgForm } from "@angular/forms";
import { PipesModule } from "src/app/shared/pipes/pipesModule";
import { TranslateService } from "@ngx-translate/core";
import { TranslateModule } from "@ngx-translate/core";
import { DateInputsModule } from "@progress/kendo-angular-dateinputs";
import { RemoveTimeFromDatePipe } from "@shared/pipes/removeTimeFromDate/remove-time-from-date.pipe";
import { LocalizationService } from "@progress/kendo-angular-l10n";
import { L10N_PREFIX } from "@progress/kendo-angular-l10n";
import { RomeDatePickerComponent } from "./rome-date-picker.component";
import { DatepickerYearDisplayComponent } from "./datepicker-year-display/datepicker-year-display.component";
import { UserPreferencesService } from "@services/user-preferences/user-preferences.service";
import { RomeTooltipDirective } from "@ui-components/rome-tooltip/rome-tooltip/rome-tooltip-directive/rome-tooltip.directive";
import { MockComponent, MockDirective, MockModule } from "ng-mocks";
import { LabelModule } from "@progress/kendo-angular-label";
import { HttpClientModule } from "@angular/common/http";
import { UserPreferencesServiceMock } from "@shared/mocks/services/user-preferences/user-preferences.service.mock";

describe("RomeDatePickerComponent", () => {
  let component: RomeDatePickerComponent;
  let fixture: ComponentFixture<RomeDatePickerComponent>;
  const userPreferencesServiceMock = new UserPreferencesServiceMock();

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        MockModule(CommonModule),
        MockModule(FormsModule),
        TranslateModule.forRoot(),
        MockModule(DateInputsModule),
        MockModule(PipesModule),
        MockModule(LabelModule),
        MockModule(HttpClientModule),
      ],
      providers: [
        LocalizationService,
        { provide: L10N_PREFIX, useValue: "" },
        TranslateService,
        RemoveTimeFromDatePipe,
        UserPreferencesService,
        NgForm,
        {
          provide: UserPreferencesService,
          useValue: userPreferencesServiceMock.getMockedService(),
        },
      ],
      declarations: [
        RomeDatePickerComponent,
        MockComponent(DatepickerYearDisplayComponent),
        MockDirective(RomeTooltipDirective),
      ],
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeDatePickerComponent);
    component = fixture.componentInstance;
    userPreferencesServiceMock.setPreferredDateFormat("dd MMM yyyy");
    fixture.detectChanges();
  });

  it("should create", () => {
    expect(component).toBeTruthy();
  });
});
