import { formatDate } from "@angular/common";
import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
  ViewEncapsulation,
} from "@angular/core";
import { ControlContainer, NgForm } from "@angular/forms";
import { TranslateService } from "@ngx-translate/core";
import { UserPreferencesService } from "@services/user-preferences/user-preferences.service";
import { TimeZoneHelperService } from "@shared/helpers/timeZone.helper.service";

@Component({
  selector: "rome-date-picker",
  templateUrl: "./rome-date-picker.component.html",
  styleUrls: ["./rome-date-picker.component.scss"],
  encapsulation: ViewEncapsulation.None,
  viewProviders: [{ provide: ControlContainer, useExisting: NgForm }],
})
export class RomeDatePickerComponent {
  minDate: Date = new Date(2016, 0, 1);
  public preferredLanguage: string;

  @Input() date: Date;
  @Input() identifier: string = "identifier";
  @Input() submitted: boolean;
  @Input() disabled: boolean = false;
  @Input() required: boolean = false;
  @Input() requiredMessage: string;
  @Input() format: string;
  @Input() focusedDate: Date;
  @Input() min: Date;
  @Output() dateChange: EventEmitter<Date> = new EventEmitter<Date>();
  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();
  @Input() showClearButton: boolean;
  @Input() datePickerLabel: string;
  @Input() displaySideLabel: boolean = false;
  @Input() displayHeader: boolean = true;
  @Output() open: EventEmitter<void> = new EventEmitter<void>();

  constructor(
    public control: NgForm,
    public readonly userPreferences: UserPreferencesService,
    public readonly timeZoneHelperService: TimeZoneHelperService,
    public readonly translateService: TranslateService,
  ) {}

  @ViewChild("datepicker", { static: false }) datepicker: any;

  openDatepicker(): void {
    this.datepicker.toggle(true);
    this.datepicker.focus();
    this.open.emit();
  }

  clearDatepicker() {
    this.date = null;
    this.handleDateChange();
  }

  getFocusedDate(): Date {
    return null;
  }

  isDateSelected(date: Date): boolean {
    return this.datesMatch(date, this.date);
  }

  protected datesMatch(dateOne: Date, dateTwo: Date): boolean {
    if (dateOne == null || dateTwo == null) {
      return false;
    }

    return (
      formatDate(dateOne, "MM-dd-yyyy", "en-US") ===
      formatDate(dateTwo, "MM-dd-yyyy", "en-US")
    );
  }

  handleDateChange(): void {
    this.dateChange.emit(this.date);
  }

  getDateTooltip(date: Date): string {
    return this.userPreferences.getLocalizedDate(date, "fullDate");
  }
}
