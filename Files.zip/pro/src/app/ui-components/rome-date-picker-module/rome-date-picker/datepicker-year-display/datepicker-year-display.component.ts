import { Component, OnInit, Input } from '@angular/core';
import { UserPreferencesService } from '@services/user-preferences/user-preferences.service';

@Component({
  selector: 'app-datepicker-year-display',
  templateUrl: './datepicker-year-display.component.html',
  styleUrls: ['./datepicker-year-display.component.scss']
})
export class DatepickerYearDisplayComponent implements OnInit {

  @Input() activeView: string;
  @Input() date: Date;
  @Input() title: String;

  constructor(public userPreferences: UserPreferencesService) { }

  ngOnInit() {
  }

  inMonthView(activeView: string) {
    return (activeView == "month");
  }

  isJanuary(date: Date) {
    return (date.getMonth() == 0);
  }
}
