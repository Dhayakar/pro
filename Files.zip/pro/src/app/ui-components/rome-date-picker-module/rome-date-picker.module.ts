import { NgModule} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PipesModule } from 'src/app/shared/pipes/pipesModule';
import { TranslateService } from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { RomeDatePickerComponent } from './rome-date-picker/rome-date-picker.component';
import { DateInputsModule } from '@progress/kendo-angular-dateinputs';
import { RemoveTimeFromDatePipe } from '@shared/pipes/removeTimeFromDate/remove-time-from-date.pipe';
import { LocalizationService } from '@progress/kendo-angular-l10n';
import { L10N_PREFIX } from '@progress/kendo-angular-l10n';
import { DatepickerYearDisplayComponent } from './rome-date-picker/datepicker-year-display/datepicker-year-display.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LabelModule } from '@progress/kendo-angular-label';
import { RomeTooltipModule } from '@ui-components/rome-tooltip/rome-tooltip.module';
  
@NgModule({
  declarations: [
    RomeDatePickerComponent,
    DatepickerYearDisplayComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    TranslateModule,
    DateInputsModule,
    PipesModule,
    ReactiveFormsModule,
    RomeTooltipModule,
    LabelModule
  ],
  providers: [
    LocalizationService,
    { provide: L10N_PREFIX, useValue: '' },
    TranslateService,
    RemoveTimeFromDatePipe
  ],
  exports: [
    RomeDatePickerComponent,
    DatepickerYearDisplayComponent
  ]
})
export class RomeDatePickerModule { }