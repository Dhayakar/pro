import { async, ComponentFixture, TestBed } from "@angular/core/testing";

import { RomeBannerComponent } from "./rome-banner.component";
import { RomeButtonComponent } from "@ui-components/rome-button-module/rome-button/rome-button.component";
import { RomeTooltipModule } from "@ui-components/rome-tooltip/rome-tooltip.module";
import { TranslateModule } from "@ngx-translate/core";
import { PipesModule } from "@shared/pipes/pipesModule";
import { MockComponent, MockModule } from "ng-mocks";

describe("RomeBannerComponent", () => {
  let component: RomeBannerComponent;
  let fixture: ComponentFixture<RomeBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MockModule(RomeTooltipModule),
        MockModule(PipesModule),
        TranslateModule.forRoot(),
      ],
      declarations: [RomeBannerComponent, MockComponent(RomeButtonComponent)],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RomeBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it("should toggle showAttachmentList value", () => {
    component.showAttachmentList = false;
    component.toggleAttachmentList();
    expect(component.showAttachmentList).toBeTrue();
    component.toggleAttachmentList();
    expect(component.showAttachmentList).toBeFalse();
  });
});
