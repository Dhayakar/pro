import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ButtonsConst } from '@shared/consts/button-const';

@Component({
  selector: 'app-rome-banner',
  templateUrl: './rome-banner.component.html',
  styleUrls: ['./rome-banner.component.scss']
})
export class RomeBannerComponent {

  @Input() bannerText: string;
  @Input() attachments: string[] = [];
  @Input() productTypeId: number;
  @Input() customStyles;
  @Output() attachmentClick = new EventEmitter<string>();

  secondary_info_icon: string = ButtonsConst.BLUECOLOR_DOWNLOAD_ICON;
  secondaryButton: string = ButtonsConst.SECONDARY_BUTTON;
  showAttachmentList: boolean;

  toggleAttachmentList() {
    this.showAttachmentList = !this.showAttachmentList;
  }

  onAttachmentClick(attachment: any) {
    this.attachmentClick.emit(attachment);
  }

  
}