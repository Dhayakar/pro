import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core';
import { RomeTooltipModule } from '@ui-components/rome-tooltip/rome-tooltip.module';
import { RomeBannerComponent } from './rome-banner/rome-banner.component';
import { RomeButtonModule } from '@ui-components/rome-button-module/rome-button.module';
import { PipesModule } from '@shared/pipes/pipesModule';


@NgModule({
  declarations: [
    RomeBannerComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    RomeTooltipModule,
    RomeButtonModule,
    PipesModule
  ],
  exports:[
    RomeBannerComponent
  ]
})
export class RomeBannerModule { }